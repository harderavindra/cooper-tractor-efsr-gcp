import { ChevronLeft } from 'lucide-react'

export function MobilePageController({
  page,
  total,
  onChange,
}: {
  page: number
  total: number
  onChange: (p: number) => void
}) {
  return (
    <div className="flex items-center justify-end gap-2 rounded-2xl px-0 py-1">
      <button
        onClick={() => onChange(Math.max(0, page - 1))}
        disabled={page === 0}
        className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity"
      >
        <ChevronLeft className="w-5 h-5 text-gray-600" />
      </button>
      <div className="flex items-center gap-2">
        <span className="text-sm text-gray-400 font-medium uppercase">Page</span>
        <span className="text-sm font-bold text-gray-800">{page + 1} / {total}</span>
      </div>
      <button
        onClick={() => onChange(Math.min(total - 1, page + 1))}
        disabled={page === total - 1}
        className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity"
      >
        <ChevronLeft className="w-5 h-5 text-gray-600 rotate-180" />
      </button>
    </div>
  )
}
