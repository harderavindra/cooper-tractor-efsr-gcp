import { MapPin, Phone } from 'lucide-react'

interface AssetLike {
  clientName?: string
  address?: {
    line1?: string; line2?: string; locality?: string
    city?: string; taluk?: string; district?: string
    state?: string; pinCode?: string; country?: string
  }
  primaryContactName?: string
  primaryContactNumber?: string
  alternateContactName?: string
  alternateContactNumber?: string
}

function buildAddr(asset: AssetLike): string {
  return [
    asset.address?.line1,
    asset.address?.city,
    asset.address?.district,
    asset.address?.state,
    asset.address?.pinCode,
  ].filter(Boolean).join(', ')
}

export function AssetLocationContact({ asset }: { asset: AssetLike | null | undefined }) {
  if (!asset) return null
  const addr = buildAddr(asset)

  const hasLocation = !!(asset.clientName || addr)
  const hasPrimary  = !!(asset.primaryContactName || asset.primaryContactNumber)
  const hasAlt      = !!(asset.alternateContactName || asset.alternateContactNumber)

  return (
    <div className="flex flex-col border border-gray-200 rounded-xl">
      {/* Location */}
      <div className="flex items-start gap-4 border-b border-gray-200 px-3 py-3">
        <MapPin size={16} className="text-gray-400 shrink-0 mt-0.5" />
        {hasLocation ? (
          <div>
            {asset.clientName && (
              <p className="text-sm font-bold text-gray-950">{asset.clientName}</p>
            )}
            {addr && (
              <p className="text-sm text-gray-950 leading-relaxed">{addr}</p>
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-400 italic min-h-[60px]">Location not available</p>
        )}
      </div>

      {/* Primary contact */}
      <div className={`flex items-center gap-4 px-3 py-2.5 ${hasAlt ? 'border-b border-gray-200' : ''}`}>
        <Phone size={16} className="text-gray-400 shrink-0" />
        {hasPrimary ? (
          <div className="flex flex-1 justify-between flex-wrap items-center gap-x-2 gap-y-0.5">
            {asset.primaryContactName && (
              <span className="text-sm font-semibold text-gray-950">{asset.primaryContactName}</span>
            )}
            {asset.primaryContactNumber ? (
              <a href={`tel:+91${asset.primaryContactNumber}`}
                className="text-sm text-blue-600 font-medium"
                onClick={e => e.stopPropagation()}>
                +91 {asset.primaryContactNumber}
              </a>
            ) : (
              <span className="text-sm text-gray-400 italic">No contact number</span>
            )}
          </div>
        ) : (
          <p className="text-sm text-gray-400 italic">Contact not available</p>
        )}
      </div>

      {/* Alternate contact — only when data exists */}
      {hasAlt ? (
        <div className="flex items-center gap-4 px-3 py-2.5">
          <Phone size={16} className="text-gray-400 shrink-0" />
          <div className="flex flex-1 justify-between flex-wrap items-center gap-x-2 gap-y-0.5">
            <span className="text-sm font-semibold text-gray-500">
              {asset.alternateContactName || 'Alternate Contact'}
            </span>
            {asset.alternateContactNumber && (
              <a href={`tel:+91${asset.alternateContactNumber}`}
                className="text-sm text-gray-400 font-medium"
                onClick={e => e.stopPropagation()}>
                +91 {asset.alternateContactNumber}
              </a>
            )}
          </div>
        </div>
      ):(
        <div className="flex items-center gap-4 px-3 py-2.5">
          <Phone size={20} className="text-gray-500 shrink-0" />
          <p className="text-sm text-gray-400 italic">No alternate contact</p>
        </div>
      )}
    </div>
  )
}
