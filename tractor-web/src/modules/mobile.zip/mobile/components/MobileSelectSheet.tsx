import { useState, type ReactNode } from 'react'
import { Search, CheckCircle2, ChevronDown } from 'lucide-react'
import { Avatar } from '../../../shared/components/Avatar'

export interface SelectSheetItem {
  id:       string
  label:    string
  sublabel?: string
  avatar?:  { name: string; userId: string; photo?: string }
}

interface Props {
  open:               boolean
  title:              string
  subtitle?:          string
  items:              SelectSheetItem[]
  value:              string
  onChange:           (id: string) => void
  onClose:            () => void
  onConfirm:          () => void
  confirmLabel?:      string
  confirmIcon?:       ReactNode
  confirming?:        boolean
  searchPlaceholder?: string
  emptyLabel?:        string
  resultLabel?:       (n: number) => string
}

export function MobileSelectSheet({
  open,
  title,
  subtitle,
  items,
  value,
  onChange,
  onClose,
  onConfirm,
  confirmLabel     = 'Confirm',
  confirmIcon,
  confirming       = false,
  searchPlaceholder = 'Search…',
  emptyLabel       = 'No items found.',
  resultLabel      = n => `${n} item${n !== 1 ? 's' : ''} available`,
}: Props) {
  const [query, setQuery] = useState('')

  if (!open) return null

  const q        = query.toLowerCase()
  const filtered = items.filter(it =>
    !q || it.label.toLowerCase().includes(q) || it.sublabel?.toLowerCase().includes(q)
  )

  function handleClose() {
    setQuery('')
    onClose()
  }

  function handleConfirm() {
    setQuery('')
    onConfirm()
  }

  return (
    <div className="popoup fixed inset-0 z-50 flex items-end" onClick={handleClose}>
      <div className="absolute inset-0 bg-black/40" />

      <div
        className="relative w-full max-w-[420px] mx-auto bg-white rounded-t-3xl shadow-2xl flex flex-col"
        style={{ maxHeight: '85vh' }}
        onClick={e => e.stopPropagation()}
      >
        {/* ── Sticky header ── */}
        <div className="shrink-0 px-5 pt-4 pb-3 border-b border-gray-100">
          <div className="flex justify-center mb-3">
            <ChevronDown className="w-5 h-5 text-gray-400" />
          </div>

          <p className="text-base font-bold text-gray-900">{title}</p>
          {subtitle && (
            <p className="text-xs text-gray-400 mt-0.5">{subtitle}</p>
          )}

          {/* Search bar */}
          <div className="flex items-center border border-gray-200 rounded-xl bg-gray-50 px-3 py-2.5 gap-2 mt-3">
            <Search className="w-4 h-4 text-gray-400 shrink-0" />
            <input
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder={searchPlaceholder}
              className="flex-1 text-sm outline-none bg-transparent placeholder-gray-400"
            />
            {query && (
              <button onClick={() => setQuery('')} className="text-gray-300 hover:text-gray-500">
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>

          <p className="text-[11px] text-gray-400 mt-2">{resultLabel(filtered.length)}</p>
        </div>

        {/* ── Scrollable list ── */}
        <div className="flex-1 overflow-y-auto overscroll-contain divide-y divide-gray-50">
          {filtered.length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-12">{emptyLabel}</p>
          ) : filtered.map(item => (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={`w-full flex items-center gap-3 px-5 py-3.5 text-left transition-colors ${
                value === item.id ? 'bg-orange-50' : 'active:bg-gray-50'
              }`}
            >
              {item.avatar && (
                <Avatar
                  name={item.avatar.name}
                  userId={item.avatar.userId}
                  photo={item.avatar.photo}
                  size="md"
                  showPopover={false}
                />
              )}

              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-gray-900 truncate">{item.label}</p>
                {item.sublabel && (
                  <p className="text-xs text-gray-400 mt-0.5">{item.sublabel}</p>
                )}
              </div>

              {value === item.id
                ? <CheckCircle2 className="w-5 h-5 text-[#E76124] shrink-0" />
                : <div className="w-5 h-5 rounded-full border-2 border-gray-200 shrink-0" />
              }
            </button>
          ))}
        </div>

        {/* ── Sticky footer ── */}
        <div className="shrink-0 px-5 pt-3 pb-8 border-t border-gray-100 flex gap-2 bg-white">
          <button
            onClick={handleClose}
            className="flex-1 py-3 rounded-2xl border border-gray-200 text-sm font-semibold text-gray-500 active:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            disabled={!value || confirming}
            onClick={handleConfirm}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#E76124] text-white text-sm font-bold disabled:opacity-40 active:bg-[#d4561f] transition-colors"
          >
            {confirmIcon}
            {confirming ? 'Please wait…' : confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
