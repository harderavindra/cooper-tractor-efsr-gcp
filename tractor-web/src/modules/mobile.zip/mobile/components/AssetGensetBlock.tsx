import { useState } from "react";
import { Wrench } from "lucide-react";
import { Avatar } from "../../../shared/components/Avatar";

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

// srNumber format: DDMMYY + 8-digit sequence (e.g. "26082600000041")
function parseSrDate(sr: string): { date: string; seq: string } | null {
  const digits = sr.replace(/\D/g, '')
  if (digits.length < 6) return null
  const dd = parseInt(digits.slice(0, 2))
  const mm = parseInt(digits.slice(2, 4))
  const yy = digits.slice(4, 6)
  if (dd < 1 || dd > 31 || mm < 1 || mm > 12) return null
  const seq = digits.length > 6 ? String(parseInt(digits.slice(6))) : ''
  return {
    date: `${String(dd).padStart(2, '0')}${MONTHS[mm - 1]}${yy}`,
    seq,
  }
}

interface PersonRef {
  name: string;
  userId?: string;
  profilePic?: string;
}

interface AssetRef {
  gensetNumber?: string;
  engineNumber?: string;
  gensetModel?: string;
}

const THEME = {
  commissioning: {
    pill:   'bg-orange-600/80',
    block:  'bg-orange-50',
    iconBg: 'bg-orange-600/80',
    iconFg: 'text-orange-50',
    ring:   'ring-orange-50',
  },
  service: {
    pill:   'bg-indigo-800',
    block:  'bg-indigo-100',
    iconBg: 'bg-indigo-800',
    iconFg: 'text-indigo-100',
    ring:   'ring-indigo-100',
  },
} as const

export function AssetGensetBlock({
  asset,
  icon,
  srNumber,
  variant = 'commissioning',
  createdBy,
  assignedTo,
}: {
  asset: AssetRef | null | undefined;
  icon?: React.ReactNode;
  srNumber?: string;
  variant?: 'service' | 'commissioning';
  createdBy?: PersonRef | null;
  assignedTo?: PersonRef | null;
}) {
  const [showFull, setShowFull] = useState(false)
  const t = THEME[variant]

  const parsed = srNumber ? parseSrDate(srNumber) : null
  const pillLabel = showFull || !parsed
    ? srNumber
    : `${parsed.date}${parsed.seq ? ' · ' + parsed.seq : ''}`

  const mainLabel = asset?.gensetModel ?? asset?.gensetNumber ?? '—'
  const subParts = asset?.gensetModel
    ? [asset.gensetNumber, asset.engineNumber].filter(Boolean)
    : [asset?.engineNumber].filter(Boolean)
  const subLabel = subParts.join(' · ')

  const showAssignee = assignedTo && assignedTo.userId !== createdBy?.userId

  return (
    <>
      {srNumber && (
        <button
          onClick={e => { e.stopPropagation(); setShowFull(s => !s) }}
          className={`inline-flex items-center ${t.pill} px-3 py-1.5 rounded-full font-mono text-xs text-gray-100 tracking-wide transition-opacity active:opacity-70`}
          title={showFull ? 'Show date' : 'Show SR number'}
        >
          {pillLabel}
        </button>
      )}

      <div className={`flex justify-between items-center ${t.block} rounded-xl px-3 py-2.5`}>
        <div className="flex gap-2 min-w-0">
          <div className={`w-9 h-9 rounded-full ${t.iconBg} flex items-center justify-center shrink-0`}>
            {icon ?? <Wrench className={`w-5 h-5 ${t.iconFg} shrink-0`} />}
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-bold text-gray-900 text-sm tracking-wide truncate">
              {mainLabel}
            </span>
            {subLabel && (
              <span className="text-gray-400 text-xs truncate">{subLabel}</span>
            )}
          </div>
        </div>

        {(createdBy || assignedTo) && (
          <div className="flex -space-x-2 shrink-0">
            {createdBy && (
              <Avatar
                name={createdBy.name}
                userId={createdBy.userId}
                photo={createdBy.profilePic}
                size="md"
                showPopover
                popoverPos="left"
                className={`ring-2 ${t.ring}`}
              />
            )}
            {showAssignee && (
              <Avatar
                name={assignedTo!.name}
                userId={assignedTo!.userId}
                photo={assignedTo!.profilePic}
                size="md"
                showPopover
                popoverPos="left"
                className={`ring-2 ${t.ring}`}
              />
            )}
          </div>
        )}
      </div>
    </>
  )
}
