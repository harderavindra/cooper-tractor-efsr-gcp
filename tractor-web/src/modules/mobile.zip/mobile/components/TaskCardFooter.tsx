import type { ReactNode } from 'react'
import { Avatar } from '../../../shared/components/Avatar'
import { timeAgo } from '../../../shared/utils/dateUtils'

interface Assignee {
  name: string
  userId?: string
  profilePic?: string
}

interface PillConfig {
  label: string
  cls: string
}

export function TaskCardFooter({
  assignee,
  createdAt,
  pill,
  children,
}: {
  assignee?: Assignee | null
  createdAt: string
  pill: PillConfig
  children?: ReactNode
}) {
  return (
    <div className="flex items-center gap-2 pt-1">
      <div className="flex items-center gap-1.5 bg-gray-900 text-white rounded-full pl-1 pr-3 py-1">
        {assignee && (
          <Avatar
            name={assignee.name}
            userId={assignee.userId}
            photo={assignee.profilePic}
            size="xs"
            showPopover
          />
        )}
        <span className="text-xs">{timeAgo(createdAt)}</span>
      </div>

      <span className={`text-xs font-semibold px-3 py-1 rounded-full ${pill.cls}`}>
        {pill.label}
      </span>

      <div className="flex-1" />

      {children && (
        <div className="flex items-center gap-2">
          {children}
        </div>
      )}
    </div>
  )
}
