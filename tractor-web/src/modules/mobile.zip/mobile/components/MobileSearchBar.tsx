import { useRef, useState } from 'react'

interface MobileSearchBarProps {
  value: string
  onChange: (v: string) => void
  placeholder?: string
  onSearch?: () => void
  defaultExpanded?: boolean
}

export function MobileSearchBar({
  value,
  onChange,
  placeholder = 'Search..',
  onSearch,
  defaultExpanded = false,
}: MobileSearchBarProps) {
  const [expanded, setExpanded] = useState(defaultExpanded)
  const inputRef = useRef<HTMLInputElement>(null)

  function open() {
    setExpanded(true)
    setTimeout(() => inputRef.current?.focus(), 30)
  }

  function collapse() {
    if (!value) setExpanded(false)
  }

  function clear() {
    onChange('')
    setExpanded(false)
  }

  if (!expanded) {
    return (
      <button
        onClick={open}
        className="w-11 h-11 rounded-full bg-gray-400/90 flex items-center justify-center shadow-sm hover:bg-[#E76124] transition-colors"
        aria-label="Open search"
      >
        <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-4.35-4.35M17 11A6 6 0 111 11a6 6 0 0116 0z" />
        </svg>
      </button>
    )
  }

  return (
    <div className="flex-1 flex items-center gap-2 bg-white border border-[#fa9568] rounded-full px-2 py-2 shadow-sm h-11">
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={e => onChange(e.target.value)}
        onBlur={collapse}
        onKeyDown={e => e.key === 'Enter' && onSearch?.()}
        placeholder={placeholder}
        className="flex-1 text-sm text-gray-800 placeholder-gray-400 outline-none bg-transparent pl-3"
      />
      {value && (
        <button
          onMouseDown={clear}
          className="text-gray-400 hover:text-gray-600 transition-colors p-0.5"
          aria-label="Clear"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}
      <button
        onMouseDown={e => { e.preventDefault(); onSearch?.() }}
        className="w-8 h-8 rounded-full bg-[#fa9568] flex items-center justify-center shrink-0 hover:bg-[#E76124] transition-colors"
        aria-label="Search"
      >
        <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-4.35-4.35M17 11A6 6 0 111 11a6 6 0 0116 0z" />
        </svg>
      </button>
    </div>
  )
}
