import { useState } from 'react'

const MAX = 120

export function TaskNotesBlock({ notes }: { notes?: string | null }) {
  const [expanded, setExpanded] = useState(false)
  if (!notes) return null

  const long = notes.length > MAX
  const text = long && !expanded ? notes.slice(0, MAX) : notes

  return (
    <div className="bg-amber-50 border border-amber-100 rounded-xl px-3 py-2.5">
      <p className="text-sm text-gray-600 leading-relaxed">
        {text}
        {long && !expanded && (
          <button
            onClick={e => { e.stopPropagation(); setExpanded(true) }}
            className="ml-1 text-xs font-semibold text-amber-700 hover:underline">
            …more
          </button>
        )}
        {long && expanded && (
          <button
            onClick={e => { e.stopPropagation(); setExpanded(false) }}
            className="ml-1 text-xs font-semibold text-amber-700 hover:underline">
            less
          </button>
        )}
      </p>
    </div>
  )
}
