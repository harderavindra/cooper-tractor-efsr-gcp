import { useState } from 'react'
import {
  ArrowRight,
  BookmarkCheck,
  ChevronRight,
  CalendarCheck,
  ScrollText,
  UserRoundCog,
  Settings,
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { ActivityCard } from '../../../shared/components/ActivityCard'
import { acceptEntry, startEntry } from '../../commissioning/services/commissioningApi'
import type { CommissioningTask } from '../../../shared/hooks/useMyTasks'
import { AssetLocationContact } from './AssetLocationContact'
import { AssetGensetBlock } from './AssetGensetBlock'
import { TaskNotesBlock } from './TaskNotesBlock'
import { TaskCardFooter } from './TaskCardFooter'

const TYPE_LABEL: Record<string, string> = {
  PRE_COMMISSIONING: 'Pre-Commissioning',
  COMMISSIONING:     'Commissioning',
  REVALIDATION:      'Revalidation',
  RE_COMMISSIONING:  'Re-Commissioning',
}


const STATUS_PILL: Record<string, { label: string; cls: string }> = {
  OPEN:        { label: 'Open',         cls: 'bg-gray-100 text-gray-600' },
  ASSIGNED:    { label: 'Assigned',     cls: 'bg-blue-100 text-blue-700' },
  ACCEPTED:    { label: 'Acknowledged', cls: 'bg-[#fde9df] text-[#E76124]' },
  IN_PROGRESS: { label: 'In Progress',  cls: 'bg-amber-100 text-amber-700' },
  COMPLETED:   { label: 'Completed',    cls: 'bg-green-100 text-green-700' },
  APPROVED:    { label: 'Approved',     cls: 'bg-indigo-100 text-indigo-700' },
  CLOSED:      { label: 'Closed',       cls: 'bg-gray-200 text-gray-500' },
}

const DONE = new Set(['COMPLETED', 'APPROVED', 'CLOSED'])

export function MobileCommCard({
  task,
  userId,
  isDealer = false,
  onReload,
  onOpenAssign,
}: {
  task:          CommissioningTask
  userId?:       string
  isDealer?:     boolean
  onReload?:     () => void
  onOpenAssign?: (taskId: string, type: 'accepted' | 'active', subtitle: string) => void
}) {
  const navigate = useNavigate()
  const asset    = task.asset
  const pill     = STATUS_PILL[task.status] ?? STATUS_PILL.OPEN
  const assignee = task.assignedTo ?? task.createdBy
  const isDone   = DONE.has(task.status)

  const [acting,      setActing]      = useState(false)
  const [actionError, setActionError] = useState('')

  const ownTask = !!userId && task.assignedTo?.userId?.toString() === userId

  const subtitle = [asset?.gensetNumber, asset?.clientName].filter(Boolean).join(' · ')

  async function runAction(fn: () => Promise<void>) {
    setActing(true)
    setActionError('')
    try {
      await fn()
      onReload?.()
    } catch (err) {
      setActionError(err instanceof Error ? err.message : 'Action failed')
    } finally {
      setActing(false)
    }
  }

  let actionIcon: React.ReactNode = null
  let onAction:   (() => void) | undefined

  if (!isDone) {
    if (task.status === 'ASSIGNED' && ownTask) {
      actionIcon = <BookmarkCheck className="w-5 h-5" />
      onAction   = () => runAction(() => acceptEntry(task._id))
    } else if (task.status === 'ASSIGNED' && !ownTask && isDealer) {
      actionIcon = <UserRoundCog className="w-5 h-5" />
      onAction   = () => onOpenAssign?.(task._id, 'active', subtitle)
    } else if (task.status === 'ACCEPTED' && ownTask && !isDealer) {
      actionIcon = <ArrowRight className="w-5 h-5" />
      onAction   = () => runAction(() => startEntry(task._id))
    } else if (task.status === 'ACCEPTED' && ownTask && isDealer) {
      actionIcon = <UserRoundCog className="w-5 h-5" />
      onAction   = () => onOpenAssign?.(task._id, 'accepted', subtitle)
    } else if (task.status === 'IN_PROGRESS' && ownTask) {
      actionIcon = <ChevronRight className="w-5 h-5" />
      onAction   = () => navigate(
        `/mobile/commissioning/${task._id}/complete`,
        { state: { returnTo: '/mobile/commissioning' } }
      )
    }
  }

  // ─────────────────────────────────────────────────────────────────────────

  return (
    <div         className="bg-white rounded-4xl p-4 space-y-4">
    

        <AssetGensetBlock 
        asset={asset}
        icon={<Settings className="w-5 h-5 text-indigo-100 shrink-0" />}
        srNumber={task.srNumber}
                  createdBy={task.createdBy ? { ...task.createdBy, profilePic: (task.createdBy as { profilePic?: string }).profilePic } : null}
          assignedTo={task.assignedTo ? { ...task.assignedTo, profilePic: (task.assignedTo as { profilePic?: string }).profilePic } : null}

        />

        <AssetLocationContact asset={asset} />

         <span className="bg-gray-900 text-white text-base font-semibold px-4 py-2 rounded-full block mb-3 w-full flex gap-3 items-center justify-start">
              <Settings size={24} />
              {TYPE_LABEL[task.type] ?? task.type}
            </span>

        <TaskNotesBlock notes={task.notes} />

        {/* done-only: date + activity */}
        {isDone && (
          <div className="space-y-3">
            {task.completedAt && (
              <div className="flex items-center gap-2 bg-green-50 rounded-xl px-3 py-2">
                <CalendarCheck className="w-4 h-4 text-green-600 shrink-0" />
                <div>
                  <p className="text-[10px] text-green-600 font-medium">Completed</p>
                  <p className="text-xs font-bold text-green-800">
                    {new Date(task.completedAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </p>
                </div>
              </div>
            )}
            <ActivityCard
              statusHistory={task.statusHistory}
              actionLog={task.actionLog}
              date={task.createdAt}
              createdByName={task.createdBy?.name}
              completedByName={task.assignedTo?.name}
              compact
            />
          </div>
        )}

        {actionError && (
          <p className="text-xs text-red-500 px-1">{actionError}</p>
        )}

        <TaskCardFooter
          assignee={assignee ? { name: assignee.name, userId: assignee.userId, profilePic: assignee.profilePic } : null}
          createdAt={task.createdAt}
          pill={pill}
        >
          {isDone ? (
            <button
              onClick={() => navigate(`/mobile/commissioning/${task._id}`, { state: { task } })}
              className="w-10 h-10 rounded-full bg-green-600 flex items-center justify-center text-white shadow-md shrink-0 hover:scale-105 transition-transform"
            >
              <ScrollText className="w-5 h-5" />
            </button>
          ) : onAction ? (
            <button
              onClick={onAction}
              disabled={acting}
              className="w-10 h-10 rounded-full bg-[#E76124] flex items-center justify-center text-white shadow-md shrink-0 hover:scale-105 transition-transform disabled:opacity-60"
            >
              {actionIcon}
            </button>
          ) : null}
        </TaskCardFooter>
    </div>
  )
}
