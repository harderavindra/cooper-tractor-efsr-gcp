const STATUS_LABEL = { active: 'Active', completed: 'Completed', closed: 'Closed' }

const THEME = {
  commissioning: {
    border:      'border-[#FFC3A8]',
    gradient:    'linear-gradient(90deg, #FA9568 0%, #F5B38E 100%)',
    activeText:  'text-gray-900',
    badgeActive: 'bg-white/30 text-gray-900',
  },
  service: {
    border:      'border-[#c5c9e8]',
    gradient:    'linear-gradient(90deg, #1E1951 0%, #3b3f8c 100%)',
    activeText:  'text-white',
    badgeActive: 'bg-white/20 text-white',
  },
} as const

export function MobileStatusTabs({
  status,
  onChange,
  counts,
  variant = 'commissioning',
}: {
  status: string
  onChange: (s: string) => void
  counts: { active: number; completed: number; closed: number }
  variant?: 'service' | 'commissioning'
}) {
  const t = THEME[variant]

  return (
    <div className={`flex items-center bg-white rounded-full p-1 border ${t.border}`}>
      {(['active', 'completed', 'closed'] as const).map(s => {
        const isActive = status === s
        return (
          <button
            key={s}
            onClick={() => onChange(s)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-full text-sm font-semibold transition-all ${
              isActive ? `${t.activeText} shadow-sm` : 'text-gray-400 hover:text-gray-600'
            }`}
            style={isActive ? { background: t.gradient } : undefined}
          >
            {STATUS_LABEL[s]}
            {counts[s] > 0 && (
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                isActive ? t.badgeActive : 'bg-gray-100 text-gray-500'
              }`}>
                {counts[s]}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}
