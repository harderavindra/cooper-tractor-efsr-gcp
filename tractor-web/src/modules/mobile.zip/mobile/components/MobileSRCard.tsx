import { useState } from "react";
import {
  ArrowRight,
  BookmarkCheck,
  ChevronRight,
  CheckCircle2,
  UserRoundCog,
  Clock,
  ClipboardList,
  Check,
  X,
  RefreshCcw,
} from "lucide-react";
import { Avatar } from "../../../shared/components/Avatar";
import { timeAgo } from "../../../shared/utils/dateUtils";
import type { ServiceTask } from "../../../shared/hooks/useMyTasks";
import type { AssignableUser } from "../../service/types";
import {
  CATEGORY_GROUPS,
  type SRCategory,
} from "../../service/data/serviceCategories";
import { AssetLocationContact } from "./AssetLocationContact";
import { AssetGensetBlock } from "./AssetGensetBlock";
import { TaskNotesBlock } from "./TaskNotesBlock";
import { TaskCardFooter } from "./TaskCardFooter";

const STATUS_PILL: Record<string, { label: string; cls: string }> = {
  OPEN: { label: "Open", cls: "bg-gray-100 text-gray-600" },
  ASSIGNED: { label: "Assigned", cls: "bg-blue-100 text-blue-700" },
  ACCEPTED: { label: "Acknowledged", cls: "bg-[#fde9df] text-[#E76124]" },
  IN_PROGRESS: { label: "In Progress", cls: "bg-amber-100 text-amber-700" },
  COMPLETED: { label: "Completed", cls: "bg-green-100 text-green-700" },
  APPROVED: { label: "Approved", cls: "bg-indigo-100 text-indigo-700" },
  CLOSED: { label: "Closed", cls: "bg-gray-200 text-gray-500" },
};

const ASSIGN_STATUSES = ["OPEN", "ASSIGNED", "ACCEPTED"];

function fmtCategory(cat?: string): string {
  if (!cat) return "Service";
  const found = CATEGORY_GROUPS.flatMap(
    (g) => g.items as readonly { letter: SRCategory; label: string }[],
  ).find((i) => i.letter === cat);
  return found ? found.label : cat;
}

function ActionIcon({ status }: { status: string }) {
  if (status === "ASSIGNED") return <BookmarkCheck className="w-5 h-5" />;
  if (status === "IN_PROGRESS") return <ChevronRight className="w-5 h-5" />;
  return <ArrowRight className="w-5 h-5" />;
}

export function MobileSRCard({
  task,
  onPress,
  onAction,
  onReport,
  engineers = [],
  isDealer = false,
  onAssign,
  onOpenAssign,
}: {
  task: ServiceTask;
  onPress?: () => void;
  onAction?: () => void;
  onReport?: () => void;
  engineers?: AssignableUser[];
  isDealer?: boolean;
  onAssign?: (id: string, engineerId: string) => void;
  onOpenAssign?: (
    taskId: string,
    type: "accepted" | "active",
    subtitle: string,
  ) => void;
}) {
  const asset = task.asset;
  const pill = STATUS_PILL[task.status] ?? STATUS_PILL.OPEN;
  const assignee = task.assignedTo ?? task.createdBy;

  const [assignOpen, setAssignOpen] = useState(false);
  const [selectedEng, setSelectedEng] = useState("");
  const [assigning, setAssigning] = useState(false);

  const subtitle = [asset?.gensetNumber, asset?.clientName]
    .filter(Boolean)
    .join(" · ");

  const canAssign =
    isDealer &&
    engineers.length > 0 &&
    !!onAssign &&
    ASSIGN_STATUSES.includes(task.status);

  function confirmAssign() {
    if (!selectedEng || !onAssign) return;
    setAssigning(true);
    onAssign(task._id, selectedEng);
    setAssignOpen(false);
    setSelectedEng("");
    setAssigning(false);
  }

  // Dealer action: Assign (ASSIGNED) or Reassign (ACCEPTED / IN_PROGRESS)
  let dealerAction: (() => void) | undefined;
  if (isDealer && onOpenAssign) {
    if (task.status === "ASSIGNED") {
      dealerAction = () => onOpenAssign(task._id, "active", subtitle);
    } else if (task.status === "ACCEPTED" || task.status === "IN_PROGRESS") {
      dealerAction = () => onOpenAssign(task._id, "accepted", subtitle);
    }
  }

  return (
    <>
      <div
        className="bg-white rounded-4xl p-4 space-y-4"
        onClick={onPress}
        role={onPress ? "button" : undefined}
      >
        

        <AssetGensetBlock
          asset={asset}
          variant="service"
          srNumber={task.srNumber}
          createdBy={task.createdBy ? { ...task.createdBy, profilePic: (task.createdBy as { profilePic?: string }).profilePic } : null}
          assignedTo={task.assignedTo ? { ...task.assignedTo, profilePic: (task.assignedTo as { profilePic?: string }).profilePic } : null}
        />

        <AssetLocationContact asset={asset} />
<div className="flex flex-col  gap-2 ">
          <div className="flex gap-1 bg-[#1E1951] text-white text-sm font-semibold px-4 py-2 rounded-full tracking-wide w-full ">
            <RefreshCcw
              size={24}
              className="text-white/50 inline-block mr-1 -mt-0.5"
            />
            {fmtCategory(task.category)}
          </div>
          {task.subCategory && (
            <div className="bg-[#1E1951]/10 text-[#1E1951] text-xs font-medium px-3 py-1.5 rounded-full">
              {task.subCategory}
            </div>
          )}
        </div>
        {/* title */}
        {task.title && (
          <p className="text-sm font-bold text-gray-900 leading-snug">
            {task.title}
          </p>
        )}

        <TaskNotesBlock notes={task.notes} />
        
        {/* approval chain */}
        {task.workApproval?.status &&
          (() => {
            const wa = task.workApproval!;
            const s = wa.status;

            const amState: "pending" | "approved" | "rejected" =
              s === "REJECTED" && wa.amDecidedBy && !wa.rsmDecidedBy
                ? "rejected"
                : wa.amDecidedBy
                  ? "approved"
                  : "pending";

            const rsmState: "pending" | "approved" | "rejected" =
              s === "REJECTED" && wa.rsmDecidedBy
                ? "rejected"
                : wa.rsmDecidedBy
                  ? "approved"
                  : "pending";

            const badgeCls = {
              approved: "bg-green-500",
              rejected: "bg-red-500",
              pending: "bg-amber-400",
            };
            const BadgeIcon = ({
              state,
            }: {
              state: "approved" | "rejected" | "pending";
            }) => (
              <span
                className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center ${badgeCls[state]}`}
              >
                {state === "approved" && (
                  <Check strokeWidth={3} className="w-2 h-2 text-white" />
                )}
                {state === "rejected" && (
                  <X strokeWidth={3} className="w-2 h-2 text-white" />
                )}
                {state === "pending" && (
                  <Clock className="w-2 h-2 text-white" />
                )}
              </span>
            );

            return (
              <div className="bg-red-100 border border-red-300 rounded-xl px-4 py-2.5 flex items-center justify-center gap-3">
                {/* AM step */}
                <div className="flex items-center gap-2">
                  <div className="relative shrink-0">
                    {wa.amDecidedBy ? (
                      <Avatar
                        name={wa.amDecidedBy.name}
                        userId={wa.amDecidedBy.userId}
                        photo={wa.amDecidedBy.profilePic}
                        size="md"
                        showPopover={false}
                      />
                    ) : (
                      <div className="w-1 h-12 rounded-full bg-gray-200 flex items-center justify-center">
                        <span className="text-xs font-bold text-gray-400">
                          AM
                        </span>
                      </div>
                    )}
                    <BadgeIcon state={amState} />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-gray-500 leading-none">
                      AM
                    </p>
                    <p className="text-xs text-red-800 mt-0.5">
                      {wa.amDecidedAt ? timeAgo(wa.amDecidedAt) : "Pending"}
                    </p>
                  </div>
                </div>

                <ChevronRight className="w-3.5 h-3.5 text-gray-300 shrink-0" />

                {/* RSM step */}
                {(() => {
                  const rsm = wa.rsmDecidedBy ?? wa.rsmInfo;
                  return (
                    <div className="flex items-center gap-2">
                      <div className="relative shrink-0">
                        {rsm ? (
                          <Avatar
                            name={rsm.name}
                            userId={rsm.userId}
                            photo={rsm.profilePic}
                            size="md"
                            showPopover={false}
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                            <span className="text-[9px] font-bold text-gray-400">
                              RSM
                            </span>
                          </div>
                        )}
                        <BadgeIcon state={rsmState} />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-gray-500 leading-none">
                          RSM
                        </p>
                        <p className="text-xs text-red-800 mt-0.5">
                          {wa.rsmDecidedAt
                            ? timeAgo(wa.rsmDecidedAt)
                            : "Pending"}
                        </p>
                      </div>
                    </div>
                  );
                })()}
              </div>
            );
          })()}

        <TaskCardFooter
          assignee={assignee ? { name: assignee.name, userId: assignee.userId, profilePic: (assignee as { profilePic?: string }).profilePic } : null}
          createdAt={task.createdAt}
          pill={pill}
        >
          {canAssign && (
            <button
              onClick={(e) => { e.stopPropagation(); setAssignOpen(true); setSelectedEng(""); }}
              className="w-10 h-10 rounded-full bg-indigo-600 flex items-center justify-center text-white shadow-md shrink-0 hover:scale-105 transition-transform"
            >
              <UserRoundCog className="w-5 h-5" />
            </button>
          )}
          {onReport && (
            <button
              onClick={(e) => { e.stopPropagation(); onReport(); }}
              className="w-10 h-10 rounded-full bg-[#1E1951] flex items-center justify-center text-white shadow-md shrink-0 hover:scale-105 transition-transform"
            >
              <ClipboardList className="w-5 h-5" />
            </button>
          )}
          {!onReport && dealerAction && (
            <button
              onClick={(e) => { e.stopPropagation(); dealerAction!(); }}
              className="w-10 h-10 rounded-full bg-[#E76124] flex items-center justify-center text-white shadow-md shrink-0 hover:scale-105 transition-transform"
            >
              <UserRoundCog className="w-5 h-5" />
            </button>
          )}
          {!onReport && !dealerAction && onAction && (() => {
            const pa = task.preApproval
            const blocked = task.status === 'ASSIGNED' && pa?.required && pa.status !== 'APPROVED'
            return blocked ? (
              <span className="flex items-center gap-1.5 text-[10px] font-bold text-amber-600 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-full shrink-0">
                <Clock className="w-3 h-3" />
                Awaiting RSM
              </span>
            ) : (
              <button
                onClick={(e) => { e.stopPropagation(); onAction(); }}
                className="w-10 h-10 rounded-full bg-[#1E1951] flex items-center justify-center text-white shadow-md shrink-0 hover:scale-105 transition-transform"
              >
                <ActionIcon status={task.status} />
              </button>
            )
          })()}
        </TaskCardFooter>
      </div>

      {/* ── Assign / Reassign bottom sheet ── */}
      {assignOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          onClick={() => setAssignOpen(false)}
        >
          <div
            className="w-full max-w-[420px] mx-auto bg-white rounded-t-3xl px-5 pt-5 pb-8 space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-gray-200 mx-auto mb-1" />
            <div>
              <p className="text-base font-bold text-gray-900">
                {task.assignedTo
                  ? "Reassign to Engineer"
                  : "Assign to Engineer"}
              </p>
              <p className="text-xs text-gray-400 mt-0.5">
                {asset?.gensetNumber}
                {asset?.clientName ? ` · ${asset.clientName}` : ""}
              </p>
            </div>

            <div className="space-y-2 max-h-60 overflow-y-auto">
              {engineers.map((eng) => (
                <button
                  key={eng._id}
                  onClick={() => setSelectedEng(eng._id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl border transition-colors ${
                    selectedEng === eng._id
                      ? "border-[#E76124] bg-orange-50"
                      : "border-gray-200 bg-white hover:bg-gray-50"
                  }`}
                >
                  <Avatar
                    name={eng.name}
                    userId={eng._id}
                    size="md"
                    showPopover={false}
                  />
                  <p className="flex-1 text-sm font-semibold text-gray-800 text-left">
                    {eng.name}
                  </p>
                  {selectedEng === eng._id && (
                    <CheckCircle2 className="w-5 h-5 text-[#E76124] shrink-0" />
                  )}
                </button>
              ))}
            </div>

            <div className="flex gap-2 pt-1">
              <button
                disabled={!selectedEng || assigning}
                onClick={confirmAssign}
                className="flex items-center justify-center gap-2 flex-1 py-3 rounded-2xl bg-[#E76124] text-white text-sm font-bold disabled:opacity-40 hover:bg-[#d4561f] transition-colors"
              >
                <UserRoundCog className="w-4 h-4" />
                {assigning ? "Assigning…" : "Assign"}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
