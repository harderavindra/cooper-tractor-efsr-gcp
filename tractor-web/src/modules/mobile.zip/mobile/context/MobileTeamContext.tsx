import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react'
import { api } from '../../../shared/lib/api'
import { useAuth } from '../../../shared/context/AuthContext'

export interface TeamMember {
  _id:        string
  name:       string
  role:       string
  dealerName?: string
  profilePic: string | null
}

interface MobileTeamState {
  members:  TeamMember[]
  loading:  boolean
  refresh:  () => void
  clear:    () => void
}

const MobileTeamContext = createContext<MobileTeamState | null>(null)

export function MobileTeamProvider({ children }: { children: ReactNode }) {
  const { token, role } = useAuth()
  const [members, setMembers] = useState<TeamMember[]>([])
  const [loading, setLoading] = useState(false)

  const fetchMembers = useCallback(() => {
    if (!token || (role !== 'area_manager' && role !== 'dealer')) {
      setMembers([])
      return
    }
    setLoading(true)
    api.get<{ members: TeamMember[] }>('/api/me/team-members')
      .then(data => setMembers(data.members))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [token, role])

  useEffect(() => { fetchMembers() }, [fetchMembers])

  function clear() { setMembers([]) }

  return (
    <MobileTeamContext.Provider value={{ members, loading, refresh: fetchMembers, clear }}>
      {children}
    </MobileTeamContext.Provider>
  )
}

export function useMobileTeam() {
  const ctx = useContext(MobileTeamContext)
  if (!ctx) throw new Error('useMobileTeam must be used inside MobileTeamProvider')
  return ctx
}
