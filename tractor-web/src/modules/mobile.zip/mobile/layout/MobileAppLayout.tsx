import { Outlet } from 'react-router-dom'
import { BottomNav } from '../../../shared/components/BottomNav'
import OfflineBanner from '../../../shared/components/OfflineBanner'
import { MobileTeamProvider } from '../context/MobileTeamContext'

export default function MobileAppLayout() {
  return (
    <MobileTeamProvider>
      <div className="min-h-screen bg-[#0F0F1A] flex items-start justify-center py-6 px-10">
        <div className="w-full max-w-[420px] h-[calc(100vh-48px)] rounded-[40px] overflow-hidden shadow-2xl flex flex-col relative" style={{ background: 'radial-gradient(105.71% 33.55% at 50% 78.29%, #F5BC9D 0%, #F6F6F6 100%)' }}>
          <OfflineBanner />
          <main className="flex-1 overflow-y-auto pb-[100px]">
            <Outlet />
          </main>
          <BottomNav />
        </div>
      </div>
    </MobileTeamProvider>
  )
}
