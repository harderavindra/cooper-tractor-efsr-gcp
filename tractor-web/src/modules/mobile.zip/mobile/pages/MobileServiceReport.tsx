import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ChevronLeft,
  Bell,
  Clock,
  CheckCircle2,
  XCircle,
  Wrench,
  Trash2,
  Lock,
  CheckCheck,
} from "lucide-react";
import { serviceApi } from "../../service/services/serviceApi";
import { api } from "../../../shared/lib/api";
import { useAuth } from "../../../shared/context/AuthContext";
import type { DetailedServiceEntry, WorkApproval } from "../../service/types";
import type { Asset } from "../../../shared/data/types";
import { ActivityCard } from "../../../shared/components/ActivityCard";
import { PhotoImg } from "../../../shared/components/PhotoImg";
import { timeAgo } from "../../../shared/utils/dateUtils";
import { Avatar } from "../../../shared/components/Avatar";

// ── helpers ───────────────────────────────────────────────────────────────────

const STATUS_PILL: Record<string, string> = {
  IN_PROGRESS: "bg-amber-100 text-amber-700",
  COMPLETED: "bg-green-100 text-green-700",
  APPROVED: "bg-indigo-100 text-indigo-700",
  CLOSED: "bg-[#1E1951]/10 text-[#1E1951]",
};

const PRIORITY_CLS: Record<string, string> = {
  P1: "bg-red-100 text-red-700",
  P2: "bg-orange-100 text-orange-700",
  P3: "bg-blue-100 text-blue-700",
  P4: "bg-gray-100 text-gray-500",
};

function fmtCategory(cat?: string) {
  if (!cat) return "Service";
  return cat.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center w-full px-3 py-2 bg-indigo-100 rounded-full mb-3">
      <p className="text-sm font-bold capitalize tracking-wide text-gray-800">
        {children}
      </p>
    </div>
  );
}

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <svg
          key={s}
          className={`w-4 h-4 ${s <= rating ? "text-[#E76124]" : "text-gray-200"}`}
          fill="currentColor"
          viewBox="0 0 24 24"
        >
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
        </svg>
      ))}
      <span className="text-xs text-gray-500 ml-1">
        {["", "Poor", "Fair", "Good", "Very Good", "Excellent"][rating] ?? ""}
      </span>
    </div>
  );
}

function ApprovalTimeline({ wa }: { wa: WorkApproval }) {
  const rows: {
    dot: string;
    label: string;
    name?: string;
    when?: string;
    note?: string;
  }[] = [];

  if (wa.requestedBy)
    rows.push({
      dot: "bg-blue-400",
      label: "Submitted for Approval",
      name: wa.requestedBy.name,
      when: timeAgo(wa.requestedAt),
    });
  if (wa.amDecidedBy)
    rows.push({
      dot: wa.rejectedBy === "AM" ? "bg-red-400" : "bg-green-400",
      label: `AM ${wa.rejectedBy === "AM" ? "Rejected" : "Approved"}`,
      name: wa.amDecidedBy.name,
      when: wa.amDecidedAt ? timeAgo(wa.amDecidedAt) : undefined,
      note: wa.rejectedBy === "AM" ? wa.rejectionNote : undefined,
    });
  if (wa.rsmDecidedBy)
    rows.push({
      dot: wa.rejectedBy === "RSM" ? "bg-red-400" : "bg-emerald-500",
      label: `RSM ${wa.rejectedBy === "RSM" ? "Rejected" : "Confirmed"}`,
      name: wa.rsmDecidedBy.name,
      when: wa.rsmDecidedAt ? timeAgo(wa.rsmDecidedAt) : undefined,
      note: wa.rejectedBy === "RSM" ? wa.rejectionNote : undefined,
    });

  return (
    <div className="bg-white p-4 rounded-3xl">
      <SectionHeading>Approval Timeline</SectionHeading>
      <div className="space-y-3">
        {rows.map((r, i) => (
          <div key={i} className="flex items-start gap-3">
            <span
              className={`mt-1 w-2.5 h-2.5 rounded-full shrink-0 ${r.dot}`}
            />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-semibold text-gray-700">{r.label}</p>
              {r.name && <p className="text-xs text-gray-500">{r.name}</p>}
              {r.when && <p className="text-[10px] text-gray-400">{r.when}</p>}
              {r.note && (
                <div className="mt-1 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
                  <p className="text-xs text-red-700 italic">"{r.note}"</p>
                </div>
              )}
            </div>
          </div>
        ))}
        {wa.status === "PENDING_AM" && !wa.amDecidedBy && (
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-amber-500 shrink-0 animate-pulse" />
            <p className="text-xs text-amber-700 font-medium">
              Awaiting AM Review
            </p>
          </div>
        )}
        {wa.status === "PENDING_RSM" && !wa.rsmDecidedBy && (
          <div className="flex items-center gap-3">
            <Clock className="w-4 h-4 text-blue-500 shrink-0 animate-pulse" />
            <p className="text-xs text-blue-700 font-medium">
              Awaiting RSM Confirmation
            </p>
          </div>
        )}
        {wa.status === "CONFIRMED" && (
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-4 h-4 text-green-500 shrink-0" />
            <p className="text-xs text-green-700 font-medium">Fully Approved</p>
          </div>
        )}
        {wa.status === "REJECTED" && (
          <div className="flex items-center gap-3">
            <XCircle className="w-4 h-4 text-red-500 shrink-0" />
            <p className="text-xs text-red-700 font-medium">
              Rejected — Needs Revision
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function MobileServiceReport() {
  const { entryId } = useParams<{ entryId: string }>();
  const navigate = useNavigate();
  const { userId } = useAuth();

  const [entry, setEntry] = useState<DetailedServiceEntry | null>(null);
  const [asset, setAsset] = useState<Asset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [removingPartId, setRemovingPartId] = useState<string | null>(null);
  const [closing, setClosing] = useState(false);

  function loadEntry(id: string) {
    return serviceApi.getEntry(id).then(async (e) => {
      setEntry(e);
      try {
        setAsset(await api.get<Asset>(`/api/assets/${e.assetId}`));
      } catch {
        /* ignore */
      }
    });
  }

  useEffect(() => {
    if (!entryId) return;
    loadEntry(entryId)
      .catch(() => setError("Could not load record."))
      .finally(() => setLoading(false));
  }, [entryId]);

  async function removePart(partId: string) {
    if (!entryId) return;
    setRemovingPartId(partId);
    try {
      await serviceApi.removeRejectedPart(entryId, partId);
      await loadEntry(entryId);
    } catch {
      /* ignore — part may already be gone */
    } finally {
      setRemovingPartId(null);
    }
  }

  const isAssignedEngineer =
    !!userId && entry?.assignedTo?.userId?.toString() === userId;

  async function handleClose() {
    if (!entryId) return;
    setClosing(true);
    try {
      await serviceApi.closeEntry(entryId);
      await loadEntry(entryId);
    } catch {
      /* ignore */
    } finally {
      setClosing(false);
    }
  }

  const partsReady =
    !entry?.partApproval ||
    (entry.partApproval.status === "REVIEWED" &&
      (entry.partsUsed ?? []).every(
        (p) => p.decision === "APPROVED" || p.decision === "REMOVED"
      ));

  const workReady =
    !entry?.workApproval || entry.workApproval.status === "CONFIRMED";

  const closeBlockedReason = !partsReady
    ? "Waiting for all parts to be approved"
    : !workReady
      ? "Waiting for work approval to be confirmed"
      : null;

  const showCloseBar =
    isAssignedEngineer &&
    !!entry &&
    entry.status !== "CLOSED";

  const addr = asset
    ? [
        asset.address?.line1,
        asset.address?.city,
        asset.address?.district,
        asset.address?.state,
        asset.address?.pinCode,
      ]
        .filter(Boolean)
        .join(", ")
    : "";

  const photos = entry?.photos ?? [];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <div className="flex items-center gap-2 flex-1 justify-center flex-wrap">
          Service Report
        </div>
        <button className="relative w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center shrink-0">
          <Bell className="w-4 h-4 text-gray-500" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500" />
        </button>
      </div>

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto px-4">
        {loading && (
          <div className="flex items-center justify-center py-20 gap-2 text-gray-400">
            <svg
              className="w-5 h-5 animate-spin"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8v8H4z"
              />
            </svg>
            <span className="text-sm">Loading…</span>
          </div>
        )}
        {error && (
          <p className="text-sm text-red-500 text-center py-10">{error}</p>
        )}

        {!loading && entry && (
          <>
            {/* Asset identity */}
            <div className="bg-white rounded-2xl shadow-sm px-4 py-4 space-y-3">
              <div className="flex w-full">
                <div className="flex flex-col gap-5 justify-center min-w-0 w-full ">
                  <div className="flex items-center gap-2 flex-wrap">
                    {entry.srNumber && (
                      <span className=" bg-indigo-800 px-3 py-1.5 rounded-full font-mono text-xs text-gray-100 tracking-widest">
                        {entry.srNumber}
                      </span>
                    )}
                    {asset?.warrantyStatus && (
                      <span
                        className={`shrink-0 text-xs font-semibold px-2.5 py-1 rounded-full ${
                          asset.warrantyStatus === "Under Warranty"
                            ? "bg-green-100 text-green-700"
                            : "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {asset.warrantyStatus}
                      </span>
                    )}
                  </div>

                  <div className="flex gap-3">
                    <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center shrink-0">
                      <Wrench className="w-6 h-6 text-indigo-500" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-900 text-base leading-tight">
                        {asset?.gensetNumber ?? "—"}
                      </p>
                      {asset?.engineNumber && (
                        <p className="text-sm text-gray-400 mt-0.5">
                          {asset.engineNumber}
                        </p>
                      )}
                    </div>
                    {/* Stacked avatars — created by + working by */}
                    <div className="flex -space-x-2.5 shrink-0 mt-0.5">
                      {entry.createdBy && (
                        <div
                          className="ring-2 ring-white rounded-full"
                          title={`Created by ${entry.createdBy.name}`}
                        >
                          <Avatar
                            name={entry.createdBy.name}
                            userId={entry.createdBy.userId}
                            photo={entry.createdBy.profilePic}
                            size="lg"
                            showPopover
                          />
                        </div>
                      )}
                      {entry.assignedTo && (
                        <div
                          className="ring-2 ring-white rounded-full"
                          title={`Working by ${entry.assignedTo.name}`}
                        >
                          <Avatar
                            name={entry.assignedTo.name}
                            userId={entry.assignedTo.userId}
                            photo={entry.assignedTo.profilePic}
                            size="lg"
                            showPopover
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  {addr && (
                    <p className="text-xs text-gray-400 mt-0.5">{addr}</p>
                  )}
                </div>
              </div>

              {/* Title */}
              {entry.title && (
                <p className="text-sm font-bold text-gray-800">{entry.title}</p>
              )}
              <div className="flex items-center gap-2 flex-wrap">
                {entry?.category && (
                  <span className="bg-[#1E1951] text-white text-xs font-bold px-2.5 py-1 rounded-full">
                    {fmtCategory(entry.category)}
                  </span>
                )}
                {entry?.status && (
                  <span
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_PILL[entry.status] ?? "bg-gray-100 text-gray-500"}`}
                  >
                    {entry.status.replace("_", " ")}
                  </span>
                )}
              </div>

              {/* Activity history */}
              <div className="bg-white  rounded-3xl">
                <SectionHeading>Activity History</SectionHeading>
                <ActivityCard
                  actionLog={entry.actionLog}
                  date={entry.date}
                  createdByName={entry.createdBy?.name}
                  completedByName={entry.assignedTo?.name}
                  compact={true}
                />
              </div>
            </div>

            <div className=" py-5 space-y-6">
              {/* Photos */}
              {photos.length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Photos ({photos.length})</SectionHeading>
                  <div className="grid grid-cols-3 gap-2">
                    {photos.map((p, i) => (
                      <button
                        key={i}
                        type="button"
                        className="aspect-square rounded-xl overflow-hidden bg-gray-100 border border-gray-200 hover:opacity-90 transition-opacity"
                      >
                        <PhotoImg
                          src={p}
                          alt={`Photo ${i + 1}`}
                          className="w-full h-full object-cover"
                          onClick={(url) => setLightbox(url)}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Fault / Complaint Codes */}
              {(entry.faultCodes ?? []).length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>
                    Complaint Codes ({entry.faultCodes!.length})
                  </SectionHeading>
                  <div className="space-y-3">
                    {entry.faultCodes!.map((fc, i) => (
                      <div key={i} className="overflow-hidden">
                        <div className="flex items-start gap-3">
                          <span className="bg-orange-400 font-mono text-xs font-bold text-gray-900 px-2 py-1 rounded-lg shrink-0">
                            {fc.codeId.code}
                          </span>
                          {fc.codeId.priority && (
                            <span
                              className={`text-[9px] font-bold px-1.5 py-0.5 rounded mt-0.5 shrink-0 ${PRIORITY_CLS[fc.codeId.priority] ?? "bg-gray-100 text-gray-500"}`}
                            >
                              {fc.codeId.priority}
                            </span>
                          )}
                        </div>
                        <div className="min-w-0 px-4">
                          <p className="text-xs font-semibold text-[#1E1951] leading-snug">
                            {fc.codeId.description}
                          </p>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {fc.codeId.category} › {fc.codeId.subCategory}
                          </p>
                        </div>
                        <div className="px-4 py-3 space-y-2">
                          {fc.observation && (
                            <div className="bg-yellow-100 px-3 py-2">
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-wide mb-1">
                                Observation
                              </p>
                              <p className="text-xs text-gray-700 leading-relaxed">
                                {fc.observation}
                              </p>
                            </div>
                          )}
                          {fc.rootCause && (
                            <div className="bg-red-100 px-3 py-2">
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-wide mb-1">
                                Root Cause
                              </p>
                              <p className="text-xs text-gray-700 leading-relaxed">
                                {fc.rootCause}
                              </p>
                            </div>
                          )}
                          {fc.correctiveAction && (
                            <div className="bg-green-100 px-3 py-2">
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-wide mb-1">
                                Corrective Action
                              </p>
                              <p className="text-xs text-gray-700 leading-relaxed">
                                {fc.correctiveAction}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Parts Used */}
              {(entry.partsUsed ?? []).length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>
                    Parts Used ({entry.partsUsed!.length})
                  </SectionHeading>

                  {/* Part-approval overall status */}
                  {entry.partApproval && (
                    <div
                      className={`flex items-center gap-2 rounded-xl px-3 py-2 mb-3 ${
                        entry.partApproval.status === "REVIEWED"
                          ? "bg-green-50 border border-green-200"
                          : "bg-orange-50 border border-orange-200"
                      }`}
                    >
                      {entry.partApproval.status === "REVIEWED" ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0" />
                      ) : (
                        <Clock className="w-3.5 h-3.5 text-orange-500 shrink-0 animate-pulse" />
                      )}
                      <p
                        className={`text-xs font-semibold ${
                          entry.partApproval.status === "REVIEWED"
                            ? "text-green-700"
                            : "text-orange-700"
                        }`}
                      >
                        {entry.partApproval.status === "REVIEWED"
                          ? "Parts reviewed by AM"
                          : "Pending AM part review"}
                      </p>
                    </div>
                  )}

                  <div className="space-y-2">
                    {entry.partsUsed!.map((p, i) => {
                      const dec = p.decision;
                      const isRemoved = dec === "REMOVED";
                      const decCls =
                        dec === "APPROVED"
                          ? "bg-green-400 text-green-50"
                          : dec === "REJECTED"
                            ? "bg-red-400 text-red-50"
                            : dec === "REMOVED"
                              ? "bg-gray-300 text-gray-500"
                              : "bg-blue-400 text-blue-50";
                      return (
                        <div
                          key={i}
                          className={`rounded-xl border overflow-hidden ${
                            isRemoved
                              ? "border-gray-200 opacity-60"
                              : dec === "REJECTED"
                                ? "border-red-300"
                                : "border-blue-300"
                          }`}
                        >
                          <div className="flex items-center gap-3 bg-white px-3 py-2.5">
                            <div className="flex-1 min-w-0">
                              <span className="font-mono text-xs font-bold bg-amber-100 border border-amber-200 text-amber-700 px-2 py-1 rounded-full shrink-0">
                                {p.partId.code}
                              </span>
                              <p className={`text-sm font-semibold truncate ${isRemoved ? "line-through text-gray-400" : "text-[#1E1951]"}`}>
                                {p.partId.name}
                              </p>
                              <p className="text-xs text-gray-400">
                                {p.partId.category} › {p.partId.subCategory}
                              </p>
                            </div>
                            <div className="flex flex-col items-end gap-1 shrink-0">
                              <span className={`text-lg font-bold ${isRemoved ? "text-gray-300 line-through" : "text-gray-700"}`}>
                                {p.quantity}{" "}
                                <span className="font-normal text-gray-400">
                                  {p.partId.unit}
                                </span>
                              </span>
                              {dec && (
                                <span
                                  className={`text-xs font-bold px-2 py-1 rounded-full ${decCls}`}
                                >
                                  {dec}
                                </span>
                              )}
                            </div>
                          </div>
                          {dec === "REJECTED" && (
                            <div className="bg-red-50 px-3 py-2 border-t border-red-100 flex items-center justify-between gap-2">
                              {p.decisionReason && (
                                <p className="text-[10px] text-red-600 italic flex-1">
                                  "{p.decisionReason}"
                                </p>
                              )}
                              {isAssignedEngineer && (
                                <button
                                  onClick={() => removePart(p.partId._id)}
                                  disabled={removingPartId === p.partId._id}
                                  className="shrink-0 flex items-center gap-1 text-[11px] font-semibold text-red-600 bg-red-100 hover:bg-red-200 px-2.5 py-1 rounded-full transition-colors disabled:opacity-50"
                                >
                                  <Trash2 className="w-3 h-3" />
                                  {removingPartId === p.partId._id ? "Removing…" : "Remove"}
                                </button>
                              )}
                            </div>
                          )}
                          {isRemoved && p.decisionReason && (
                            <div className="bg-gray-50 px-3 py-1.5 border-t border-gray-100">
                              <p className="text-[10px] text-gray-400 italic">
                                Rejected: "{p.decisionReason}"
                              </p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Notes */}
              {entry.notes && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Notes</SectionHeading>
                  <p className="text-sm text-gray-700 leading-relaxed">
                    {entry.notes}
                  </p>
                </div>
              )}

              {/* Customer Feedback */}
              {entry.customerFeedback && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Customer Feedback</SectionHeading>
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      {entry.customerFeedback.customerName && (
                        <p className="text-sm font-bold text-[#1E1951]">
                          {entry.customerFeedback.customerName}
                        </p>
                      )}
                      {entry.customerFeedback.rating != null && (
                        <Stars rating={entry.customerFeedback.rating} />
                      )}
                    </div>
                    {entry.customerFeedback.comment && (
                      <p className="text-xs text-gray-600 leading-relaxed italic border-t border-gray-200 pt-2.5">
                        "{entry.customerFeedback.comment}"
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Approval Timeline */}
              {entry.workApproval && (
                <ApprovalTimeline wa={entry.workApproval} />
              )}

              <div className="pb-4" />
            </div>
          </>
        )}
      </div>

      {/* Close bar */}
      {showCloseBar && (
        <div className="shrink-0 px-4 py-3 bg-white border-t border-gray-100">
          {closeBlockedReason ? (
            <div className="flex items-center gap-2.5 bg-gray-50 border border-gray-200 rounded-2xl px-4 py-3">
              <Lock className="w-4 h-4 text-gray-400 shrink-0" />
              <p className="text-xs text-gray-500">{closeBlockedReason}</p>
            </div>
          ) : (
            <button
              onClick={handleClose}
              disabled={closing}
              className="w-full flex items-center justify-center gap-2 bg-[#1E1951] text-white font-bold text-sm py-3.5 rounded-2xl disabled:opacity-60 transition-opacity"
            >
              <CheckCheck className="w-4 h-4" />
              {closing ? "Closing…" : "Close Service"}
            </button>
          )}
        </div>
      )}

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <img
            src={lightbox}
            alt="Full size"
            className="max-w-full max-h-full rounded-xl object-contain"
          />
          <button
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/20 flex items-center justify-center"
            onClick={() => setLightbox(null)}
          >
            <ChevronLeft className="w-5 h-5 text-white rotate-180" />
          </button>
        </div>
      )}
    </div>
  );
}
