import { useState, useEffect, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronLeft, Bell, Clock, XCircle, CheckCircle2, Wrench } from 'lucide-react'
import { api } from '../../../shared/lib/api'
import { serviceApi } from '../../service/services/serviceApi'
import type { ServiceEntryFlat } from '../../service/types'
import type { Asset } from '../../../shared/data/types'
import { SR_CATEGORIES } from '../../service/data/serviceCategories'
import { MobileSearchBar } from '../components/MobileSearchBar'
import { timeAgo } from '../../../shared/utils/dateUtils'

const SR_CAT_MAP = Object.fromEntries(SR_CATEGORIES.map(c => [c.letter, c.title]))

const WA_BADGE: Record<string, { label: string; cls: string; icon: React.ReactNode }> = {
  PENDING_AM:  { label: 'Work · Awaiting AM',  cls: 'bg-amber-100 text-amber-700', icon: <Clock className="w-3 h-3" /> },
  PENDING_RSM: { label: 'Work · Awaiting RSM', cls: 'bg-blue-100 text-blue-700',   icon: <Clock className="w-3 h-3" /> },
  REJECTED:    { label: 'Work · Rejected',     cls: 'bg-red-100 text-red-600',     icon: <XCircle className="w-3 h-3" /> },
  CONFIRMED:   { label: 'Work · Approved',     cls: 'bg-green-100 text-green-700', icon: <CheckCircle2 className="w-3 h-3" /> },
}

const PA_BADGE: Record<string, { label: string; cls: string; icon: React.ReactNode }> = {
  PENDING:  { label: 'Parts · Pending AM',  cls: 'bg-orange-100 text-orange-700', icon: <Clock className="w-3 h-3" /> },
  REVIEWED: { label: 'Parts · Reviewed',    cls: 'bg-green-100 text-green-700',   icon: <CheckCircle2 className="w-3 h-3" /> },
}

const WA_PENDING_STATUSES  = ['PENDING_AM', 'PENDING_RSM', 'REJECTED'] as const
const WA_APPROVED_STATUSES = ['CONFIRMED'] as const
const PA_PENDING_STATUSES  = ['PENDING'] as const
const PA_APPROVED_STATUSES = ['REVIEWED'] as const

const PAGE_SIZE = 10

function PageController({ page, total, onChange }: { page: number; total: number; onChange: (p: number) => void }) {
  return (
    <div className="flex items-center justify-end gap-2 px-1 py-1">
      <button onClick={() => onChange(Math.max(0, page - 1))} disabled={page === 0}
        className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity">
        <ChevronLeft className="w-5 h-5 text-gray-600" />
      </button>
      <div className="flex flex-col items-center">
        <span className="text-xs text-gray-400 font-medium">Page</span>
        <span className="text-sm font-bold text-gray-800 leading-none">{page + 1} / {total}</span>
      </div>
      <button onClick={() => onChange(Math.min(total - 1, page + 1))} disabled={page === total - 1}
        className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity">
        <ChevronLeft className="w-5 h-5 text-gray-600 rotate-180" />
      </button>
    </div>
  )
}

type Row = ServiceEntryFlat & { asset: Asset }

export default function MobileSRApprovals() {
  const navigate = useNavigate()

  const [mine,    setMine]    = useState(true)
  const [tab,     setTab]     = useState<'pending' | 'approved'>('pending')
  const [search,  setSearch]  = useState('')
  const [pageIdx, setPageIdx] = useState(0)
  const [rows,    setRows]    = useState<Row[]>([])
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState('')

  useEffect(() => {
    setLoading(true)
    setError('')
    const m       = mine ? '&mine=true' : ''
    const waStats = tab === 'pending' ? WA_PENDING_STATUSES  : WA_APPROVED_STATUSES
    const paStats = tab === 'pending' ? PA_PENDING_STATUSES  : PA_APPROVED_STATUSES

    Promise.all([
      Promise.all(waStats.map(s =>
        api.get<ServiceEntryFlat[]>(`/api/service?workApprovalStatus=${s}${m}`)
      )).then(r => r.flat()),
      Promise.all(paStats.map(s =>
        api.get<ServiceEntryFlat[]>(`/api/service?partApprovalStatus=${s}${m}`)
      )).then(r => r.flat()),
      serviceApi.listAssets(),
    ])
      .then(([waEntries, paEntries, assets]) => {
        const assetMap = new Map(assets.map(a => [a._id, a]))
        const seen = new Set<string>()
        const merged: Row[] = []
        for (const e of [...waEntries, ...paEntries]) {
          if (seen.has(e._id)) continue
          seen.add(e._id)
          const asset = assetMap.get(e.assetId)
          if (asset) merged.push({ ...e, asset })
        }
        setRows(merged)
        setPageIdx(0)
      })
      .catch(err => setError(err instanceof Error ? err.message : 'Failed to load'))
      .finally(() => setLoading(false))
  }, [tab, mine])

  const visible = useMemo(() => {
    if (!search) return rows
    const q = search.toLowerCase()
    return rows.filter(r =>
      r.asset.gensetNumber?.toLowerCase().includes(q) ||
      r.asset.clientName?.toLowerCase().includes(q) ||
      r.asset.engineNumber?.toLowerCase().includes(q) ||
      r.title?.toLowerCase().includes(q)
    )
  }, [rows, search])

  const totalPages = Math.max(1, Math.ceil(visible.length / PAGE_SIZE))
  const safePage   = Math.min(pageIdx, totalPages - 1)
  const pageItems  = visible.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)

  function changeTab(t: 'pending' | 'approved') { setTab(t); setSearch(''); setPageIdx(0) }
  function changeMine(v: boolean)                { setMine(v); setSearch(''); setPageIdx(0) }

  return (
    <div className="px-4 py-6 space-y-4">

      {/* Header */}
      <div className="flex items-center justify-between">
        <button onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0">
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">SR Approvals</p>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>

      {/* My / All toggle */}
      <div className="flex items-center bg-white rounded-full p-1 border border-gray-200 w-fit mx-auto">
        {(['My', 'All'] as const).map(label => {
          const active = label === 'My' ? mine : !mine
          return (
            <button key={label} onClick={() => changeMine(label === 'My')}
              className={`px-7 py-2 rounded-full text-sm font-bold transition-all ${
                active ? 'bg-[#1E1951] text-white shadow-sm' : 'text-gray-400 hover:text-gray-600'
              }`}>
              {label}
            </button>
          )
        })}
      </div>

      {/* Pending / Approved tabs */}
      <div className="flex items-center bg-white rounded-full p-1 border border-[#FFC3A8]">
        {([
          { key: 'pending',  label: 'Pending'  },
          { key: 'approved', label: 'Approved' },
        ] as const).map(({ key, label }) => (
          <button key={key} onClick={() => changeTab(key)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-full text-sm font-semibold transition-all ${
              tab === key ? 'text-gray-900 shadow-sm' : 'text-gray-400 hover:text-gray-600'
            }`}
            style={tab === key ? { background: 'linear-gradient(90deg, #FA9568 0%, #F5B38E 100%)' } : undefined}>
            {label}
            {!loading && rows.length > 0 && (
              <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                tab === key ? 'bg-white/30 text-gray-900' : 'bg-gray-100 text-gray-500'
              }`}>
                {rows.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Search */}
      <MobileSearchBar
        value={search}
        onChange={v => { setSearch(v); setPageIdx(0) }}
        placeholder="Genset S/N, customer…"
      />

      {error   && <div className="bg-red-50 text-red-600 text-sm rounded-xl px-4 py-3">{error}</div>}
      {loading && <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>}

      {!loading && visible.length > 0 && (
        <>
          {totalPages > 1 && <PageController page={safePage} total={totalPages} onChange={setPageIdx} />}
          <div className="space-y-3">
            {pageItems.map(row => {
              const waBadge = row.workApproval?.status ? WA_BADGE[row.workApproval.status] : null
              const paBadge = row.partApproval?.status ? PA_BADGE[row.partApproval.status] : null
              const badge = waBadge ?? paBadge
              return (
                <button
                  key={row._id}
                  onClick={() => navigate(`/mobile/service/${row._id}`)}
                  className="w-full bg-white rounded-2xl px-4 py-3 shadow-sm text-left hover:shadow-md transition-shadow space-y-1.5"
                >
                  {/* Row 1: SR number · category */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-mono text-gray-400 tracking-wide">
                      {row.srNumber ?? '—'}
                    </span>
                    {row.category && (
                      <span className="text-xs font-bold text-[#1E1951]">
                        {row.category} · {SR_CAT_MAP[row.category] ?? row.category}
                      </span>
                    )}
                  </div>

                  {/* Row 2: icon · genset number · date */}
                  <div className="flex items-center gap-2">
                    <Wrench className="w-3.5 h-3.5 text-gray-400 shrink-0" />
                    <span className="text-xs font-semibold text-gray-800 flex-1 truncate">
                      {row.asset.gensetNumber ?? '—'}
                    </span>
                    <span className="text-xs text-gray-400 shrink-0">{timeAgo(row.createdAt)}</span>
                  </div>

                  {/* Row 3: engine number · approval badge */}
                  <div className="flex items-center gap-2 pl-5">
                    <span className="text-xs text-gray-400 flex-1 truncate">
                      {row.asset.engineNumber ?? '—'}
                    </span>
                    {badge && (
                      <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full shrink-0 ${badge.cls}`}>
                        {badge.icon}{badge.label}
                      </span>
                    )}
                  </div>
                </button>
              )
            })}
          </div>
        </>
      )}

      {!loading && visible.length === 0 && (
        <div className="bg-white rounded-2xl px-5 py-12 text-center shadow-sm">
          <p className="text-sm text-gray-400">
            {tab === 'pending' ? 'No pending approvals.' : 'No approved entries.'}
          </p>
        </div>
      )}
    </div>
  )
}
