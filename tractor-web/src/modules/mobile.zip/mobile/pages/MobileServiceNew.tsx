import { useState, useEffect } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { ChevronLeft, Bell, MapPin, Wrench, Info, UserRoundCog, ChevronRight } from 'lucide-react'
import { useAuth } from '../../../shared/context/AuthContext'
import { api } from '../../../shared/lib/api'
import { serviceApi, type FreeServiceAvailabilityItem } from '../../service/services/serviceApi'
import { searchSapAssets, fetchAvailableActions } from '../../commissioning/services/commissioningApi'
import type { Asset } from '../../../shared/data/types'
import type { AssignableUser } from '../../service/types'
import type { SapAssetSearchResult } from '../../commissioning/types'
import { MobileSearchBar } from '../components/MobileSearchBar'
import { MobileSelectSheet, type SelectSheetItem } from '../components/MobileSelectSheet'
import { CATEGORY_GROUPS, CATEGORY_STYLE, CAT_INFO, type SRCategory } from '../../service/data/serviceCategories'

type SearchState = 'idle' | 'searching' | 'found' | 'sap_found' | 'not_found'

function fmtDate(d?: string | null) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function sapDispatchLogic(billingDate?: string | null) {
  if (!billingDate) return {
    type: 'no_date' as const,
    label: 'No Dispatch Date',
    desc: 'SAP record has no billing date — dispatch date unknown.',
    dot: 'bg-gray-300', wrap: 'bg-gray-50 border-gray-200', title: 'text-gray-500', body: 'text-gray-400',
  }
  const date         = new Date(billingDate)
  const AUTO_CUTOFF  = new Date('2024-07-01')
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

  if (date < AUTO_CUTOFF) return {
    type: 'auto' as const,
    label: 'Auto-Commissioned',
    desc:  'Dispatch date before July 2024 — a completed commissioning entry will be created automatically.',
    dot: 'bg-green-500', wrap: 'bg-green-50 border-green-200', title: 'text-green-700', body: 'text-green-600',
  }
  if (date >= sixMonthsAgo) return {
    type: 'window' as const,
    label: 'Commissioning Window Open',
    desc:  'Within the 6-month window — asset must be commissioned before a service request can be raised.',
    dot: 'bg-blue-500', wrap: 'bg-blue-50 border-blue-200', title: 'text-blue-700', body: 'text-blue-600',
  }
  return {
    type: 'revalidation' as const,
    label: 'Revalidation Required',
    desc:  'Dispatch date is more than 6 months ago — revalidation will be needed before a service request can be raised.',
    dot: 'bg-amber-500', wrap: 'bg-amber-50 border-amber-200', title: 'text-amber-700', body: 'text-amber-600',
  }
}

export default function MobileServiceNew() {
  const navigate      = useNavigate()
  const [searchParams] = useSearchParams()
  const { role, dealerName, canAssign, userId, name: userName } = useAuth()
  const isDealer = role === 'dealer'
  const isAM     = role === 'area_manager'

  // ── search ────────────────────────────────────────────────────────────────
  const [query,       setQuery]       = useState('')
  const [searchState, setSearchState] = useState<SearchState>('idle')
  const [asset,       setAsset]       = useState<Asset | null>(null)
  const [sapRecord,   setSapRecord]   = useState<SapAssetSearchResult | null>(null)

  // ── form ──────────────────────────────────────────────────────────────────
  const [title,        setTitle]        = useState('')
  const [notes,        setNotes]        = useState('')
  const [assignedToId, setAssignedToId] = useState('')
  const [selCategory,      setSelCategory]      = useState<SRCategory | ''>('')
  const [selSubCat,        setSelSubCat]        = useState('')
  const [freeServiceItems, setFreeServiceItems] = useState<FreeServiceAvailabilityItem[]>([])
  const [saving,          setSaving]          = useState(false)
  const [saveError,       setSaveError]       = useState('')
  const [assignSheetOpen, setAssignSheetOpen] = useState(false)
  const [commStatus,      setCommStatus]      = useState<string | null>(null)

  // ── assignable engineers (dealer only) ───────────────────────────────────
  const [engineers, setEngineers] = useState<AssignableUser[]>([])
  useEffect(() => {
    if (!isDealer) return
    serviceApi.listAssignableUsers(['engineer'])
      .then(users => setEngineers(dealerName ? users.filter(u => u.dealerName === dealerName) : users))
      .catch(() => {})
  }, [isDealer, dealerName])

  // ── assignable dealers (AM only) ─────────────────────────────────────────
  const [dealers, setDealers] = useState<AssignableUser[]>([])
  useEffect(() => {
    if (!isAM) return
    serviceApi.listAssignableUsers(['dealer'])
      .then(setDealers)
      .catch(() => {})
  }, [isAM])

  // ── category config ───────────────────────────────────────────────────────
  useEffect(() => {
    serviceApi.getCategoryConfig()
      .then(cfg => console.log('[category-config]', cfg))
      .catch(err => console.error('[category-config]', err))
  }, [])

  // ── resume after returning from create-asset page ─────────────────────────
  useEffect(() => {
    const assetId = searchParams.get('asset')
    if (!assetId) return
    api.get<Asset>(`/api/assets/${assetId}`)
      .then(a => { setAsset(a); setQuery(a.gensetNumber); setSearchState('found') })
      .catch(() => setSearchState('not_found'))
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // ── asset search ──────────────────────────────────────────────────────────
  async function handleSearch() {
    const q = query.trim()
    if (!q) return
    setSearchState('searching')
    setAsset(null); setSapRecord(null); setSaveError('')
    try {
      const results = await api.get<Asset[]>(`/api/assets/search?q=${encodeURIComponent(q)}`)
      if (results.length > 0) { setAsset(results[0]); setSearchState('found'); return }
      // Fallback: check SAP records
      const sapResults = await searchSapAssets(q)
      if (sapResults.length > 0) { setSapRecord(sapResults[0]); setSearchState('sap_found'); return }
      setSearchState('not_found')
    } catch {
      setSearchState('not_found')
    }
  }

  useEffect(() => {
    if (searchState === 'found' && asset) {
      setCommStatus(null)
      setFreeServiceItems([])
      fetchAvailableActions(asset._id)
        .then(r => setCommStatus(r.assetStatus))
        .catch(() => setCommStatus('COMMISSIONED'))
      serviceApi.getFreeServiceAvailability(asset._id)
        .then(setFreeServiceItems)
        .catch(() => {})
    } else {
      setCommStatus(null)
      setFreeServiceItems([])
    }
  }, [searchState, asset?._id])

  function handleClear() {
    setQuery(''); setAsset(null); setSapRecord(null); setSearchState('idle')
    setTitle(''); setNotes(''); setAssignedToId('')
    setSelCategory(''); setSelSubCat('')
    setSaveError(''); setCommStatus(null)
  }

  // ── create SR ─────────────────────────────────────────────────────────────
  async function handleSave() {
    if (!asset || !title.trim()) return
    setSaving(true); setSaveError('')
    try {
      await serviceApi.createEntry({
        title:        title.trim(),
        assetId:      asset._id,
        date:         new Date().toISOString().slice(0, 10),
        notes:        notes || undefined,
        assignedToId: assignedToId || undefined,
        category:     selCategory || undefined,
        subCategory:  selSubCat   || undefined,
      })
      navigate('/mobile/service')
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Failed to create')
    } finally {
      setSaving(false)
    }
  }

  const addr = asset ? [
    asset.address?.line1, asset.address?.city,
    asset.address?.district, asset.address?.state,
  ].filter(Boolean).join(', ') : ''

  return (
    <div className="min-h-screen bg-gray-100">

      {/* Header */}
      <div className="px-4 pt-6 pb-4 flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">New SR</p>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>

      <div className="px-4 space-y-4 pb-12">

        {/* Search */}
        <MobileSearchBar
          value={query}
          onChange={v => { setQuery(v); if (searchState !== 'idle') handleClear() }}
          onSearch={handleSearch}
          placeholder="Genset S/N or Engine S/N…"
          defaultExpanded
        />

        {/* Searching */}
        {searchState === 'searching' && (
          <p className="text-sm text-gray-400 text-center py-6">Searching…</p>
        )}

        {/* Idle hint */}
        {searchState === 'idle' && (
          <p className="text-sm text-gray-400 text-center pt-6">Enter Genset S/N or Engine S/N to find the asset</p>
        )}

        {/* Not found */}
        {searchState === 'not_found' && (
          <div className="bg-red-50 border border-red-100 rounded-2xl px-4 py-4">
            <p className="text-sm font-semibold text-red-600">No asset found</p>
            <p className="text-xs text-red-400 mt-0.5">No result for <strong>"{query}"</strong> in database or SAP.</p>
          </div>
        )}

        {/* SAP found — asset not yet registered */}
        {searchState === 'sap_found' && sapRecord && (
          <div className="space-y-3">
            <div className="bg-orange-50 border border-orange-200 rounded-2xl px-4 py-3 flex gap-3">
              <Info className="w-5 h-5 text-orange-500 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-orange-700">Found in SAP records</p>
                <p className="text-xs text-orange-500 mt-0.5">
                  Asset not yet registered. Create it now to proceed with the service request.
                </p>
              </div>
            </div>

            {/* SAP data preview */}
            <div className="bg-white rounded-2xl shadow-sm px-4 py-4 space-y-3">
              <div className="flex items-center gap-2 bg-orange-50 rounded-xl px-3 py-2.5">
                <Wrench className="w-5 h-5 text-orange-400 shrink-0" />
                <span className="font-bold text-gray-900 text-sm">{sapRecord.gensetSerialNo}</span>
                {sapRecord.engineSerialNo && <span className="text-gray-400 text-sm">{sapRecord.engineSerialNo}</span>}
                <div className="ml-auto flex items-center gap-1.5">
                  {sapRecord.gensetRating && <span className="text-xs text-gray-400">{sapRecord.gensetRating}</span>}
                  {sapRecord.cpcbStage && (
                    <span className="text-[10px] font-semibold bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">{sapRecord.cpcbStage}</span>
                  )}
                </div>
              </div>
              {(sapRecord.shipToPartyName || sapRecord.endCustomerDetails) && (
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
                  <div>
                    {sapRecord.shipToPartyName && <p className="text-sm font-bold text-gray-900">{sapRecord.shipToPartyName}</p>}
                    {sapRecord.endCustomerDetails && <p className="text-xs text-gray-400">{sapRecord.endCustomerDetails}</p>}
                    {[sapRecord.cityTQ, sapRecord.district, sapRecord.state].filter(Boolean).length > 0 && (
                      <p className="text-xs text-gray-400">{[sapRecord.cityTQ, sapRecord.district, sapRecord.state].filter(Boolean).join(', ')}</p>
                    )}
                  </div>
                </div>
              )}
            </div>

            {(() => {
              const logic = sapDispatchLogic(sapRecord.billingDate)
              return (
                <div className={`border rounded-2xl px-4 py-3 space-y-1.5 ${logic.wrap}`}>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${logic.dot}`} />
                    <p className={`text-sm font-bold ${logic.title}`}>{logic.label}</p>
                  </div>
                  {sapRecord.billingDate && (
                    <p className={`text-xs ${logic.body}`}>Dispatch Date: {fmtDate(sapRecord.billingDate)}</p>
                  )}
                  <p className={`text-xs ${logic.body}`}>{logic.desc}</p>
                </div>
              )
            })()}

            <button
              onClick={() => navigate('/mobile/assets/create', {
                state: { sapRecord, returnTo: '/mobile/service/new', context: 'service' },
              })}
              className="w-full py-3 rounded-2xl bg-[#E76124] text-white text-sm font-bold hover:bg-[#cf5520] transition-colors"
            >
              Create Asset &amp; Continue
            </button>
          </div>
        )}

        {/* Found */}
        {searchState === 'found' && asset && (
          <>
            {/* Asset card */}
            <div className="bg-white rounded-2xl shadow-sm px-4 py-4 space-y-3">
              <div className="flex items-center gap-2 bg-indigo-50 rounded-xl px-3 py-2.5">
                <Wrench className="w-5 h-5 text-indigo-500 shrink-0" />
                <span className="font-bold text-gray-900 text-sm">{asset.gensetNumber}</span>
                {asset.engineNumber && <span className="text-gray-400 text-sm">{asset.engineNumber}</span>}
                {asset.kva && <span className="ml-auto text-xs text-gray-400">{asset.kva} KVA</span>}
              </div>
              {(asset.clientName || addr) && (
                <div className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
                  <div>
                    {asset.clientName && <p className="text-sm font-bold text-gray-900">{asset.clientName}</p>}
                    {addr && <p className="text-xs text-gray-400 leading-relaxed">{addr}</p>}
                  </div>
                </div>
              )}
            </div>

            {/* Commissioning status loading */}
            {commStatus === null && (
              <p className="text-sm text-gray-400 text-center py-2">Checking asset status…</p>
            )}

            {/* Blocked: not yet commissioned */}
            {commStatus !== null && (commStatus === 'NOT_DISPATCHED' || commStatus === 'IN_WINDOW') && (
              <div className="bg-amber-50 border border-amber-200 rounded-2xl px-4 py-4 flex gap-3">
                <Info className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-amber-700">Commissioning required</p>
                  <p className="text-xs text-amber-600 mt-0.5">
                    This asset has not been commissioned yet. Complete commissioning before raising a service request.
                  </p>
                </div>
              </div>
            )}

            {/* Form */}
            {commStatus !== null && commStatus !== 'NOT_DISPATCHED' && commStatus !== 'IN_WINDOW' && (
            <div className="bg-white rounded-2xl shadow-sm px-4 py-4 space-y-4">
              <p className="text-lg font-bold text-gray-900 uppercase tracking-widest">New Service Request</p>

              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">
                  Title <span className="text-red-400">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="Brief description of the issue…"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124]"
                />
              </div>

             

              {/* ── Category — Level 1 ── */}
              <div className="">
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">
                  Category <span className="text-red-400">*</span>
                </label>
                <div className="relative mb-5">
                  <select
                    value={selCategory}
                    onChange={e => { setSelCategory(e.target.value as SRCategory | ''); setSelSubCat('') }}
                    className={`w-full appearance-none border rounded-xl px-3 py-2.5 pr-9 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#E76124] transition-colors ${
                      selCategory ? 'text-gray-900 font-semibold border-gray-300' : 'text-gray-400 border-gray-200'
                    }`}
                  >
                    <option value="">Select category…</option>
                    {CATEGORY_GROUPS.map(group => (
                      <optgroup key={group.label} label={group.label}>
                        {group.items.map(item => (
                          <option key={item.letter} value={item.letter}>{item.label}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                  <ChevronRight className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 rotate-90" />
                </div>
               

              {/* ── Sub-category — Level 2 (A / F / G) ── */}
              {(() => {
                if (!selCategory) return null
                const item = CATEGORY_GROUPS.flatMap(g => g.items as readonly { letter: SRCategory; label: string; subCats: readonly string[] }[]).find(i => i.letter === selCategory)
                if (!item || item.subCats.length === 0) return null

                // Free Service with no commissioning date → show warning, block picker
                if (selCategory === 'A' && freeServiceItems.length > 0 && freeServiceItems[0].commissioningDate == null) {
                  return (
                    <div className="flex items-start gap-2 bg-red-500/50 border border-red-200 rounded-xl px-3 py-3 mb-4">
                      <Info className="w-4 h-4 text-white shrink-0 mt-0.5" />
                      <div>
                        <p className="text-sm font-semibold text-white">Commissioning date not available</p>
                        <p className="text-sm text-white mt-0.5">Free service window cannot be determined. Commission this asset first.</p>
                      </div>
                    </div>
                  )
                }

                const selectedInfo = selCategory === 'A' && selSubCat
                  ? freeServiceItems.find(i => i.label === selSubCat) ?? null
                  : null

                return (
                  <div className="mb-6">
                    <label className="block text-xs font-semibold text-gray-500 mb-1.5">
                      Sub-category <span className="text-red-400">*</span>
                    </label>
                    <div className="relative">
                      <select
                        value={selSubCat}
                        onChange={e => setSelSubCat(e.target.value)}
                        className={`w-full appearance-none border rounded-xl px-3 py-2.5 pr-9 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-[#E76124] transition-colors ${
                          selSubCat ? 'text-gray-900 font-semibold border-gray-300' : 'text-gray-400 border-gray-200'
                        }`}
                      >
                        <option value="">Select sub-category…</option>
                        {item.subCats.map(sub => {
                          if (selCategory === 'A') {
                            const fsItem = freeServiceItems.find(i => i.label === sub)
                            const suffix = fsItem ? ` — ${fsItem.reason}` : ''
                            return <option key={sub} value={sub} disabled={!fsItem?.canCreate}>{sub}{suffix}</option>
                          }
                          return <option key={sub} value={sub}>{sub}</option>
                        })}
                      </select>
                      <ChevronRight className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400 rotate-90" />
                    </div>

                    {/* Free service window status card */}
                    {selectedInfo && selectedInfo.status !== 'no_date' && (
                      <div className={`mt-2 flex items-center gap-2.5 rounded-xl px-3 py-2.5 border ${
                        selectedInfo.status === 'due'     ? 'bg-blue-50 border-blue-200'   :
                        selectedInfo.status === 'grace'   ? 'bg-amber-50 border-amber-200' :
                        selectedInfo.status === 'overdue' ? 'bg-red-50 border-red-200'     :
                                                            'bg-gray-50 border-gray-200'
                      }`}>
                        <span className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          selectedInfo.status === 'due'     ? 'bg-blue-100 text-blue-700'   :
                          selectedInfo.status === 'grace'   ? 'bg-amber-100 text-amber-700' :
                          selectedInfo.status === 'overdue' ? 'bg-red-100 text-red-600'     :
                                                              'bg-gray-100 text-gray-500'
                        }`}>{selectedInfo.reason}</span>
                        {selectedInfo.windowStart && selectedInfo.windowEnd && (
                          <p className="text-[10px] text-gray-500">
                            Window: {new Date(selectedInfo.windowStart).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}
                            {' – '}
                            {new Date(selectedInfo.windowEnd).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                )
              })()}
               {selCategory && (() => {
                  const allItems = CATEGORY_GROUPS.flatMap(g => g.items as readonly { letter: SRCategory; label: string; subCats: readonly string[] }[])
                  const catItem  = allItems.find(i => i.letter === selCategory)
                  const hasSubAtCreation = (catItem?.subCats.length ?? 0) > 0

                  return (
                    <div className="mt-2 rounded-xl border border-amber-200 bg-amber-100/50 px-3 py-3 space-y-1.5">
                      <div className="flex items-center gap-2">
                        <span className={`shrink-0 text-xs font-bold px-2.5 py-1 rounded-full ${CATEGORY_STYLE[selCategory].pill}`}>
                          {selCategory} - 
                        
                        <span className="">{catItem?.label}</span>
                        </span>
                      </div>
                      <p className="text-sm text-gray-900 leading-relaxed">{CAT_INFO[selCategory]}</p>
                      {hasSubAtCreation ? (
                        <p className="text-xs font-semibold text-[#E76124] pt-0.5">Select the service type below ↓</p>
                      ) : (
                        <div className="flex items-center gap-1.5 pt-0.5">
                          <Info className="w-3 h-3 text-blue-400 shrink-0" />
                          <p className="text-xs text-blue-500 font-medium">Engineer selects the service sub-type at Step 6</p>
                        </div>
                      )}
                    </div>
                  )
                })()}
              </div>

               {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-gray-500 mb-1.5">
                  Customer Reported Issue
                </label>
                <textarea
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  rows={3}
                  placeholder="Additional details…"
                  className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124] resize-none"
                />
              </div>

              {/* Assign To */}
              {(isAM && (userId || dealers.length > 0)) || (isDealer && canAssign && engineers.length > 0) ? (() => {
                const assignItems: SelectSheetItem[] = [
                  ...(isAM && userId && userName
                    ? [{ id: userId, label: `${userName} (You)`, sublabel: 'Area Manager', avatar: { name: userName, userId } }]
                    : []),
                  ...(isAM ? dealers : engineers).map((u: AssignableUser) => ({
                    id:       u._id,
                    label:    isAM ? (u.dealerName || u.name) : u.name,
                    sublabel: isAM ? u.name : (u.dealerName || 'Engineer'),
                    avatar:   { name: u.dealerName || u.name, userId: u._id },
                  })),
                ]
                const selectedItem = assignItems.find(it => it.id === assignedToId)
                return (
                  <div>
                    <label className="block text-xs font-semibold text-gray-500 mb-1.5">Assign To</label>
                    <button
                      type="button"
                      onClick={() => setAssignSheetOpen(true)}
                      className="w-full flex items-center gap-3 border border-gray-200 rounded-xl px-3 py-2.5 bg-gray-50 text-left active:bg-gray-100 transition-colors"
                    >
                      <UserRoundCog className="w-4 h-4 text-gray-400 shrink-0" />
                      <span className={`flex-1 text-sm ${selectedItem ? 'text-gray-900 font-semibold' : 'text-gray-400'}`}>
                        {selectedItem ? selectedItem.label : 'Select assignee…'}
                      </span>
                      <ChevronRight className="w-4 h-4 text-gray-300 shrink-0" />
                    </button>
                  </div>
                )
              })() : null}

              {saveError && <p className="text-xs text-red-500">{saveError}</p>}

              <button
                onClick={handleSave}
                disabled={saving || !title.trim() || !selCategory || (['A','F','G'].includes(selCategory) && !selSubCat)}
                className="w-full py-3 rounded-2xl bg-[#E76124] hover:bg-[#cf5520] disabled:opacity-40 text-white text-sm font-bold transition-colors"
              >
                {saving ? 'Creating…' : 'Create Service Request'}
              </button>
            </div>
            )}
          </>
        )}
      </div>

      {/* Assign sheet */}
      {(() => {
        const assignItems: SelectSheetItem[] = [
          ...(isAM && userId && userName
            ? [{ id: userId, label: `${userName} (You)`, sublabel: 'Area Manager', avatar: { name: userName, userId } }]
            : []),
          ...(isAM ? dealers : engineers).map((u: AssignableUser) => ({
            id:       u._id,
            label:    isAM ? (u.dealerName || u.name) : u.name,
            sublabel: isAM ? u.name : (u.dealerName || 'Engineer'),
            avatar:   { name: u.dealerName || u.name, userId: u._id },
          })),
        ]
        return (
          <MobileSelectSheet
            open={assignSheetOpen}
            title="Assign To"
            items={assignItems}
            value={assignedToId}
            onChange={setAssignedToId}
            onClose={() => setAssignSheetOpen(false)}
            onConfirm={() => setAssignSheetOpen(false)}
            confirmLabel="Select"
            confirmIcon={<UserRoundCog className="w-4 h-4" />}
            searchPlaceholder="Search by name…"
            emptyLabel="No users available."
            resultLabel={n => `${n} user${n !== 1 ? 's' : ''} available`}
          />
        )
      })()}
    </div>
  )
}
