import { useState, useMemo, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronLeft, Bell, UserRoundCog } from 'lucide-react'

import { useAuth } from '../../../shared/context/AuthContext'
import { useTeamTasks, type TeamTask } from '../../../shared/hooks/useTeamTasks'
import { useMyTasks, type ServiceTask } from '../../../shared/hooks/useMyTasks'
import { serviceApi } from '../../service/services/serviceApi'
import type { AssignableUser } from '../../service/types'
import { MobileSRCard } from '../components/MobileSRCard'
import { MobileSearchBar } from '../components/MobileSearchBar'
import { MobileSelectSheet } from '../components/MobileSelectSheet'
import { MobileStatusTabs } from '../components/MobileStatusTabs'
import { MobilePageController } from '../components/MobilePageController'
const STATUS_EMPTY = {
  active:    "You're all caught up — no active SR tasks.",
  completed: 'No completed SR tasks yet.',
  closed:    'No closed SR tasks.',
}

const PAGE_SIZE = 5

const ACTIVE_STATUSES    = ['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS']
const COMPLETED_STATUSES = ['COMPLETED', 'APPROVED']

// ── shared layout shell ───────────────────────────────────────────────────────

function PageShell({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate()
  return (
    <div className="px-4 py-6 space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">Service</p>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>
      {children}
    </div>
  )
}



// ── AM view ───────────────────────────────────────────────────────────────────

function MobileAMService() {
  const navigate = useNavigate()
  const { userId, name: userName } = useAuth()
  const { data, loading, error } = useTeamTasks()
  const [status, setStatus] = useState<'active' | 'completed' | 'closed'>('active')
  const [search, setSearch] = useState('')
  const [pageIdx, setPageIdx] = useState(0)
  const [assignSheet, setAssignSheet] = useState<{ taskId: string; type: 'accepted' | 'active'; subtitle: string } | null>(null)
  const [selectedEng, setSelectedEng] = useState('')
  const [assigning, setAssigning]     = useState(false)
  const [engineers, setEngineers]     = useState<AssignableUser[]>([])

  useEffect(() => {
    serviceApi.listAssignableUsers(['engineer'])
      .then(setEngineers)
      .catch(() => {})
  }, [])

  const allTasks = useMemo<TeamTask[]>(() => {
    if (!data) return []
    const seen = new Set<string>()
    const list: TeamTask[] = []
    const push = (t: TeamTask) => { if (!seen.has(t._id)) { seen.add(t._id); list.push(t) } }
    data.myTasks.service.forEach(push)
    data.team.forEach(g => {
      g.ownTasks.service.forEach(push)
      g.engineers.forEach(e => e.tasks.service.forEach(push))
    })
    return list
  }, [data])

  const counts = useMemo(() => ({
    active:    allTasks.filter(t => ACTIVE_STATUSES.includes(t.status)).length,
    completed: allTasks.filter(t => COMPLETED_STATUSES.includes(t.status)).length,
    closed:    allTasks.filter(t => t.status === 'CLOSED').length,
  }), [allTasks])

  const visible = useMemo(() => {
    let list = allTasks.filter(t => {
      if (status === 'active')    return ACTIVE_STATUSES.includes(t.status)
      if (status === 'completed') return COMPLETED_STATUSES.includes(t.status)
      return t.status === 'CLOSED'
    })
    if (search) {
      const q = search.toLowerCase()
      list = list.filter(t =>
        t.asset?.gensetNumber?.toLowerCase().includes(q) ||
        t.asset?.clientName?.toLowerCase().includes(q) ||
        t.asset?.engineNumber?.toLowerCase().includes(q)
      )
    }
    return list
  }, [allTasks, status, search])

  const totalPages = Math.max(1, Math.ceil(visible.length / PAGE_SIZE))
  const safePage   = Math.min(pageIdx, totalPages - 1)
  const pageItems  = visible.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)

  function changeStatus(s: 'active' | 'completed' | 'closed') { setStatus(s); setPageIdx(0) }

  function toServiceTask(t: TeamTask): ServiceTask {
    return {
      ...t,
      type: 'SERVICE' as never,
      createdAt: t.date ?? new Date(0).toISOString(),
      title: t.title,
      notes: t.notes,
      createdBy: t.assignedTo
        ? { userId: t.assignedTo.userId ?? '', name: t.assignedTo.name ?? '', role: '' }
        : undefined,
      statusHistory: [],
      actionLog: [],
    } as unknown as ServiceTask
  }

  return (
    <PageShell>
      <div className="flex justify-between items-center gap-2">
        <MobileSearchBar value={search} onChange={(v: string) => { setSearch(v); setPageIdx(0) }} />
        <button
          onClick={() => navigate('/mobile/service/new')}
          className="w-11 h-11 rounded-2xl bg-[#1E1951] flex items-center justify-center shrink-0 shadow-sm hover:bg-[#16123d] transition-colors"
        >
          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      </div>
      <MobileStatusTabs variant="service" status={status} onChange={s => changeStatus(s as 'active' | 'completed' | 'closed')} counts={counts} />

      {error   && <div className="bg-red-50 text-red-600 text-sm rounded-xl px-4 py-3">{error}</div>}
      {loading && <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>}

      {!loading && visible.length > 0 && (
        <>
          <MobilePageController page={safePage} total={totalPages} onChange={setPageIdx} />
          <div className="space-y-3">
            {pageItems.map(t => {
              const task = toServiceTask(t)
              const isReport = ['CLOSED', 'APPROVED', 'COMPLETED'].includes(t.status)
              const dest = isReport ? `/mobile/service/${t._id}/report` : `/mobile/service/${t._id}`
              const isMyTask = t.assignedTo?.userId === userId
              const onAction = isMyTask
                ? () => {
                    if (t.status === 'ASSIGNED') {
                      serviceApi.acceptEntry(t._id).catch(() => {})
                    } else if (t.status === 'ACCEPTED') {
                      serviceApi.startEntry(t._id).catch(() => {})
                    } else if (t.status === 'IN_PROGRESS') {
                      navigate(`/mobile/service/${t._id}/complete`)
                    }
                  }
                : undefined
              return (
                <MobileSRCard
                  key={t._id}
                  task={task}
                  onReport={isReport ? () => navigate(dest) : undefined}
                  onAction={!isReport ? onAction : undefined}
                  onOpenAssign={!isReport
                    ? (taskId, type, sub) => { setAssignSheet({ taskId, type, subtitle: sub }); setSelectedEng('') }
                    : undefined}
                  onPress={isReport ? () => navigate(dest) : undefined}
                />
              )
            })}
          </div>
        </>
      )}

      {!loading && visible.length === 0 && (
        <div className="bg-white rounded-2xl px-5 py-12 text-center shadow-sm">
          <p className="text-sm text-gray-400">{STATUS_EMPTY[status]}</p>
        </div>
      )}

      <MobileSelectSheet
        open={!!assignSheet}
        title="Assign to Engineer"
        subtitle={assignSheet?.subtitle}
        items={[
          ...(userId && userName
            ? [{ id: userId, label: `${userName} (You)`, sublabel: 'Area Manager', avatar: { name: userName, userId } }]
            : []),
          ...engineers.map(e => ({ id: e._id, label: e.name, sublabel: 'Engineer', avatar: { name: e.name, userId: e._id } })),
        ]}
        value={selectedEng}
        onChange={setSelectedEng}
        onClose={() => { setAssignSheet(null); setSelectedEng('') }}
        onConfirm={async () => {
          if (!assignSheet || !selectedEng) return
          setAssigning(true)
          try { await serviceApi.reassignEntry(assignSheet.taskId, selectedEng) } finally { setAssigning(false) }
          setAssignSheet(null); setSelectedEng('')
        }}
        confirmLabel="Assign"
        confirmIcon={<UserRoundCog className="w-4 h-4" />}
        confirming={assigning}
        searchPlaceholder="Search by name…"
        emptyLabel="No engineers available."
        resultLabel={n => `${n} engineer${n !== 1 ? 's' : ''} available`}
      />
    </PageShell>
  )
}

// ── dealer / engineer view ────────────────────────────────────────────────────

export default function MobileService() {
  const navigate = useNavigate()
  const { role, dealerName, userId } = useAuth()
  const [pageIdx, setPageIdx]     = useState(0)
  const [search, setSearch]       = useState('')
  const [engineers, setEngineers] = useState<AssignableUser[]>([])
  const [assignSheet, setAssignSheet] = useState<{ taskId: string; type: 'accepted' | 'active'; subtitle: string } | null>(null)
  const [selectedEng, setSelectedEng] = useState('')
  const [assigning, setAssigning]     = useState(false)

  const { loading, error, status, setStatus, data, reload } = useMyTasks()

  const isDealer = role === 'dealer'

  useEffect(() => {
    if (!isDealer) return
    serviceApi.listAssignableUsers(['engineer'])
      .then(users => setEngineers(dealerName ? users.filter(u => u.dealerName === dealerName) : users))
      .catch(() => {})
  }, [isDealer, dealerName])

  if (role === 'area_manager') return <MobileAMService />

  const tasks  = data?.service ?? []
  const counts = {
    active:    data?.counts.service.active    ?? 0,
    completed: data?.counts.service.completed ?? 0,
    closed:    data?.counts.service.closed    ?? 0,
  }

  const filtered = useMemo(() => {
    if (!search) return tasks
    const q = search.toLowerCase()
    return tasks.filter(t =>
      t.asset?.gensetNumber?.toLowerCase().includes(q) ||
      t.asset?.clientName?.toLowerCase().includes(q)
    )
  }, [tasks, search])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const safePage   = Math.min(pageIdx, totalPages - 1)
  const pageItems  = filtered.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)

  function changeStatus(s: string) { setStatus(s as typeof status); setPageIdx(0) }

  return (
    <PageShell>
      <div className="flex items-center justify-between gap-2">
        <MobileSearchBar value={search} onChange={(v: string) => { setSearch(v); setPageIdx(0) }} />
        {isDealer && (
          <button
            onClick={() => navigate('/mobile/service/new')}
            className="w-11 h-11 rounded-2xl bg-indigo-800 flex items-center justify-center shrink-0 shadow-sm hover:bg-[#16123d] transition-colors"
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
            </svg>
          </button>
        )}
      </div>
      <MobileStatusTabs variant="service" status={status} onChange={changeStatus} counts={counts} />

      {error   && <div className="bg-red-50 text-red-600 text-sm rounded-xl px-4 py-3">{error}</div>}
      {loading && <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>}

      {!loading && filtered.length > 0 && (
        <>
          <MobilePageController page={safePage} total={totalPages} onChange={setPageIdx} />
          <div className="space-y-3">
            {pageItems.map(task => {
              const isMyTask = task.assignedTo?.userId === userId
              const isReport = ['CLOSED', 'APPROVED', 'COMPLETED'].includes(task.status)
              const dest     = isReport ? `/mobile/service/${task._id}/report` : `/mobile/service/${task._id}`
              const subtitle = [task.asset?.gensetNumber, task.asset?.clientName].filter(Boolean).join(' · ')
              const onAction = (!isDealer && isMyTask && !isReport)
                ? () => {
                    if (task.status === 'ASSIGNED') {
                      const pa = task.preApproval
                      if (pa?.required && pa.status !== 'APPROVED') return
                      serviceApi.acceptEntry(task._id).then(reload).catch(() => {})
                    } else if (task.status === 'ACCEPTED') {
                      serviceApi.startEntry(task._id).then(reload).catch(() => {})
                    } else if (task.status === 'IN_PROGRESS') {
                      navigate(`/mobile/service/${task._id}/complete`)
                    }
                  }
                : undefined
              return (
                <MobileSRCard
                  key={task._id}
                  task={task}
                  isDealer={isDealer}
                  onAction={onAction}
                  onOpenAssign={isDealer && !isReport
                    ? (taskId, type) => { setAssignSheet({ taskId, type, subtitle }); setSelectedEng('') }
                    : undefined
                  }
                  onReport={isReport ? () => navigate(dest) : undefined}
                  onPress={isReport ? () => navigate(dest) : undefined}
                />
              )
            })}
          </div>
        </>
      )}

      {!loading && filtered.length === 0 && (
        <div className="bg-white rounded-2xl px-5 py-12 text-center shadow-sm">
          <p className="text-sm text-gray-400">{STATUS_EMPTY[status]}</p>
        </div>
      )}

      <MobileSelectSheet
        open={!!assignSheet}
        title={assignSheet?.type === 'active' ? 'Assign to Engineer' : 'Reassign to Engineer'}
        subtitle={assignSheet?.subtitle}
        items={engineers.map(e => ({
          id: e._id,
          label: e.name,
          sublabel: e.dealerName || 'Engineer',
          avatar: { name: e.name, userId: e._id },
        }))}
        value={selectedEng}
        onChange={setSelectedEng}
        onClose={() => { setAssignSheet(null); setSelectedEng('') }}
        onConfirm={async () => {
          if (!assignSheet || !selectedEng) return
          setAssigning(true)
          try { await serviceApi.reassignEntry(assignSheet.taskId, selectedEng); reload() } finally { setAssigning(false) }
          setAssignSheet(null); setSelectedEng('')
        }}
        confirmLabel="Assign"
        confirmIcon={<UserRoundCog className="w-4 h-4" />}
        confirming={assigning}
        searchPlaceholder="Search by name…"
        emptyLabel="No engineers available."
        resultLabel={n => `${n} engineer${n !== 1 ? 's' : ''} available`}
      />
    </PageShell>
  )
}
