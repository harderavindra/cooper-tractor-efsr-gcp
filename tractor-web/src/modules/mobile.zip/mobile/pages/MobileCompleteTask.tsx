import { useCallback, useEffect, useRef, useState } from "react";
import { useParams, useNavigate, useLocation } from "react-router-dom";
import {
  ChevronLeft,
  Bell,
  X,
  ChevronRight,
  Check,
  Pencil,
} from "lucide-react";
import { api, directGCSUpload } from "../../../shared/lib/api";
import { Avatar } from "../../../shared/components/Avatar";
import AssetInfoEditor from "../../../shared/components/AssetInfoEditor";
import FaultCodePicker, {
  type FaultCodeEntry,
} from "../../../shared/components/FaultCodePicker";
import PartsUsed, {
  type PartEntry,
} from "../../../shared/components/PartsUsed";
import PhotoUpload from "../../../shared/components/PhotoUpload";
import CompletionOtp from "../../commissioning/components/CompletionOtp";
import { saveProgress as commissioningSaveProgress } from "../../commissioning/services/commissioningApi";
import {
  VALIDATION_SECTIONS,
  type ValidationCheckEntry,
} from "../../../shared/data/validationChecks";
import { COMMISSIONING_SECTIONS } from "../../commissioning/data/commissioningChecks";
import type { CommissioningEntry } from "../../../shared/data/commissioningLogic";
import type { Asset } from "../../../shared/data/types";

const TYPE_LABEL: Record<string, string> = {
  PRE_COMMISSIONING: "Pre-Commissioning",
  COMMISSIONING: "Commissioning",
  REVALIDATION: "Revalidation",
  RE_COMMISSIONING: "Re-Commissioning",
};

const TYPE_PILL: Record<string, string> = {
  PRE_COMMISSIONING: "bg-blue-100 text-blue-700",
  COMMISSIONING: "bg-green-100 text-green-700",
  REVALIDATION: "bg-orange-100 text-orange-700",
  RE_COMMISSIONING: "bg-purple-100 text-purple-700",
};

const ELEC_FIELDS = [
  { key: "acVoltageRY", label: "AC Volt R-Y (V)" },
  { key: "acVoltageYB", label: "AC Volt Y-B (V)" },
  { key: "acVoltageBR", label: "AC Volt B-R (V)" },
  { key: "acAmpR", label: "AC Amp R (A)" },
  { key: "acAmpY", label: "AC Amp Y (A)" },
  { key: "acAmpB", label: "AC Amp B (A)" },
  { key: "loadKwR", label: "Load KW R" },
  { key: "loadKwY", label: "Load KW Y" },
  { key: "loadKwB", label: "Load KW B" },
  { key: "totalKwLoad", label: "Total KW Load" },
  { key: "loadPercentage", label: "Load %" },
];
const ENG_FIELDS = [
  { key: "rpm", label: "RPM" },
  { key: "frequency", label: "Frequency (Hz)" },
  { key: "dcVoltage", label: "DC Voltage (V)" },
  { key: "oilPressure", label: "Oil Pressure" },
  { key: "coolantTemperature", label: "Coolant Temp (°C)" },
  { key: "defLevelPercentage", label: "DEF Level (%)" },
];

function fmt12(d: Date) {
  return d.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}
function fmtDay(d: Date) {
  return d
    .toLocaleDateString("en-IN", { day: "2-digit", month: "short" })
    .toUpperCase();
}
function fmtDuration(ms: number) {
  const m = Math.floor(ms / 60000);
  const h = Math.floor(m / 60);
  return h > 0 ? `${h} hr ${m % 60} min` : `${m} min`;
}

// ── Shared button components ───────────────────────────────────────────────────

function BtnNext({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-12 h-12 flex items-center justify-center rounded-full bg-purple-950 text-white text-sm font-bold  transition-colors"
    >
      <ChevronRight size={32} />
    </button>
  );
}
function BtnBack({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-12 h-12 flex items-center justify-center rounded-full bg-white text-gray-400 text-sm font-bold  transition-colors"
    >
      <ChevronLeft size={32} />
    </button>
  );
}

function CheckRow({
  idx,
  label,
  value,
  comment,
  onChange,
  onCommentChange,
  onSave,
}: {
  idx: number;
  label: string;
  value?: string;
  comment?: string;
  onChange: (v: "OK" | "Not OK") => void;
  onCommentChange?: (c: string) => void;
  onSave?: () => Promise<unknown>;
}) {
  const [editing, setEditing] = useState(!comment);
  const [saving, setSaving] = useState(false);

  // when value switches away from Not OK, reset edit state
  const showComment = value === "Not OK";

  async function handleSave() {
    if (!onSave) return;
    setSaving(true);
    try {
      await onSave();
      setEditing(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="p-2 even:bg-gray-50">
      <div className="flex items-center gap-1">
        <span className="text-xs text-gray-600 w-5 shrink-0">
          {String(idx).padStart(2, "0")}
        </span>
        <p className="flex-1 text-base text-gray-900 leading-snug">{label}</p>
        <div className="flex gap-1 shrink-0 bg-gray-100 border border-gray-300 rounded-xl p-1">
          <button
            onClick={() => {
              onChange("Not OK");
              setEditing(true);
            }}
            className={`w-12 h-12 rounded-l-xl border flex items-center justify-center transition-colors ${
              value === "Not OK"
                ? "bg-red-500/70 border-red-600 text-white"
                : "bg-white border border-gray-300 text-gray-300"
            }`}
          >
            <X className="w-5 h-5" />
          </button>
          <button
            onClick={() => onChange("OK")}
            className={`w-12 h-12 rounded-r-xl border flex items-center justify-center transition-colors ${
              value === "OK"
                ? "bg-green-500/80 text-white border-green-600"
                : "bg-white border-gray-200 text-gray-300"
            }`}
          >
            <Check className="w-5 h-5" />
          </button>
        </div>
      </div>

      {showComment && (
        <div className="mt-2 ">
          {editing ? (
            <div className="flex gap-2 items-start">
              <textarea
                rows={2}
                value={comment ?? ""}
                onChange={(e) => onCommentChange?.(e.target.value)}
                placeholder="Add comment…"
                className="flex-1 text-sm border border-red-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-red-300 resize-none bg-red-50 placeholder-red-300 text-gray-700"
              />
              <button
                onClick={handleSave}
                disabled={saving}
                className="shrink-0 w-9 h-9 rounded-xl bg-red-500 text-white flex items-center justify-center hover:bg-red-600 disabled:opacity-50 transition-colors"
              >
                {saving ? (
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
              </button>
            </div>
          ) : (
            <div className="flex items-start gap-2 bg-red-50 border border-red-100 rounded-xl px-3 py-2">
              <p className="flex-1 text-sm text-gray-700 leading-snug">
                {comment || (
                  <span className="text-red-300 italic">No comment</span>
                )}
              </p>
              <button
                onClick={() => setEditing(true)}
                className="shrink-0 w-7 h-7 rounded-lg flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-100 transition-colors"
              >
                <Pencil className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function MobileCompleteTask() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const returnTo =
    (location.state as { returnTo?: string } | null)?.returnTo ??
    "/mobile/commissioning";

  const [entry, setEntry] = useState<CommissioningEntry | null>(null);
  const [asset, setAsset] = useState<Asset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [step, setStep] = useState(1);
  const [success, setSuccess] = useState(false);

  const [faultCodes, setFaultCodes] = useState<FaultCodeEntry[]>([]);
  const [partsUsed, setPartsUsed] = useState<PartEntry[]>([]);
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [validationChecks, setValidationChecks] = useState<
    Record<string, ValidationCheckEntry>
  >({});
  const [commissioningChecks, setCommissioningChecks] = useState<Record<string, string>>({});
  const [readings, setReadings] = useState<Record<string, string>>({});
  const [commissioningDate, setCommissioningDate] = useState(
    new Date().toISOString().slice(0, 10),
  );

  const [uploading, setUploading] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [startedAt, setStartedAt] = useState<Date | null>(null);
  const [completedAt, setCompletedAt] = useState<Date | null>(null);

  const faultCodesRef = useRef(faultCodes);
  faultCodesRef.current = faultCodes;
const scrollRef = useRef<HTMLDivElement>(null);

  const handleFaultCodeSave = useCallback(async () => {
    await commissioningSaveProgress(id!, {
      faultCodes: faultCodesRef.current.map((fc) => ({
        codeId: fc.codeId,
        observation: fc.observation,
        rootCause: fc.rootCause,
      })),
    });
  }, [id]);

  const handlePartsAutoSave = useCallback(async (parts: PartEntry[]) => {
    await commissioningSaveProgress(id!, {
      partsUsed: parts.map(p => ({ partId: p.partId, quantity: p.quantity })),
    })
  }, [id])

  useEffect(() => {
    if (!id) return;
    api
      .get<
        CommissioningEntry & {
          commissioningChecks?: Record<string, string>;
          validationChecks?: Record<string, unknown>;
        }
      >(`/api/commissioning/${id}`)
      .then((e) => {
        setEntry(e);
        if (e.date)
          setCommissioningDate(new Date(e.date).toISOString().slice(0, 10));
        // infer start time from first IN_PROGRESS status history entry
        const ipEntry = (
          e.statusHistory as { status: string; changedAt: string }[] | undefined
        )?.find((h) => h.status === "IN_PROGRESS");
        setStartedAt(
          ipEntry ? new Date(ipEntry.changedAt) : new Date(e.createdAt),
        );

        if (
          e.commissioningChecks &&
          Object.keys(e.commissioningChecks).length > 0
        )
          setCommissioningChecks(e.commissioningChecks);
        if (e.validationChecks && Object.keys(e.validationChecks).length > 0)
          setValidationChecks(
            e.validationChecks as Record<string, ValidationCheckEntry>,
          );
        if (e.gensetReadings) {
          // eslint-disable-next-line @typescript-eslint/no-unused-vars
          const { savedBy, savedAt, commissioningId, ...rest } =
            e.gensetReadings as Record<string, unknown>;
          setReadings(
            Object.fromEntries(
              Object.entries(rest)
                .filter(([, v]) => v != null && v !== "")
                .map(([k, v]) => [k, String(v)]),
            ),
          );
        }
        const fc = (e as unknown as Record<string, unknown>).faultCodes as
          | {
              codeId: Record<string, string>;
              observation: string;
              rootCause: string;
            }[]
          | undefined;
        if (fc?.length) {
          setFaultCodes(
            fc.map((f) => ({
              codeId: f.codeId._id,
              code: f.codeId.code,
              description: f.codeId.description,
              category: f.codeId.category,
              subCategory: f.codeId.subCategory,
              priority: f.codeId.priority,
              observation: f.observation,
              rootCause: f.rootCause,
              correctiveAction: "",
            })),
          );
        }
        const pu = (e as unknown as Record<string, unknown>).partsUsed as
          | { partId: Record<string, string>; quantity: number }[]
          | undefined;
        if (pu?.length) {
          setPartsUsed(
            pu.map((p) => ({
              partId: p.partId._id,
              code: p.partId.code,
              name: p.partId.name,
              unit: p.partId.unit,
              category: p.partId.category,
              subCategory: p.partId.subCategory,
              quantity: p.quantity,
            })),
          );
        }
        return api.get<Asset>(`/api/assets/${e.assetId}`);
      })
      .then((a) => setAsset(a))
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [id]);

  // ── Derived config ─────────────────────────────────────────────────────────
  const isRevalidation = entry?.type === "REVALIDATION";
  const isCommissioning =
    entry?.type === "COMMISSIONING" || entry?.type === "RE_COMMISSIONING";
  const hasChecks = isRevalidation || isCommissioning;

  // Step mapping: always 6 steps when hasChecks, else 5
  const S = hasChecks
    ? { ASSET: 1, CHECKS: 2, READINGS: 3, FAULT: 4, PARTS: 5, PHOTOS: 6 }
    : { ASSET: 1, CHECKS: -1, READINGS: 2, FAULT: 3, PARTS: 4, PHOTOS: 5 };
  const TOTAL = hasChecks ? 6 : 5;

  function scrollTop() {
    scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
  }
  function goNext() {
    if (step < TOTAL) {
      setStep((s) => s + 1);
      scrollTop();
    }
  }
  function goPrev() {
    if (step > 1) {
      setStep((s) => s - 1);
      scrollTop();
    }
  }

  // ── Complete task ──────────────────────────────────────────────────────────
  async function handleComplete() {
    setUploading(true);
    setSaveError("");
    try {
      if (photoFiles.length > 0) {
        const urls = await Promise.all(
          photoFiles.map((f) => directGCSUpload(f, "commissioning", f.type)),
        );
        await api.post(`/api/commissioning/${id}/photos/confirm`, {
          gcsUrls: urls,
        });
      }
      // save readings
      if (Object.keys(readings).length > 0) {
        await commissioningSaveProgress(id!, { gensetReadings: readings });
      }
      await api.put(`/api/commissioning/${id}/complete`, {
        date: commissioningDate,
        faultCodes: faultCodes.map((fc) => ({
          codeId: fc.codeId,
          observation: fc.observation?.trim() || undefined,
          rootCause: fc.rootCause?.trim() || undefined,
        })),
        partsUsed: partsUsed.map((p) => ({
          partId: p.partId,
          quantity: p.quantity,
        })),
        ...(isRevalidation && Object.keys(validationChecks).length > 0
          ? { validationChecks }
          : {}),
        ...(isCommissioning && Object.keys(commissioningChecks).length > 0
          ? { commissioningChecks }
          : {}),
      });
      setCompletedAt(new Date());
      setSuccess(true);
    } catch (err) {
      setSaveError(
        err instanceof Error ? err.message : "Failed to complete task",
      );
    } finally {
      setUploading(false);
    }
  }

  // ── Loading / error states ─────────────────────────────────────────────────
  if (loading || error || !entry || !asset) {
    return (
      <div className="flex flex-col h-full">
        <div className="shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
          <button
            onClick={() => navigate(returnTo)}
            className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
          <p className="text-base font-bold text-gray-900 uppercase tracking-widest">
            Task
          </p>
          <div className="w-9" />
        </div>
        <div className="flex-1 flex items-center justify-center p-6">
          {loading ? (
            <svg
              className="w-7 h-7 animate-spin text-gray-300"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle
                className="opacity-25"
                cx="12"
                cy="12"
                r="10"
                stroke="currentColor"
                strokeWidth="4"
              />
              <path
                className="opacity-75"
                fill="currentColor"
                d="M4 12a8 8 0 018-8v8H4z"
              />
            </svg>
          ) : (
            <p className="text-sm text-red-500">{error || "Task not found."}</p>
          )}
        </div>
      </div>
    );
  }

  const typePill = TYPE_PILL[entry.type] ?? "bg-gray-100 text-gray-500";
  const typeLabel = TYPE_LABEL[entry.type] ?? entry.type;

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-full bg-[#faf0eb]">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
        <button
          onClick={() => navigate(returnTo)}
          className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-base font-bold tracking-widest text-gray-900 uppercase">
          {success ? typeLabel : "TASK"}
        </p>
        <button className="relative w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center shrink-0">
          <Bell className="w-4 h-4 text-gray-500" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500" />
        </button>
      </div>

      {/* Step dots + task summary card */}
      {!success && (
        <div className="shrink-0 px-4 pt-4 pb-2 space-y-3">
          {/* Step navigation */}
          <div className="flex items-center gap-2 justify-center">
            <button
              onClick={goPrev}
              disabled={step === 1}
              className="w-8 h-8 rounded-full bg-white  flex items-center justify-center disabled:opacity-30 shrink-0"
            >
              <ChevronLeft className="w-4 h-4 text-gray-600" />
            </button>

            {Array.from({ length: TOTAL }, (_, i) => {
              const n = i + 1;
              const done = n < step;
              const current = n === step;
              return (
                <button
                  key={n}
                  disabled={n > step}
                  onClick={() => n < step && setStep(n)}
                  className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold transition-colors shrink-0 ${
                    current
                      ? "bg-[#E76124] text-white "
                      : done
                        ? "bg-gray-800 text-white"
                        : "bg-white text-gray-400 "
                  }`}
                >
                  {done ? (
                    <svg
                      className="w-4 h-4"
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={3}
                        d="M5 13l4 4L19 7"
                      />
                    </svg>
                  ) : (
                    n
                  )}
                </button>
              );
            })}

            <button
              onClick={goNext}
              disabled={step === TOTAL}
              className="w-8 h-8 rounded-full bg-white  flex items-center justify-center disabled:opacity-30 shrink-0"
            >
              <ChevronLeft className="w-4 h-4 text-gray-600 rotate-180" />
            </button>
          </div>
        </div>
      )}

      {/* Scrollable content */}
      <div
        ref={scrollRef}
        className="flex-1 overflow-y-auto px-4 pb-8 space-y-4 pt-2"
      >
        {/* Type pill + avatars + genset serial */}

        <div className="bg-white rounded-2xl px-4 py-3  space-y-2">
          <div className="flex items-center justify-between">
            <span
              className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${typePill}`}
            >
              {typeLabel}
            </span>
            <div className="flex -space-x-2">
              {(entry.createdBy as
                | { name: string; userId: string }
                | undefined) && (
                <Avatar
                  name={(entry.createdBy as { name: string }).name}
                  userId={(entry.createdBy as { userId: string }).userId}
                  size="sm"
                  showPopover={true}
                  className="ring-2 ring-white"
                />
              )}
              {(entry.assignedTo as
                | { name: string; userId: string }
                | undefined) &&
                (entry.assignedTo as { userId: string }).userId !==
                  (entry.createdBy as { userId: string } | undefined)
                    ?.userId && (
                  <Avatar
                    name={(entry.assignedTo as { name: string }).name}
                    userId={(entry.assignedTo as { userId: string }).userId}
                    size="sm"
                    showPopover={true}
                    className="ring-2 ring-white"
                  />
                )}
            </div>
          </div>
          <div className="flex items-center gap-2 bg-indigo-50 rounded-xl px-3 py-2">
            <span className="font-bold text-gray-900 text-sm font-mono">
              {asset.gensetNumber ?? "—"}
            </span>
            {asset.engineNumber && (
              <span className="text-gray-400 text-xs">
                {asset.engineNumber}
              </span>
            )}
          </div>
        </div>
        {/* ── Step 1: Asset Info ── */}
        {!success && step === S.ASSET && (
          <>
            <AssetInfoEditor
              asset={asset}
              onUpdate={setAsset}
              sectionIds={["genset", "alternator", "service"]}
            />
            <div className="bg-white rounded-2xl px-4 py-4 ">
              <p className="text-xs text-gray-400 uppercase tracking-wide mb-2">
                Commissioning Date
              </p>
              <input
                type="date"
                value={commissioningDate}
                onChange={(e) => setCommissioningDate(e.target.value)}
                className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124]"
              />
            </div>
            <div className="flex justify-end gap-3">
              <BtnNext onClick={goNext} />
            </div>
          </>
        )}

        {/* ── Step 2: Checks ── */}
        {!success && step === S.CHECKS && S.CHECKS !== -1 && (
          <>
            {isRevalidation &&
              VALIDATION_SECTIONS.map((sec) => (
                <div
                  key={sec.letter}
                  className="bg-white rounded-4xl  overflow-hidden"
                >
                  <div className="flex items-center gap-2 px-4 py-3 bg-indigo-50 mx-4 mt-4 rounded-full">
                    <span className="w-6 h-6 rounded-full bg-[#E76124] text-white text-xs font-bold flex items-center justify-center shrink-0">
                      {sec.letter}
                    </span>
                    <p className="text-sm font-bold text-gray-800">
                      {sec.title}
                    </p>
                  </div>
                  <div className="divide-y divide-gray-50 ">
                    {sec.items.map((item, idx) => (
                      <CheckRow
                        key={item.id}
                        idx={idx + 1}
                        label={item.label}
                        value={validationChecks[item.id]?.value}
                        onChange={(v) =>
                          setValidationChecks((prev) => ({
                            ...prev,
                            [item.id]: { ...prev[item.id], value: v },
                          }))
                        }
                      />
                    ))}
                  </div>
                </div>
              ))}

            {isCommissioning &&
              COMMISSIONING_SECTIONS.filter((s) => s.letter !== "D").map(
                (sec) => (
                  <div
                    key={sec.letter}
                    className="bg-white rounded-2xl  overflow-hidden"
                  >
                    <div className="flex items-center gap-2 px-4 py-3 bg-indigo-50">
                      <span className="w-6 h-6 rounded-full bg-[#E76124] text-white text-xs font-bold flex items-center justify-center shrink-0">
                        {sec.letter}
                      </span>
                      <p className="text-sm font-bold text-gray-800">
                        {sec.title}
                      </p>
                    </div>
                    <div className="divide-y divide-gray-50 px-4">
                      {sec.items.map((item, idx) => (
                        <CheckRow
                          key={item.id}
                          idx={idx + 1}
                          label={item.label}
                          value={commissioningChecks[item.id]}
                          comment={commissioningChecks[`${item.id}_comment`]}
                          onChange={(v) =>
                            setCommissioningChecks((prev) => ({ ...prev, [item.id]: v }))
                          }
                          onCommentChange={(c) =>
                            setCommissioningChecks((prev) => ({ ...prev, [`${item.id}_comment`]: c }))
                          }
                          onSave={() =>
                            commissioningSaveProgress(id!, { commissioningChecks })
                          }
                        />
                      ))}
                    </div>
                  </div>
                ),
              )}

            <div className="flex justify-between gap-3">
              <BtnBack onClick={goPrev} />
              <BtnNext onClick={goNext} />
            </div>
          </>
        )}

        {/* ── Step 3 (or 2): Readings ── */}
        {!success && step === S.READINGS && (
          <>
            <div className="bg-white rounded-2xl  px-4 py-4">
              <p className="text-sm font-bold text-gray-800 mb-4">
                Electrical Readings
              </p>
              <div className="grid grid-cols-2 gap-3">
                {ELEC_FIELDS.map((f) => (
                  <div key={f.key}>
                    <label className="text-xs text-gray-400 uppercase tracking-wide block mb-1">
                      {f.label}
                    </label>
                    <input
                      value={readings[f.key] ?? ""}
                      onChange={(e) =>
                        setReadings((prev) => ({
                          ...prev,
                          [f.key]: e.target.value,
                        }))
                      }
                      placeholder="—"
                      inputMode="decimal"
                      className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124]"
                    />
                  </div>
                ))}
              </div>
            </div>
            <div className="bg-white rounded-2xl  px-4 py-4">
              <p className="text-sm font-bold text-gray-800 mb-4">
                Engine Parameters
              </p>
              <div className="grid grid-cols-2 gap-3">
                {ENG_FIELDS.map((f) => (
                  <div key={f.key}>
                    <label className="text-xs text-gray-400 uppercase tracking-wide block mb-1">
                      {f.label}
                    </label>
                    <input
                      value={readings[f.key] ?? ""}
                      onChange={(e) =>
                        setReadings((prev) => ({
                          ...prev,
                          [f.key]: e.target.value,
                        }))
                      }
                      placeholder="—"
                      inputMode="decimal"
                      className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124]"
                    />
                  </div>
                ))}
                <div>
                  <label className="text-xs text-gray-400 uppercase tracking-wide block mb-1">
                    Oil Level
                  </label>
                  <select
                    value={readings.oilLevel ?? ""}
                    onChange={(e) =>
                      setReadings((prev) => ({
                        ...prev,
                        oilLevel: e.target.value,
                      }))
                    }
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124] bg-white"
                  >
                    <option value="">—</option>
                    <option value="OK">OK</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs text-gray-400 uppercase tracking-wide block mb-1">
                    Coolant Level
                  </label>
                  <select
                    value={readings.coolantLevel ?? ""}
                    onChange={(e) =>
                      setReadings((prev) => ({
                        ...prev,
                        coolantLevel: e.target.value,
                      }))
                    }
                    className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124] bg-white"
                  >
                    <option value="">—</option>
                    <option value="OK">OK</option>
                    <option value="Low">Low</option>
                  </select>
                </div>
              </div>
            </div>
            <div className="flex gap-3">
              <BtnBack onClick={goPrev} />
              <BtnNext onClick={goNext} />
            </div>
          </>
        )}

        {/* ── Fault Codes ── */}
        {!success && step === S.FAULT && (
          <>
            <div className=" ">
              <p className="text-sm font-bold text-gray-800 mb-3">
                Complaint Codes
              </p>
              <FaultCodePicker
                entries={faultCodes}
                onChange={setFaultCodes}
                onSave={handleFaultCodeSave}
              />
            </div>
            <div className="flex justify-between gap-3">
              <BtnBack onClick={goPrev} />
              <BtnNext onClick={goNext} />
            </div>
          </>
        )}

        {/* ── Parts Used ── */}
        {!success && step === S.PARTS && (
          <>
            <p className="text-sm font-bold text-gray-800 mb-3">Parts Used</p>

            <div className="">
              <PartsUsed
                entries={partsUsed}
                onChange={setPartsUsed}
                onAutoSave={handlePartsAutoSave}
              />
            </div>
            <div className="flex gap-3 justify-between">
              <BtnBack onClick={goPrev} />
              <BtnNext onClick={goNext} />
            </div>
          </>
        )}

        {/* ── Photos + Complete ── */}
        {!success && step === S.PHOTOS && (
          <>
            <div className="bg-white rounded-2xl  px-4 py-4">
              <p className="text-sm font-bold text-gray-800 mb-3">Photos</p>
              <PhotoUpload files={photoFiles} onChange={setPhotoFiles} />
            </div>
         
            {saveError && (
              <p className="text-sm text-red-500 px-1">{saveError}</p>
            )}
            <BtnBack onClick={goPrev} />
            <button
              onClick={handleComplete}
              disabled={uploading}
              className="w-full py-4 rounded-2xl bg-green-600 text-white text-sm font-bold tracking-widest uppercase disabled:opacity-50 hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
            >
              {uploading ? (
                <>
                  <svg
                    className="w-4 h-4 animate-spin"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8v8z"
                    />
                  </svg>
                  Completing…
                </>
              ) : (
                "Complete The Task"
              )}
            </button>
          </>
        )}

        {/* ── Success + OTP ── */}
        {success && (
          <div className="flex flex-col items-center gap-6 py-4">
            {/* Animated orb */}
            <div
              className="w-36 h-36 rounded-full bg-gray-900 flex items-center justify-center  overflow-hidden"
              style={{ animation: "none" }}
            >
              <svg
                viewBox="0 0 160 160"
                className="w-28 h-28"
                style={{ animation: "spin 6s linear infinite" }}
              >
                <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
                <defs>
                  <linearGradient id="g1" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#f97316" />
                    <stop offset="100%" stopColor="#f59e0b" />
                  </linearGradient>
                </defs>
                {Array.from({ length: 14 }, (_, i) => {
                  const a = (i / 14) * Math.PI * 2;
                  const r1 = 28,
                    r2 = 55 + (i % 3) * 10;
                  return (
                    <line
                      key={i}
                      x1={80 + Math.cos(a) * r1}
                      y1={80 + Math.sin(a) * r1}
                      x2={80 + Math.cos(a) * r2}
                      y2={80 + Math.sin(a) * r2}
                      stroke="url(#g1)"
                      strokeWidth="3.5"
                      strokeLinecap="round"
                      opacity="0.85"
                    />
                  );
                })}
              </svg>
            </div>

            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">Successfully</p>
              <p className="text-sm text-gray-400 mt-1">
                You have successfully completed the task
              </p>
            </div>

            {/* Duration display */}
            {startedAt && completedAt && (
              <div className="flex items-stretch gap-2 w-full">
                <div className="flex-1 bg-gray-900 text-white rounded-2xl px-3 py-3 text-center">
                  <p className="text-[10px] text-gray-400 font-medium">
                    {fmtDay(startedAt)}
                  </p>
                  <p className="text-xs font-bold mt-0.5">{fmt12(startedAt)}</p>
                </div>
                <div className="flex-1 bg-[#fde9df] text-gray-900 rounded-2xl px-3 py-3 text-center flex items-center justify-center">
                  <p className="text-sm font-bold">
                    {fmtDuration(completedAt.getTime() - startedAt.getTime())}
                  </p>
                </div>
                <div className="flex-1 bg-gray-900 text-white rounded-2xl px-3 py-3 text-center">
                  <p className="text-[10px] text-gray-400 font-medium">
                    {fmtDay(completedAt)}
                  </p>
                  <p className="text-xs font-bold mt-0.5">
                    {fmt12(completedAt)}
                  </p>
                </div>
              </div>
            )}

            {/* OTP */}
            <div className="w-full bg-white rounded-2xl  p-4">
              {asset.primaryContactNumber && (
                <div className="flex items-center gap-2 mb-4 px-3 py-2.5 bg-blue-50 rounded-xl border border-blue-100">
                  <svg
                    className="w-4 h-4 text-blue-400 shrink-0"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"
                    />
                  </svg>
                  <div>
                    <p className="text-[10px] text-blue-400 font-medium uppercase tracking-wide">
                      OTP sent to
                    </p>
                    <p className="text-sm font-semibold text-blue-700">
                      {asset.primaryContactNumber}
                    </p>
                  </div>
                </div>
              )}
              <CompletionOtp
                entryId={id!}
                onVerified={() => navigate(returnTo)}
                saving={false}
              />
            </div>

            <button
              onClick={() => navigate(returnTo)}
              className="w-full py-3.5 rounded-2xl border border-gray-200 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 transition-colors"
            >
              Back to Tasks
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
