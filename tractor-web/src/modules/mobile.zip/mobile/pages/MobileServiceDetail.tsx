import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  ChevronLeft,
  MapPin,
  CheckCircle2,
  XCircle,
  Clock,
  X,
  Check,
  RefreshCcw,
  AlertCircle,
  Star,
  Bell,
  ChevronDown,
  Wrench,
  ChevronRight,
  BookmarkCheck,
} from "lucide-react";
import { useAuth } from "../../../shared/context/AuthContext";
import { serviceApi } from "../../service/services/serviceApi";
import type { DetailedServiceEntry } from "../../service/types";
import type { Asset } from "../../../shared/data/types";
import { timeAgo } from "../../../shared/utils/dateUtils";
import { Avatar } from "../../../shared/components/Avatar";
import {
  CATEGORY_GROUPS,
  CAT_INFO,
  type SRCategory,
} from "../../service/data/serviceCategories";

export default function MobileServiceDetail() {
  const { entryId } = useParams<{ entryId: string }>();
  const navigate = useNavigate();
  const { role, userId } = useAuth();

  const [entry, setEntry] = useState<DetailedServiceEntry | null>(null);
  const [asset, setAsset] = useState<Asset | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [note, setNote] = useState("");
  const [rejectOpen, setRejectOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  type EditFC = {
    codeId: string;
    code: string;
    description: string;
    observation: string;
    rootCause: string;
    correctiveAction: string;
  };
  type EditPart = {
    partId: string;
    name: string;
    code: string;
    unit: string;
    quantity: number;
  };
  const [resubmitOpen, setResubmitOpen] = useState(false);
  const [editFCs, setEditFCs] = useState<EditFC[]>([]);
  const [editParts, setEditParts] = useState<EditPart[]>([]);
  const [resubmitting, setResubmitting] = useState(false);
  const [resubmitError, setResubmitError] = useState("");
  const [openSections, setOpenSections] = useState<Set<string>>(new Set());

  const [partSaving, setPartSaving] = useState<Record<string, boolean>>({});
  const [rejectingPartId, setRejectingPartId] = useState<string | null>(null);
  const [rejectComment, setRejectComment] = useState('');
  const [partReviewError, setPartReviewError] = useState("");
  const [actioning, setActioning] = useState(false);

  function toggleSection(id: string) {
    setOpenSections((prev) => {
      const s = new Set(prev);
      if (s.has(id)) s.delete(id);
      else s.add(id);
      return s;
    });
  }

  useEffect(() => {
    if (!entryId) return;
    serviceApi
      .getEntry(entryId)
      .then((e) => {
        setEntry(e);
        return serviceApi.getAsset(e.assetId);
      })
      .then(setAsset)
      .catch((err) =>
        setError(err instanceof Error ? err.message : "Failed to load"),
      )
      .finally(() => setLoading(false));
  }, [entryId]);

  async function decide(approved: boolean) {
    if (!entry) return;
    if (!approved && !note.trim()) {
      setSubmitError("Rejection note is required.");
      return;
    }
    setSubmitting(true);
    setSubmitError("");
    try {
      const wa = entry.workApproval;
      if (wa?.status === "PENDING_AM") {
        await serviceApi.amReviewWorkApproval(entry._id, {
          decision: approved ? "APPROVED" : "REJECTED",
          note: note.trim() || undefined,
        });
      } else if (wa?.status === "PENDING_RSM") {
        await serviceApi.rsmConfirmWorkApproval(entry._id, {
          decision: approved ? "CONFIRMED" : "REJECTED",
          note: note.trim() || undefined,
        });
      }
      navigate(-1);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : "Failed to submit");
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <p className="text-sm text-gray-400">Loading…</p>
      </div>
    );
  }

  if (error || !entry) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100 p-4">
        <p className="text-sm text-red-500">{error || "Entry not found."}</p>
      </div>
    );
  }

  const wa = entry.workApproval;
  const canAMReview = role === "area_manager" && wa?.status === "PENDING_AM";
  const canRSMReview = role === "rsm" && wa?.status === "PENDING_RSM";
  const showActions = canAMReview || canRSMReview;
  const canResubmit =
    wa?.status === "REJECTED" && !!userId && wa.requestedBy?.userId === userId;

  function openResubmit() {
    setEditFCs(
      (entry!.faultCodes ?? []).map((fc) => ({
        codeId: (fc.codeId as unknown as { _id: string })._id,
        code: fc.codeId.code,
        description: fc.codeId.description,
        observation: fc.observation ?? "",
        rootCause: fc.rootCause ?? "",
        correctiveAction: fc.correctiveAction ?? "",
      })),
    );
    setEditParts(
      (entry!.partsUsed ?? []).map((p) => ({
        partId: p.partId._id,
        name: p.partId.name,
        code: p.partId.code,
        unit: p.partId.unit,
        quantity: p.quantity,
      })),
    );
    setResubmitError("");
    setResubmitOpen(true);
  }

  async function handleResubmit() {
    if (!entry || !entryId) return;
    setResubmitting(true);
    setResubmitError("");
    try {
      await serviceApi.requestWorkApproval(entryId, {
        category: entry.category ?? "",
        subCategory: entry.subCategory ?? "",
        faultCodes: editFCs.map((fc) => ({
          codeId: fc.codeId,
          observation: fc.observation,
          rootCause: fc.rootCause,
          correctiveAction: fc.correctiveAction,
        })),
        partsUsed: editParts.map((p) => ({
          partId: p.partId,
          quantity: p.quantity,
        })),
      });
      navigate(-1);
    } catch (err) {
      setResubmitError(
        err instanceof Error ? err.message : "Failed to resubmit",
      );
      setResubmitting(false);
    }
  }

  async function acknowledge() {
    if (!entryId) return;
    setActioning(true);
    try {
      await serviceApi.acceptEntry(entryId);
      const updated = await serviceApi.getEntry(entryId);
      setEntry(updated);
    } catch {
    } finally {
      setActioning(false);
    }
  }

  async function startWork() {
    if (!entryId) return;
    setActioning(true);
    try {
      await serviceApi.startEntry(entryId);
      const updated = await serviceApi.getEntry(entryId);
      setEntry(updated);
    } catch {
    } finally {
      setActioning(false);
    }
  }

  async function savePartDecision(partId: string, decision: "APPROVED" | "REJECTED", reason?: string) {
    if (!entryId) return;
    setPartSaving(prev => ({ ...prev, [partId]: true }));
    setPartReviewError("");
    try {
      await serviceApi.reviewPartApproval(entryId, [{ partId, decision, reason }]);
      const refreshed = await serviceApi.getEntry(entryId);
      setEntry(refreshed);
      setRejectingPartId(null);
      setRejectComment('');
    } catch (err) {
      setPartReviewError(err instanceof Error ? err.message : "Failed to submit");
    } finally {
      setPartSaving(prev => { const s = { ...prev }; delete s[partId]; return s });
    }
  }

  const addr = asset
    ? [
        asset.address?.line1,
        asset.address?.city,
        asset.address?.district,
        asset.address?.state,
        asset.address?.pinCode,
      ]
        .filter(Boolean)
        .join(", ")
    : "";

  const cat = entry.category as SRCategory | undefined;
  const catLabel = cat
    ? (CATEGORY_GROUPS.flatMap(
        (g) => g.items as readonly { letter: SRCategory; label: string }[],
      ).find((i) => i.letter === cat)?.label ?? cat)
    : null;

  return (
    <>
      <div className="px-4 pt-6 pb-32 space-y-3">
        {/* Header */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate(-1)}
            className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0"
          >
            <ChevronLeft className="w-5 h-5 text-gray-600" />
          </button>
          <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">
            Service Details
          </p>
          <button className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
            <Bell className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        {/* Asset card */}
        <div className="bg-white rounded-2xl shadow-sm px-4 py-4 space-y-3">
          {/* category pill + stacked avatars */}
          {entry.srNumber && (
            <span className="inline-block bg-indigo-800 px-3 py-1.5 rounded-full font-mono text-xs text-gray-100 tracking-widest">
              {entry.srNumber}
            </span>
          )}

          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center shrink-0">
              <Wrench className="w-6 h-6 text-indigo-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-gray-900 text-base leading-tight">
                {asset?.gensetNumber ?? "—"}
              </p>
              {asset?.engineNumber && (
                <p className="text-sm text-gray-400 mt-0.5">
                  {asset.engineNumber}
                </p>
              )}
            </div>
            {/* Stacked avatars — created by + working by */}
            <div className="flex -space-x-2.5 shrink-0 mt-0.5">
              {entry.createdBy && (
                <div
                  className="ring-2 ring-white rounded-full"
                  title={`Created by ${entry.createdBy.name}`}
                >
                  <Avatar
                    name={entry.createdBy.name}
                    userId={entry.createdBy.userId}
                    photo={entry.createdBy.profilePic}
                    size="lg"
                    showPopover
                  />
                </div>
              )}
              {entry.assignedTo && (
                <div
                  className="ring-2 ring-white rounded-full"
                  title={`Working by ${entry.assignedTo.name}`}
                >
                  <Avatar
                    name={entry.assignedTo.name}
                    userId={entry.assignedTo.userId}
                    photo={entry.assignedTo.profilePic}
                    size="lg"
                    showPopover
                  />
                </div>
              )}
            </div>
          </div>
          {(asset?.clientName || addr) && (
            <div className="flex items-start gap-2">
              <MapPin className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
              <div>
                {asset?.clientName && (
                  <p className="text-sm font-bold text-gray-900">
                    {asset.clientName}
                  </p>
                )}
                {addr && (
                  <p className="text-xs text-gray-400 leading-relaxed">
                    {addr}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Status timeline */}
        {(() => {
          const STEPS: { key: string; label: string }[] = [
            { key: "ASSIGNED", label: "Assigned" },
            { key: "ACCEPTED", label: "Accepted" },
            { key: "IN_PROGRESS", label: "Active" },
            { key: "COMPLETED", label: "Completed" },
            { key: "CLOSED", label: "Closed" },
          ];
          const STATUS_IDX: Record<string, number> = {
            ASSIGNED: 0,
            ACCEPTED: 1,
            IN_PROGRESS: 2,
            COMPLETED: 3,
            APPROVED: 3,
            CLOSED: 4,
          };
          const cur = STATUS_IDX[entry.status] ?? 0;
          const N = STEPS.length;

          function fmtDate(iso?: string) {
            if (!iso) return null;
            return new Date(iso).toLocaleDateString("en-IN", {
              day: "numeric",
              month: "short",
            });
          }
          function fmtDur(from?: string, to?: string) {
            if (!from || !to) return null;
            const ms = new Date(to).getTime() - new Date(from).getTime();
            if (ms <= 0) return null;
            const m = Math.floor(ms / 60000);
            if (m < 60) return `${m}m`;
            const h = Math.floor(m / 60);
            if (h < 24) return `${h}h`;
            return `${Math.floor(h / 24)}d`;
          }

          const segDur = [
            fmtDur(entry.date, entry.acceptedAt),
            null,
            fmtDur(entry.acceptedAt, entry.completedAt),
            fmtDur(entry.completedAt, entry.closedAt),
          ];
          const assignedDate = fmtDate(entry.date);
          const completedDate = fmtDate(entry.completedAt ?? entry.closedAt);
          const totalDur = fmtDur(
            entry.date,
            entry.completedAt ?? entry.closedAt,
          );

          return (
            <div className="bg-white rounded-2xl shadow-sm px-4 pt-4 pb-4 space-y-4">
              {/* Date header */}
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400">
                    Assigned
                  </p>
                  <p className="text-xs font-bold text-gray-900">
                    {assignedDate}
                  </p>
                </div>
                {totalDur && (
                  <div className="text-center">
                    <p className="text-base font-black text-[#E76124]">
                      {totalDur}
                    </p>
                    <p className="text-[8px] text-gray-400 uppercase tracking-wide">
                      duration
                    </p>
                  </div>
                )}
                <div className="text-right">
                  {completedDate ? (
                    <>
                      <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400">
                        Completed
                      </p>
                      <p className="text-xs font-bold text-gray-900">
                        {completedDate}
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-[9px] font-bold uppercase tracking-widest text-gray-400">
                        Status
                      </p>
                      <p className="text-xs font-bold text-[#E76124]">
                        {STEPS[cur]?.label ?? ""}
                      </p>
                    </>
                  )}
                </div>
              </div>

              {/* Timeline: dots + absolute progress bar + segment durations */}
              <div className="space-y-1.5">
                <div className="relative flex items-center justify-between">
                  {/* Background line */}
                  <div className="absolute inset-x-3 top-1/2 h-0.5 -translate-y-1/2 bg-gray-100 rounded-full" />
                  {/* Filled progress */}
                  {cur > 0 && (
                    <div
                      className="absolute top-1/2 h-0.5 -translate-y-1/2 bg-[#1E1951] rounded-full transition-all duration-500"
                      style={{
                        left: "12px",
                        width: `calc((100% - 24px) * ${cur / (N - 1)})`,
                      }}
                    />
                  )}
                  {/* Segment duration labels above the line */}
                  {segDur.map((dur, i) =>
                    dur && i < cur ? (
                      <div
                        key={i}
                        className="absolute -top-4 z-10"
                        style={{
                          left: `calc(${(i + 0.5) / (N - 1)} * (100% - 24px) + 12px)`,
                          transform: "translateX(-50%)",
                        }}
                      >
                        <span className="text-[8px] font-bold text-gray-400">
                          {dur}
                        </span>
                      </div>
                    ) : null,
                  )}
                  {/* Step dots */}
                  {STEPS.map((step, i) => (
                    <div key={step.key} className="relative z-10">
                      <div
                        className={`w-6 h-6 rounded-full flex items-center justify-center ${
                          i < cur
                            ? "bg-[#1E1951]"
                            : i === cur
                              ? "bg-[#E76124] ring-4 ring-[#E76124]/20"
                              : "bg-gray-100 border border-gray-200"
                        }`}
                      >
                        {i < cur ? (
                          <Check className="w-3 h-3 text-white" />
                        ) : i === cur ? (
                          <div className="w-1.5 h-1.5 rounded-full bg-white" />
                        ) : (
                          <div className="w-1.5 h-1.5 rounded-full bg-gray-300" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Labels row */}
                <div className="flex justify-between">
                  {STEPS.map((step, i) => (
                    <span
                      key={step.key}
                      className={`text-[8px] font-bold text-center w-6 leading-tight ${
                        i < cur
                          ? "text-[#1E1951]"
                          : i === cur
                            ? "text-[#E76124]"
                            : "text-gray-300"
                      }`}
                    >
                      {step.label}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })()}

        {/* Contextual action banner */}
        {(() => {
          const isAssignee =
            !!userId && entry.assignedTo?.userId?.toString() === userId;
          const preApprovalOk =
            !entry.preApproval?.required ||
            entry.preApproval?.status === "APPROVED";
          const pa = entry.partApproval;

          type ActionKey = "acknowledge" | "start" | "complete" | "reviewParts";
          const action: ActionKey | null =
            isAssignee && entry.status === "ASSIGNED" && preApprovalOk
              ? "acknowledge"
              : isAssignee && entry.status === "ACCEPTED"
                ? "start"
                : isAssignee && entry.status === "IN_PROGRESS"
                  ? "complete"
                  : role === "area_manager" && pa?.status === "PENDING"
                    ? "reviewParts"
                    : null;

          if (!action) return null;

          const CONFIG: Record<
            ActionKey,
            {
              icon: React.ReactNode;
              label: string;
              sub: string;
              btn: string;
              btnCls: string;
              onTap: () => void;
            }
          > = {
            acknowledge: {
              icon: <BookmarkCheck className="w-5 h-5 text-[#E76124]" />,
              label: "Acknowledge Task",
              sub: "Confirm receipt and take ownership of this service request",
              btn: actioning ? "Acknowledging…" : "Acknowledge",
              btnCls: "bg-[#E76124] text-white",
              onTap: acknowledge,
            },
            start: {
              icon: <Wrench className="w-5 h-5 text-[#1E1951]" />,
              label: "Ready to Start?",
              sub: "Mark this service as In Progress when work begins on site",
              btn: actioning ? "Starting…" : "Start Work",
              btnCls: "bg-[#1E1951] text-white",
              onTap: startWork,
            },
            complete: {
              icon: <ChevronRight className="w-5 h-5 text-green-600" />,
              label: "Complete Service",
              sub: "Fill in fault codes, parts used and submit your report",
              btn: "Continue →",
              btnCls: "bg-green-600 text-white",
              onTap: () => navigate(`/mobile/service/${entryId}/complete`),
            },
            reviewParts: {
              icon: <RefreshCcw className="w-5 h-5 text-amber-600" />,
              label: "Parts Awaiting Review",
              sub: `${(entry.partsUsed ?? []).filter((p) => !p.decision || p.decision === "PENDING").length} part(s) pending your approval decision`,
              btn: "Review Parts",
              btnCls: "bg-amber-500 text-white",
              onTap: () => {
                setOpenSections((prev) => {
                  const s = new Set(prev);
                  s.add("parts");
                  return s;
                });
              },
            },
          };

          const c = CONFIG[action];
          return (
            <div className="flex items-center gap-3 bg-white rounded-2xl shadow-sm px-4 py-3.5">
              <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center shrink-0">
                {c.icon}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-gray-900 leading-tight">
                  {c.label}
                </p>
                <p className="text-[10px] text-gray-400 leading-tight mt-0.5">
                  {c.sub}
                </p>
              </div>
              <button
                onClick={c.onTap}
                disabled={actioning}
                className={`shrink-0 px-3 py-1.5 rounded-full text-[11px] font-bold disabled:opacity-50 ${c.btnCls}`}
              >
                {c.btn}
              </button>
            </div>
          );
        })()}

        {/* Service title card */}
        {(entry.title || entry.notes) && (
          <div className="bg-amber-50 border border-amber-100 rounded-2xl px-4 py-4 space-y-1.5">
            <p className="text-[10px] font-bold text-amber-600 uppercase tracking-widest">
              Service Title
            </p>
            {entry.title && (
              <p className="text-sm font-semibold text-gray-900 leading-relaxed">
                {entry.title}
              </p>
            )}
            {entry.notes && (
              <p className="text-xs text-gray-600 leading-relaxed">
                {entry.notes}
              </p>
            )}
          </div>
        )}

        {/* Category + subcategory dark pills */}
        {cat && (
          <div className="space-y-2">
            <button
              onClick={() => toggleSection("cat-info")}
              className="w-full flex items-center gap-3 bg-[#1E1951] rounded-2xl px-4 py-3.5 text-left"
            >
              <RefreshCcw className="w-4 h-4 text-white/50 shrink-0" />
              <span className="flex-1 text-sm font-semibold text-white">
                {catLabel}
              </span>
              <ChevronDown
                className={`w-4 h-4 text-white/50 shrink-0 transition-transform ${openSections.has("cat-info") ? "rotate-180" : ""}`}
              />
            </button>
            {openSections.has("cat-info") && (
              <div className="bg-white rounded-2xl px-4 py-3 space-y-1.5 -mt-1 border border-gray-100">
                <p className="text-[11px] text-gray-500 leading-relaxed">
                  {CAT_INFO[cat]}
                </p>
              </div>
            )}
            {entry.subCategory && (
              <div className="flex items-center gap-3 bg-[#1E1951]/80 rounded-2xl px-4 py-3.5">
                <RefreshCcw className="w-4 h-4 text-white/50 shrink-0" />
                <span className="text-sm font-semibold text-white">
                  {entry.subCategory}
                </span>
              </div>
            )}
          </div>
        )}

        {/* Approval section */}
        {wa && (
          <div className="bg-white rounded-2xl shadow-sm px-4 py-4 space-y-4">
            {/* Submitter row */}
            {wa.requestedBy && (
              <div className="flex items-center gap-3">
                <Avatar
                  name={wa.requestedBy.name}
                  userId={wa.requestedBy.userId}
                  photo={wa.requestedBy.profilePic}
                  size="lg"
                  showPopover
                />
                <div>
                  <p className="text-sm font-semibold text-gray-800">
                    Approval Request
                  </p>
                  <p className="text-xs text-gray-400">
                    {timeAgo(wa.requestedAt)}
                  </p>
                </div>
                <span
                  className={`ml-auto text-[10px] font-bold px-2.5 py-1 rounded-full shrink-0 ${
                    wa.status === "CONFIRMED"
                      ? "bg-green-100 text-green-700"
                      : wa.status === "REJECTED"
                        ? "bg-red-100 text-red-600"
                        : wa.status === "PENDING_RSM"
                          ? "bg-blue-100 text-blue-700"
                          : "bg-amber-100 text-amber-700"
                  }`}
                >
                  {wa.status.replace("_", " ")}
                </span>
              </div>
            )}

            {/* AM → RSM flow */}
            <div className="flex items-center gap-3">
              {/* AM */}
              <div className="flex items-center gap-2.5 flex-1">
                <div className="relative shrink-0">
                  <Avatar
                    name={wa.amDecidedBy?.name ?? "?"}
                    userId={wa.amDecidedBy?.userId ?? ""}
                    photo={wa.amDecidedBy?.profilePic}
                    size="lg"
                    showPopover={!!wa.amDecidedBy}
                  />
                  {wa.amDecidedBy && (
                    <span
                      className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white ${wa.rejectedBy === "AM" ? "bg-red-500" : "bg-green-500"}`}
                    >
                      {wa.rejectedBy === "AM" ? (
                        <X className="w-2.5 h-2.5 text-white" />
                      ) : (
                        <Check className="w-2.5 h-2.5 text-white" />
                      )}
                    </span>
                  )}
                  {!wa.amDecidedBy && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-amber-400 flex items-center justify-center ring-2 ring-white">
                      <Clock className="w-2.5 h-2.5 text-white" />
                    </span>
                  )}
                </div>
                <div>
                  <p className="text-[11px] font-bold text-gray-700">AM</p>
                  <p className="text-[10px] text-gray-400">
                    {wa.amDecidedAt ? timeAgo(wa.amDecidedAt) : "Pending"}
                  </p>
                </div>
              </div>
              <ChevronRight className="w-4 h-4 text-gray-300 shrink-0" />
              {/* RSM */}
              <div className="flex items-center gap-2.5 flex-1">
                <div className="relative shrink-0">
                  <Avatar
                    name={wa.rsmDecidedBy?.name ?? "?"}
                    userId={wa.rsmDecidedBy?.userId ?? ""}
                    photo={wa.rsmDecidedBy?.profilePic}
                    size="lg"
                    showPopover={!!wa.rsmDecidedBy}
                  />
                  {wa.rsmDecidedBy && (
                    <span
                      className={`absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full flex items-center justify-center ring-2 ring-white ${wa.rejectedBy === "RSM" ? "bg-red-500" : "bg-emerald-500"}`}
                    >
                      {wa.rejectedBy === "RSM" ? (
                        <X className="w-2.5 h-2.5 text-white" />
                      ) : (
                        <Check className="w-2.5 h-2.5 text-white" />
                      )}
                    </span>
                  )}
                  {!wa.rsmDecidedBy && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-gray-300 flex items-center justify-center ring-2 ring-white">
                      <Clock className="w-2.5 h-2.5 text-white" />
                    </span>
                  )}
                </div>
                <div>
                  <p className="text-[11px] font-bold text-gray-700">RSM</p>
                  <p className="text-[10px] text-gray-400">
                    {wa.rsmDecidedAt ? timeAgo(wa.rsmDecidedAt) : "Pending"}
                  </p>
                </div>
              </div>
            </div>

            {/* Rejection note */}
            {wa.status === "REJECTED" && wa.rejectionNote && (
              <div className="bg-red-50 border border-red-100 rounded-xl px-3 py-2.5">
                <p className="text-[10px] font-bold text-red-500 uppercase tracking-wide mb-0.5">
                  Rejection note
                </p>
                <p className="text-xs text-red-700 italic">
                  "{wa.rejectionNote}"
                </p>
              </div>
            )}

            {/* Inline AM / RSM decision buttons */}
            {showActions && (
              <div className="space-y-2 pt-1">
                {submitError && (
                  <p className="text-xs text-red-500 text-center">
                    {submitError}
                  </p>
                )}
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setRejectOpen(true);
                      setNote("");
                      setSubmitError("");
                    }}
                    disabled={submitting}
                    className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl border-2 border-red-200 text-red-600 text-sm font-bold disabled:opacity-50 hover:bg-red-50 transition-colors"
                  >
                    <X className="w-4 h-4" />
                    Reject
                  </button>
                  <button
                    onClick={() => decide(true)}
                    disabled={submitting}
                    className="flex-1 flex items-center justify-center gap-1.5 py-3 rounded-2xl bg-green-500 hover:bg-green-600 text-white text-sm font-bold disabled:opacity-50 transition-colors"
                  >
                    {submitting ? (
                      <RefreshCcw className="w-4 h-4 animate-spin" />
                    ) : (
                      <Check className="w-4 h-4" />
                    )}
                    {canAMReview ? "Approve" : "Confirm"}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Asset Information — collapsible */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          <button
            onClick={() => toggleSection("asset")}
            className="w-full flex items-center justify-between px-4 py-4"
          >
            <span className="text-sm font-bold text-gray-900">
              Asset Information
            </span>
            <ChevronDown
              className={`w-5 h-5 text-gray-400 transition-transform ${openSections.has("asset") ? "rotate-180" : ""}`}
            />
          </button>
          {openSections.has("asset") && asset && (
            <div className="border-t border-gray-100 px-4 py-3 space-y-2">
              {[
                { label: "KVA", value: asset.kva },
                { label: "Genset Model", value: asset.gensetModel },
                { label: "Engine Model", value: asset.engineModel },
                { label: "CPCB", value: asset.cpcb },
                { label: "Fuel Type", value: asset.fuelType },
              ]
                .filter((r) => r.value)
                .map((r) => (
                  <div
                    key={r.label}
                    className="flex items-center justify-between"
                  >
                    <span className="text-xs text-gray-400">{r.label}</span>
                    <span className="text-xs font-semibold text-gray-800">
                      {r.value}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>

        {/* Fault Codes — collapsible */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {(entry.faultCodes ?? []).length === 0 ? (
            <div className="flex items-center justify-between px-4 py-4">
              <span className="text-sm font-bold text-gray-900">
                Fault Codes
              </span>
              <span className="text-xs text-gray-400">—</span>
            </div>
          ) : (
            <>
              <button
                onClick={() => toggleSection("faults")}
                className="w-full flex items-center justify-between px-4 py-4"
              >
                <span className="text-sm font-bold text-gray-900">
                  Fault Codes
                </span>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                    {entry.faultCodes!.length}
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 transition-transform ${openSections.has("faults") ? "rotate-180" : ""}`}
                  />
                </div>
              </button>
              {openSections.has("faults") && (
                <div className="border-t border-gray-100 divide-y divide-gray-100">
                  {entry.faultCodes!.map((fc, i) => (
                    <div key={i}>
                      <div className="flex items-center gap-3 px-4 py-3">
                        <div className="w-8 h-8 rounded-xl bg-[#1E1951] flex items-center justify-center shrink-0">
                          <AlertCircle className="w-4 h-4 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono text-xs font-bold text-gray-800">
                              {fc.codeId.code}
                            </span>
                            {fc.codeId.priority && (
                              <span
                                className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                                  fc.codeId.priority === "P1"
                                    ? "bg-red-100 text-red-700"
                                    : fc.codeId.priority === "P2"
                                      ? "bg-orange-100 text-orange-700"
                                      : fc.codeId.priority === "P3"
                                        ? "bg-blue-100 text-blue-700"
                                        : "bg-gray-100 text-gray-500"
                                }`}
                              >
                                {fc.codeId.priority}
                              </span>
                            )}
                          </div>
                          <p className="text-xs font-semibold text-[#1E1951] mt-0.5 truncate">
                            {fc.codeId.description}
                          </p>
                        </div>
                      </div>
                      {[
                        {
                          label: "Observation",
                          value: fc.observation,
                          accent: "bg-yellow-50",
                        },
                        {
                          label: "Root Cause",
                          value: fc.rootCause,
                          accent: "bg-red-50",
                        },
                        {
                          label: "Corrective Action",
                          value: fc.correctiveAction,
                          accent: "bg-green-50",
                        },
                      ].map(({ label, value, accent }) =>
                        value ? (
                          <div key={label} className={`px-4 py-2.5 ${accent}`}>
                            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide mb-0.5">
                              {label}
                            </p>
                            <p className="text-sm text-gray-800 leading-relaxed">
                              {value}
                            </p>
                          </div>
                        ) : null,
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Parts — collapsible */}
        {(() => {
          const pa = entry.partApproval;
          const partsUsed = entry.partsUsed ?? [];
          const hasUndecidedParts = partsUsed.some(
            (p) => !p.decision || p.decision === "PENDING",
          );
          const canReviewParts =
            role === "area_manager" &&
            hasUndecidedParts &&
            pa?.required === true &&
            pa?.status === "PENDING";
          return (
            <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
              {partsUsed.length === 0 ? (
                <div className="flex items-center justify-between px-4 py-4">
                  <span className="text-sm font-bold text-gray-900">Parts</span>
                  <span className="text-xs text-gray-400">—</span>
                </div>
              ) : (
                <>
                  <button
                    onClick={() => toggleSection("parts")}
                    className="w-full flex items-center justify-between px-4 py-4"
                  >
                    <span className="text-sm font-bold text-gray-900">
                      Parts
                    </span>
                    <div className="flex items-center gap-2">
                      {pa?.required && (
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            pa.status === "PENDING"
                              ? "bg-amber-100 text-amber-700"
                              : "bg-green-100 text-green-700"
                          }`}
                        >
                          {pa.status === "PENDING"
                            ? "AM Review Needed"
                            : "Reviewed"}
                        </span>
                      )}
                      <span className="text-[10px] font-bold bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                        {partsUsed.length}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-gray-400 transition-transform ${openSections.has("parts") ? "rotate-180" : ""}`}
                      />
                    </div>
                  </button>
                  {openSections.has("parts") && (
                    <div className="border-t border-gray-100">
                      <div className="divide-y divide-gray-100">
                        {partsUsed.map((p, i) => {
                          return (
                            <div key={i} className="px-4 py-3 space-y-2">
                              <div className="flex items-start gap-3">
                                <div className="flex gap-2 items-start min-w-0">
                                    <span className="font-mono text-[10px] font-bold bg-[#E76124]/10 text-[#E76124] px-2 py-0.5 rounded-full">
                                      {p.partId.code}
                                    </span>
                              
                                    {p.decision && p.decision !== 'PENDING' && (
                                      <span className={`shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                        p.decision === 'APPROVED'
                                          ? 'bg-green-100 text-green-700'
                                          : p.decision === 'REMOVED'
                                            ? 'bg-gray-100 text-gray-400'
                                            : 'bg-red-100 text-red-600'
                                      }`}>
                                        {p.decision}
                                      </span>
                                    )}
                                  <div>

                                  <p className="text-sm font-semibold text-[#1E1951] truncate">
                                    {p.partId.name}
                                  </p>
                                  <p className="text-[10px] text-gray-400">
                                    {p.partId.category} › {p.partId.subCategory}
                                  </p>
                                    </div>
                                </div>
                              
                              </div>
                              {p.decision === 'REJECTED' && p.decisionReason && (
                                <p className="text-[11px] text-red-500 bg-red-50 rounded-lg px-2.5 py-1.5 leading-snug">
                                  {p.decisionReason}
                                </p>
                              )}
                              {canReviewParts && (
                                <div className="mt-1">
                                  {rejectingPartId === p.partId._id ? (
                                    <div className="space-y-2">
                                      <textarea
                                        value={rejectComment}
                                        onChange={e => setRejectComment(e.target.value)}
                                        placeholder="Reason for rejection…"
                                        rows={2}
                                        className="w-full text-sm border border-red-200 rounded-xl px-3 py-2 resize-none focus:outline-none focus:ring-2 focus:ring-red-300"
                                      />
                                      <div className="flex gap-2 justify-end">
                                        <button
                                          onClick={() => { setRejectingPartId(null); setRejectComment(''); }}
                                          className="text-xs text-gray-500 px-3 py-1.5 rounded-lg border border-gray-200"
                                        >
                                          Cancel
                                        </button>
                                        <button
                                          onClick={() => savePartDecision(p.partId._id, "REJECTED", rejectComment.trim() || undefined)}
                                          disabled={partSaving[p.partId._id]}
                                          className="flex items-center gap-1 text-xs font-semibold text-white bg-red-500 px-3 py-1.5 rounded-lg disabled:opacity-50"
                                        >
                                          {partSaving[p.partId._id]
                                            ? <RefreshCcw className="w-3 h-3 animate-spin" />
                                            : <Check className="w-3 h-3" />}
                                          Save
                                        </button>
                                      </div>
                                    </div>
                                  ) : (
                                      <div className="flex justify-end">
                                        {partSaving[p.partId._id] ? (
                                          <span className="w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full animate-spin" />
                                        ) : (
                                          <div className="flex gap-1 bg-gray-100 border border-gray-300 rounded-xl p-1">
                                            <button
                                              onClick={() => { setRejectingPartId(p.partId._id); setRejectComment('') }}
                                              className={`w-12 h-12 rounded-l-xl border flex items-center justify-center transition-colors ${
                                                p.decision === "REJECTED"
                                                  ? "bg-red-500 border-red-600 text-white"
                                                  : "bg-white border-gray-300 text-gray-300"
                                              }`}
                                            >
                                              <X className="w-5 h-5" />
                                            </button>
                                            <button
                                              onClick={() => savePartDecision(p.partId._id, "APPROVED")}
                                              className={`w-12 h-12 rounded-r-xl border flex items-center justify-center transition-colors ${
                                                p.decision === "APPROVED"
                                                  ? "bg-green-500 border-green-600 text-white"
                                                  : "bg-white border-gray-200 text-gray-300"
                                              }`}
                                            >
                                              <Check className="w-5 h-5" />
                                            </button>
                                          </div>
                                        )}
                                      </div>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                      {partReviewError && (
                        <p className="text-xs text-red-500 px-4 py-2">{partReviewError}</p>
                      )}
                    </div>
                  )}
                </>
              )}
            </div>
          );
        })()}

        {/* Photos — collapsible */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {(entry.photos ?? []).length === 0 ? (
            <div className="flex items-center justify-between px-4 py-4">
              <span className="text-sm font-bold text-gray-900">Photos</span>
              <span className="text-xs text-gray-400">—</span>
            </div>
          ) : (
            <>
              <button
                onClick={() => toggleSection("photos")}
                className="w-full flex items-center justify-between px-4 py-4"
              >
                <span className="text-sm font-bold text-gray-900">Photos</span>
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-green-500 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-white" />
                  </span>
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 transition-transform ${openSections.has("photos") ? "rotate-180" : ""}`}
                  />
                </div>
              </button>
              {openSections.has("photos") && (
                <div className="border-t border-gray-100 grid grid-cols-3 gap-1 p-1">
                  {entry.photos!.map((url, i) => (
                    <img
                      key={i}
                      src={url}
                      alt={`Photo ${i + 1}`}
                      className="aspect-square w-full object-cover rounded-xl"
                    />
                  ))}
                </div>
              )}
            </>
          )}
        </div>

        {/* Customer feedback — collapsible */}
        <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
          {!entry.customerFeedback ? (
            <div className="flex items-center justify-between px-4 py-4">
              <span className="text-sm font-bold text-gray-900">
                Customer Feedback
              </span>
              <span className="text-xs text-gray-400">—</span>
            </div>
          ) : (
            <>
              <button
                onClick={() => toggleSection("feedback")}
                className="w-full flex items-center justify-between px-4 py-4"
              >
                <span className="text-sm font-bold text-gray-900">
                  Customer Feedback
                </span>
                <div className="flex items-center gap-1.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-3.5 h-3.5 ${s <= entry.customerFeedback!.rating ? "text-amber-400 fill-amber-400" : "text-gray-200 fill-gray-200"}`}
                    />
                  ))}
                  <ChevronDown
                    className={`w-5 h-5 text-gray-400 ml-1 transition-transform ${openSections.has("feedback") ? "rotate-180" : ""}`}
                  />
                </div>
              </button>
              {openSections.has("feedback") && (
                <div className="border-t border-gray-100 px-4 py-3 space-y-1.5">
                  <p className="text-sm font-semibold text-gray-800">
                    {entry.customerFeedback.customerName}
                  </p>
                  {entry.customerFeedback.comment && (
                    <p className="text-sm text-gray-600 italic">
                      "{entry.customerFeedback.comment}"
                    </p>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Sticky bottom bar */}
      {(showActions || wa) && (
        <div className="fixed bottom-[124px] m-auto max-w-[380px] left-0 right-0 bg-[#11101c] px-2 py-2 backdrop-blur-md rounded-full">
          {showActions ? (
            <div className="flex gap-6 justify-end items-center">
              {submitError && (
                <p className="text-xs text-red-400 flex-1 text-center">
                  {submitError}
                </p>
              )}
              <p className="text-sm text-gray-400 font-semibold">Decision:</p>
              <button
                onClick={() => {
                  setRejectOpen(true);
                  setNote("");
                  setSubmitError("");
                }}
                disabled={submitting}
                className="w-12 h-12 rounded-full bg-red-500 flex items-center justify-center text-white disabled:opacity-50"
              >
                {submitting ? (
                  <RefreshCcw size={20} className="animate-spin" />
                ) : (
                  <X size={22} />
                )}
              </button>
              <button
                onClick={() => decide(true)}
                disabled={submitting}
                className="w-12 h-12 rounded-full bg-green-500 flex items-center justify-center text-white disabled:opacity-50"
              >
                {submitting ? (
                  <RefreshCcw size={20} className="animate-spin" />
                ) : (
                  <Check size={22} />
                )}
              </button>
            </div>
          ) : wa ? (
            <div className="flex items-center justify-center gap-2 py-2">
              {(wa.status === "PENDING_AM" || wa.status === "PENDING_RSM") && (
                <>
                  <Clock className="w-4 h-4 text-amber-400" />
                  <p className="text-sm font-semibold text-amber-400">
                    {wa.status === "PENDING_AM"
                      ? "Awaiting AM Review"
                      : "Awaiting RSM Confirmation"}
                  </p>
                </>
              )}
              {wa.status === "CONFIRMED" && (
                <>
                  <CheckCircle2 className="w-4 h-4 text-green-400" />
                  <p className="text-sm font-semibold text-green-400">
                    Approved — Pending Close
                  </p>
                </>
              )}
              {wa.status === "REJECTED" &&
                (canResubmit ? (
                  <button
                    onClick={openResubmit}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#E76124] text-white text-sm font-bold"
                  >
                    <RefreshCcw className="w-4 h-4" />
                    Edit &amp; Resubmit
                  </button>
                ) : (
                  <>
                    <XCircle className="w-4 h-4 text-red-400" />
                    <p className="text-sm font-semibold text-red-400">
                      Rejected — Needs Revision
                    </p>
                  </>
                ))}
            </div>
          ) : null}
        </div>
      )}

      {/* Resubmit bottom sheet */}
      {resubmitOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          onClick={() => setResubmitOpen(false)}
        >
          <div
            className="w-full max-w-[420px] mx-auto bg-white rounded-t-3xl shadow-2xl max-h-[88vh] flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-5 pt-5 pb-4 shrink-0">
              <div className="w-10 h-1 rounded-full bg-gray-200 mx-auto mb-4" />
              <p className="text-base font-bold text-gray-900">
                Edit &amp; Resubmit
              </p>
              {wa?.rejectionNote && (
                <div className="mt-2 bg-red-50 border border-red-100 rounded-xl px-3 py-2">
                  <p className="text-[10px] font-bold text-red-500 uppercase tracking-widest mb-0.5">
                    Rejection note
                  </p>
                  <p className="text-xs text-red-700 italic">
                    "{wa.rejectionNote}"
                  </p>
                </div>
              )}
            </div>
            <div className="flex-1 overflow-y-auto px-5 space-y-5 pb-4">
              {editFCs.length > 0 && (
                <div className="space-y-3">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    Fault Codes
                  </p>
                  {editFCs.map((fc, i) => (
                    <div
                      key={i}
                      className="bg-gray-50 rounded-2xl px-4 py-3 space-y-2.5"
                    >
                      <p className="text-xs font-bold text-gray-800">
                        {fc.code} — {fc.description}
                      </p>
                      {(
                        [
                          "observation",
                          "rootCause",
                          "correctiveAction",
                        ] as const
                      ).map((field) => (
                        <div key={field}>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">
                            {field === "correctiveAction"
                              ? "Corrective Action"
                              : field === "rootCause"
                                ? "Root Cause"
                                : "Observation"}
                          </label>
                          <textarea
                            value={fc[field]}
                            onChange={(e) =>
                              setEditFCs((prev) =>
                                prev.map((x, j) =>
                                  j === i
                                    ? { ...x, [field]: e.target.value }
                                    : x,
                                ),
                              )
                            }
                            rows={2}
                            className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124] resize-none bg-white"
                          />
                        </div>
                      ))}
                    </div>
                  ))}
                </div>
              )}
              {editParts.length > 0 && (
                <div className="space-y-3">
                  <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    Parts Used
                  </p>
                  {editParts.map((p, i) => (
                    <div
                      key={i}
                      className="bg-gray-50 rounded-2xl px-4 py-3 flex items-center justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-gray-800 truncate">
                          {p.name}
                        </p>
                        <p className="text-[10px] text-gray-400">
                          {p.code} · {p.unit}
                        </p>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            setEditParts((prev) =>
                              prev.map((x, j) =>
                                j === i
                                  ? {
                                      ...x,
                                      quantity: Math.max(1, x.quantity - 1),
                                    }
                                  : x,
                              ),
                            )
                          }
                          className="w-7 h-7 rounded-full bg-white border border-gray-200 text-gray-700 font-bold flex items-center justify-center"
                        >
                          −
                        </button>
                        <span className="w-8 text-center text-sm font-bold text-gray-900">
                          {p.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            setEditParts((prev) =>
                              prev.map((x, j) =>
                                j === i
                                  ? { ...x, quantity: x.quantity + 1 }
                                  : x,
                              ),
                            )
                          }
                          className="w-7 h-7 rounded-full bg-white border border-gray-200 text-gray-700 font-bold flex items-center justify-center"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="shrink-0 px-5 pb-8 pt-3 border-t border-gray-100 space-y-2">
              {resubmitError && (
                <p className="text-xs text-red-500">{resubmitError}</p>
              )}
              <button
                onClick={handleResubmit}
                disabled={resubmitting}
                className="w-full py-3 rounded-2xl bg-[#E76124] hover:bg-[#cf5520] text-white text-sm font-bold disabled:opacity-40 transition-colors"
              >
                {resubmitting ? "Resubmitting…" : "Resubmit for Approval"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject note bottom sheet */}
      {rejectOpen && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          onClick={() => setRejectOpen(false)}
        >
          <div
            className="w-full max-w-[420px] mx-auto bg-white rounded-t-3xl px-5 pt-5 pb-8 space-y-4 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-gray-200 mx-auto" />
            <p className="text-base font-bold text-gray-900">Rejection Note</p>
            <textarea
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Explain what needs to be corrected…"
              rows={4}
              className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-red-300 resize-none"
            />
            {submitError && (
              <p className="text-xs text-red-500">{submitError}</p>
            )}
            <button
              onClick={() => decide(false)}
              disabled={submitting || !note.trim()}
              className="w-full py-3 rounded-2xl bg-red-500 hover:bg-red-600 text-white text-sm font-bold disabled:opacity-40 transition-colors"
            >
              {submitting ? "Submitting…" : "Confirm Reject"}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
