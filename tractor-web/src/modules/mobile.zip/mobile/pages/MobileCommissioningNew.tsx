import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronLeft, Bell, MapPin, Phone, User, ChevronDown, ChevronUp, Zap, CheckCircle2, ShieldCheck, Repeat2, UserRoundCog, ChevronRight } from 'lucide-react'
import { MobileSearchBar } from '../components/MobileSearchBar'
import { MobileSelectSheet, type SelectSheetItem } from '../components/MobileSelectSheet'
import { useAuth } from '../../../shared/context/AuthContext'
import { useAssetSearch } from '../../commissioning/hooks/useAssetSearch'
import { useCommissioningActions } from '../../commissioning/hooks/useCommissioningActions'
import {
  fetchAvailableActions,
  type AvailableActionsResult,
} from '../../commissioning/services/commissioningApi'
import { fmtAddress } from '../../../shared/data/types'
import type { EntryType } from '../../commissioning/types'

function fmtDate(d?: string | null) {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function sapDispatchLogic(billingDate?: string | null) {
  if (!billingDate) return {
    type: 'no_date' as const,
    label: 'No Dispatch Date',
    desc: 'SAP record has no billing date — dispatch date unknown.',
    dot: 'bg-gray-300', wrap: 'bg-gray-50 border-gray-200', title: 'text-gray-500', body: 'text-gray-400',
  }
  const date         = new Date(billingDate)
  const AUTO_CUTOFF  = new Date('2024-07-01')
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)

  if (date < AUTO_CUTOFF) return {
    type: 'auto' as const,
    label: 'Auto-Commissioned',
    desc:  'Dispatch date before July 2024 — a completed commissioning entry will be created automatically.',
    dot: 'bg-green-500', wrap: 'bg-green-50 border-green-200', title: 'text-green-700', body: 'text-green-600',
  }
  if (date >= sixMonthsAgo) return {
    type: 'window' as const,
    label: 'Commissioning Window Open',
    desc:  'Within the 6-month window — proceed to commission this asset.',
    dot: 'bg-blue-500', wrap: 'bg-blue-50 border-blue-200', title: 'text-blue-700', body: 'text-blue-600',
  }
  return {
    type: 'revalidation' as const,
    label: 'Revalidation Required',
    desc:  'Dispatch date is more than 6 months ago — revalidation will be needed before services can be raised.',
    dot: 'bg-amber-500', wrap: 'bg-amber-50 border-amber-200', title: 'text-amber-700', body: 'text-amber-600',
  }
}

const TYPE_LABEL: Record<string, string> = {
  PRE_COMMISSIONING: 'Pre-Commissioning',
  COMMISSIONING:     'Commissioning',
  REVALIDATION:      'Revalidation',
  RE_COMMISSIONING:  'Re-Commissioning',
}

const TYPE_COLOR: Record<string, string> = {
  PRE_COMMISSIONING: 'bg-blue-100 text-blue-700',
  COMMISSIONING:     'bg-green-100 text-green-700',
  REVALIDATION:      'bg-orange-100 text-orange-700',
  RE_COMMISSIONING:  'bg-purple-100 text-purple-700',
}

const STATUS_PILL: Record<string, string> = {
  ASSIGNED:    'bg-blue-50 text-blue-600',
  ACCEPTED:    'bg-teal-50 text-teal-600',
  IN_PROGRESS: 'bg-amber-50 text-amber-700',
  COMPLETED:   'bg-green-50 text-green-700',
  APPROVED:    'bg-indigo-50 text-indigo-700',
  CLOSED:      'bg-gray-100 text-gray-500',
}

const ACTION_ICON: Record<string, React.ReactNode> = {
  PRE_COMMISSIONING: <Zap         className="w-5 h-5 text-blue-500   shrink-0" />,
  COMMISSIONING:     <CheckCircle2 className="w-5 h-5 text-green-500  shrink-0" />,
  REVALIDATION:      <ShieldCheck  className="w-5 h-5 text-orange-500 shrink-0" />,
  RE_COMMISSIONING:  <Repeat2      className="w-5 h-5 text-purple-500 shrink-0" />,
}

const ACTION_COLOR: Record<string, string> = {
  PRE_COMMISSIONING: 'blue',
  COMMISSIONING:     'green',
  REVALIDATION:      'orange',
  RE_COMMISSIONING:  'purple',
}

const ACTIVED: Record<string, string> = {
  blue:   'bg-blue-50   border-blue-300',
  green:  'bg-green-50  border-green-300',
  orange: 'bg-orange-50 border-orange-300',
  purple: 'bg-purple-50 border-purple-300',
}

const HOVER: Record<string, string> = {
  blue:   'hover:bg-blue-50   hover:border-blue-200',
  green:  'hover:bg-green-50  hover:border-green-200',
  orange: 'hover:bg-orange-50 hover:border-orange-200',
  purple: 'hover:bg-purple-50 hover:border-purple-200',
}

export default function MobileCommissioningNew() {
  const navigate = useNavigate()
  const { canAssign, role: userRole, dealerName, userId, name: userName } = useAuth()
  const isAM = userRole === 'area_manager'

  const search = useAssetSearch()
  const [serverActions, setServerActions] = useState<AvailableActionsResult | null>(null)
  const [loadingActions, setLoadingActions] = useState(false)
  const [showClientInfo, setShowClientInfo] = useState(false)
  const [showHistory, setShowHistory] = useState(false)
  const [assignSheetOpen, setAssignSheetOpen] = useState(false)

  const actions = useCommissioningActions({
    asset:      search.asset,
    onSaved:    async () => { navigate('/mobile/dashboard') },
    canAssign:  canAssign ?? false,
    userRole:   userRole ?? undefined,
    dealerName: dealerName ?? undefined,
    userId,
  })

  function doLoadActions() {
    if (!search.asset) return
    setLoadingActions(true)
    fetchAvailableActions(search.asset._id)
      .then(setServerActions)
      .catch(() => setServerActions(null))
      .finally(() => setLoadingActions(false))
  }

  useEffect(() => {
    if (search.searchState === 'found' && search.asset) {
      doLoadActions()
      setShowClientInfo(false)
      setShowHistory(false)
    } else {
      setServerActions(null)
    }
  }, [search.searchState, search.asset?._id]) // eslint-disable-line react-hooks/exhaustive-deps

  const asset            = search.asset
  const availableActions = serverActions?.actions ?? []

  const infoFields: [string, string | number | undefined][] = [
    ['Genset Model',     asset?.gensetModel],
    ['Genset S/N',       asset?.gensetNumber],
    ['Engine S/N',       asset?.engineNumber],
    ['Alternator Make',  asset?.alternatorMake],
    ['Alternator Model', asset?.alternatorModel],
    ['Engine Model',     asset?.engineModel],
  ]

  return (
    <div className="min-h-screen">

      {/* Header */}
      <div className="px-8 pt-6 pb-4 flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">New Job</p>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>

      <div className="px-8 space-y-4 pb-12">

        {/* Search row */}
        <MobileSearchBar
          value={search.query}
          onChange={v => { search.setQuery(v); if (search.searchState !== 'idle') search.setSearchState('idle') }}
          onSearch={() => search.handleSearch(search.query)}
          placeholder="Genset S/N or Engine S/N…"
          defaultExpanded
        />

        {/* Idle hint */}
        {search.searchState === 'idle' && !search.searching && (
          <p className="text-sm text-gray-400 text-center pt-8">Enter Genset S/N or Engine S/N to search</p>
        )}

        {/* Not found */}
        {search.searchState === 'not_found' && (
          <div className="bg-red-50 border border-red-100 rounded-2xl px-5 py-4">
            <p className="text-sm font-semibold text-red-600">No asset found</p>
            <p className="text-xs text-red-400 mt-0.5">No result for <strong>"{search.query}"</strong> in database or SAP.</p>
          </div>
        )}

        {/* SAP found */}
        {search.searchState === 'sap_found' && search.sapRecord && (
          <div className="space-y-3">
            {/* SAP record info */}
            <div className="bg-orange-50 border border-orange-200 rounded-2xl px-4 py-3 space-y-1">
              <p className="text-sm font-semibold text-orange-700">Found in SAP records</p>
              <p className="text-xs text-orange-500">
                {[search.sapRecord.gensetSerialNo, search.sapRecord.engineSerialNo].filter(Boolean).join(' · ')}
              </p>
              {search.sapRecord.shipToPartyName && (
                <p className="text-xs text-orange-400">{search.sapRecord.shipToPartyName}</p>
              )}
              {[search.sapRecord.cityTQ, search.sapRecord.district, search.sapRecord.state].filter(Boolean).length > 0 && (
                <p className="text-xs text-orange-400">
                  {[search.sapRecord.cityTQ, search.sapRecord.district, search.sapRecord.state].filter(Boolean).join(', ')}
                </p>
              )}
            </div>

            {/* Dispatch date + business logic */}
            {(() => {
              const logic = sapDispatchLogic(search.sapRecord?.billingDate)
              return (
                <div className={`border rounded-2xl px-4 py-3.5 space-y-1.5 ${logic.wrap}`}>
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full shrink-0 ${logic.dot}`} />
                    <p className={`text-xs font-bold ${logic.title}`}>{logic.label}</p>
                  </div>
                  {search.sapRecord?.billingDate && (
                    <p className="text-xs text-gray-500 font-medium pl-4">
                      Dispatch Date: {fmtDate(search.sapRecord.billingDate)}
                    </p>
                  )}
                  <p className={`text-xs leading-relaxed pl-4 ${logic.body}`}>{logic.desc}</p>
                </div>
              )
            })()}

            {(() => {
              const dl = sapDispatchLogic(search.sapRecord?.billingDate)
              const label = dl.type === 'auto'
                ? 'Create Asset'
                : dl.type === 'window'
                ? 'Create Asset & Commission'
                : 'Create Asset'
              return (
                <button
                  onClick={() => navigate('/mobile/assets/create', { state: { sapRecord: search.sapRecord, returnTo: '/mobile/commissioning/new' } })}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-2xl bg-[#E76124] text-white text-sm font-bold hover:bg-[#cf5520] transition-colors"
                >
                  <Zap className="w-4 h-4" />
                  {label}
                </button>
              )
            })()}
          </div>
        )}

        {/* Found */}
        {search.searchState === 'found' && asset && (
          <>
            {/* Asset info card */}
            <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
              {/* card header */}
              <div className="px-4 py-3.5 border-b border-gray-50 flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0">
                  <svg className="w-4 h-4 text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-gray-900 truncate">{asset.gensetModel ?? asset.gensetNumber}</p>
                  <p className="text-xs text-gray-400">
                    {[asset.kva && `${asset.kva} KVA`, asset.cpcb].filter(Boolean).join(' · ') || 'Asset Details'}
                  </p>
                </div>
              </div>
              {/* 2-col grid */}
              <div className="grid grid-cols-2">
                {infoFields.map(([label, val], i) => (
                  <div
                    key={label}
                    className={`px-4 py-3 ${i % 2 === 0 ? 'border-r border-gray-50' : ''} ${i < infoFields.length - 2 ? 'border-b border-gray-50' : ''}`}
                  >
                    <p className="text-[10px] text-gray-400 uppercase tracking-wide">{label}</p>
                    <p className="text-sm font-semibold text-gray-800 mt-0.5">{val ?? '—'}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Actions list */}
            <div className="space-y-2">
              <p className="text-xs font-bold text-gray-500 uppercase tracking-wider px-1">Actions</p>
              {loadingActions && <p className="text-xs text-gray-400">Loading available actions…</p>}
              {!loadingActions && availableActions.length === 0 && (
                <p className="text-xs text-gray-400">No actions available for this asset.</p>
              )}
              {!loadingActions && availableActions.map(item => {
                const color  = ACTION_COLOR[item.action] ?? 'blue'
                const active = actions.activeAction === item.action
                return (
                  <button
                    key={item.action}
                    onClick={item.available ? () => actions.openAction(item.action as EntryType) : undefined}
                    disabled={!item.available}
                    className={`w-full text-left border rounded-2xl px-5 py-4 shadow-sm transition-colors ${
                      !item.available ? 'bg-gray-50 border-gray-200 opacity-50 cursor-not-allowed'
                      : active        ? ACTIVED[color]
                      :                 `bg-white border-gray-200 ${HOVER[color]}`
                    }`}
                  >
                    <div className="flex items-center gap-3 mb-1">
                      {ACTION_ICON[item.action]}
                      <span className="text-sm font-semibold text-[#1E1951]">{item.label}</span>
                      {!item.available && (
                        <span className="ml-auto text-[10px] font-semibold bg-green-100 text-green-700 px-2 py-0.5 rounded-full">Done</span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 pl-8">{item.description}</p>
                    {item.reason && <p className="text-xs text-gray-300 mt-1 pl-8 italic">{item.reason}</p>}
                  </button>
                )
              })}
            </div>

            {/* Inline job card form */}
            {actions.activeAction && (
              <div className="bg-white rounded-3xl shadow-sm px-5 pt-5 pb-6 space-y-4">
                {/* heading */}
                <div className="flex items-center gap-2">
                  <span className={`text-[11px] font-semibold px-2.5 py-1 rounded-full ${TYPE_COLOR[actions.activeAction]}`}>
                    {TYPE_LABEL[actions.activeAction]}
                  </span>
                  <p className="text-base font-bold text-gray-900">New Job Card</p>
                </div>

                {/* Date */}
                <div>
                  <label className="block text-xs font-semibold text-gray-500 mb-1.5">Date</label>
                  <input
                    type="date"
                    value={actions.actionDate}
                    onChange={e => actions.setActionDate(e.target.value)}
                    className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124]"
                  />
                </div>

                {/* Assign to */}
                {canAssign && (actions.assignableUsers.length > 0 || isAM || userRole === 'dealer') && (() => {
                  const selected = actions.assignedToId
                    ? [...(userId && (isAM || userRole === 'dealer') ? [{ _id: userId, name: userName ?? 'Me', role: userRole ?? '' }] : []), ...actions.assignableUsers]
                        .find(u => u._id === actions.assignedToId)
                    : null
                  return (
                    <div>
                      <label className="block text-xs font-semibold text-gray-500 mb-1.5">Assign To</label>
                      <button
                        type="button"
                        onClick={() => setAssignSheetOpen(true)}
                        className="w-full flex items-center gap-3 border border-gray-200 rounded-xl px-3 py-2.5 bg-gray-50 text-left transition-colors active:bg-gray-100"
                      >
                        <UserRoundCog className="w-4 h-4 text-gray-400 shrink-0" />
                        <span className={`flex-1 text-sm ${selected ? 'text-gray-900 font-semibold' : 'text-gray-400'}`}>
                          {selected
                            ? selected._id === userId
                              ? `${selected.name} (You)`
                              : selected.role === 'dealer'
                                ? ((selected as { dealerName?: string }).dealerName || selected.name)
                                : selected.name
                            : 'Select assignee…'}
                        </span>
                        <ChevronRight className="w-4 h-4 text-gray-300 shrink-0" />
                      </button>
                    </div>
                  )
                })()}

                {/* Notes */}
                <div>
                  <label className="block text-xs font-semibold text-gray-500 mb-1.5">
                    Notes <span className="font-normal text-gray-400">(optional)</span>
                  </label>
                  <textarea
                    value={actions.notes}
                    onChange={e => actions.setNotes(e.target.value)}
                    rows={2}
                    placeholder="Add notes…"
                    className="w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124] resize-none"
                  />
                </div>

                {actions.saveError && (
                  <p className="text-xs text-red-500">{actions.saveError}</p>
                )}

                {/* Buttons */}
                <div className="flex gap-2">
                  <button
                    onClick={actions.closeAction}
                    className="flex-1 py-3 rounded-2xl border border-gray-200 text-sm font-semibold text-gray-500 hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={actions.handleSave}
                    disabled={actions.saving}
                    className="flex-1 py-3 rounded-2xl bg-[#E76124] text-white text-sm font-bold disabled:opacity-50 hover:bg-[#d4561f] transition-colors"
                  >
                    {actions.saving ? 'Creating…' : 'Create Job Card'}
                  </button>
                </div>
              </div>
            )}

            {/* Client Info accordion */}
            <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
              <button
                onClick={() => setShowClientInfo(v => !v)}
                className="w-full flex items-center justify-between px-4 py-4"
              >
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">Client Info</p>
                {showClientInfo
                  ? <ChevronUp className="w-4 h-4 text-gray-400" />
                  : <ChevronDown className="w-4 h-4 text-gray-400" />}
              </button>
              {showClientInfo && (
                <div className="px-4 pb-5 space-y-3 border-t border-gray-50 pt-3">
                  {asset.clientName && (
                    <div className="flex items-center gap-3">
                      <User className="w-4 h-4 text-gray-400 shrink-0" />
                      <p className="text-sm font-semibold text-gray-800">{asset.clientName}</p>
                    </div>
                  )}
                  {(asset.primaryContactName || asset.primaryContactNumber) && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-gray-400 shrink-0" />
                      <p className="text-sm text-gray-700">
                        {[asset.primaryContactName, asset.primaryContactNumber].filter(Boolean).join(' · ')}
                      </p>
                    </div>
                  )}
                  {asset.alternateContactNumber && (
                    <div className="flex items-center gap-3">
                      <Phone className="w-4 h-4 text-gray-300 shrink-0" />
                      <p className="text-sm text-gray-500">Alt: {asset.alternateContactNumber}</p>
                    </div>
                  )}
                  {asset.address && (
                    <div className="flex items-start gap-3">
                      <MapPin className="w-4 h-4 text-gray-400 shrink-0 mt-0.5" />
                      <p className="text-sm text-gray-600 leading-relaxed">{fmtAddress(asset.address)}</p>
                    </div>
                  )}
                  {!asset.clientName && !asset.primaryContactName && !asset.address && (
                    <p className="text-xs text-gray-400">No client info on record.</p>
                  )}
                </div>
              )}
            </div>

            {/* History accordion */}
            <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
              <button
                onClick={() => setShowHistory(v => !v)}
                className="w-full flex items-center justify-between px-4 py-4"
              >
                <p className="text-xs font-bold text-gray-500 uppercase tracking-wider">
                  History
                  <span className="ml-1.5 normal-case font-normal text-gray-400">({search.entries.length})</span>
                </p>
                {showHistory
                  ? <ChevronUp className="w-4 h-4 text-gray-400" />
                  : <ChevronDown className="w-4 h-4 text-gray-400" />}
              </button>
              {showHistory && (
                <div className="border-t border-gray-50">
                  {search.entries.length === 0 ? (
                    <p className="text-xs text-gray-400 px-4 py-4">No commissioning history yet.</p>
                  ) : (
                    <div className="divide-y divide-gray-50 pb-1">
                      {search.entries.map(entry => (
                        <div key={entry._id} className="flex items-center gap-3 px-4 py-3">
                          <span className={`shrink-0 text-[10px] font-semibold px-2.5 py-1 rounded-full ${TYPE_COLOR[entry.type] ?? 'bg-gray-100 text-gray-500'}`}>
                            {TYPE_LABEL[entry.type] ?? entry.type}
                          </span>
                          <p className="flex-1 text-xs text-gray-500 truncate">{entry.assignedTo?.name ?? '—'}</p>
                          <span className={`shrink-0 text-[10px] font-semibold px-2.5 py-1 rounded-full ${STATUS_PILL[entry.status] ?? 'bg-gray-100 text-gray-500'}`}>
                            {entry.status.replace(/_/g, ' ')}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>


      {/* Assign sheet — rendered at page level so z-index clears the action sheet */}
      {canAssign && (() => {
        const selfItem: SelectSheetItem | null = (userId && (isAM || userRole === 'dealer'))
          ? { id: userId, label: `${userName ?? 'Me'} (You)`, sublabel: isAM ? 'Area Manager' : 'Dealer', avatar: { name: userName ?? 'Me', userId } }
          : null
        const teamItems: SelectSheetItem[] = actions.assignableUsers.map(u => ({
          id:       u._id,
          label:    u.role === 'dealer' ? (u.dealerName || u.name) : u.name,
          sublabel: u.role === 'dealer' ? u.name : (u.dealerName || 'Engineer'),
          avatar:   { name: u.name, userId: u._id },
        }))
        const allItems = selfItem ? [selfItem, ...teamItems] : teamItems
        return (
          <MobileSelectSheet
            open={assignSheetOpen}
            title="Assign To"
            items={allItems}
            value={actions.assignedToId}
            onChange={id => { actions.setAssignedToId(id) }}
            onClose={() => setAssignSheetOpen(false)}
            onConfirm={() => setAssignSheetOpen(false)}
            confirmLabel="Select"
            confirmIcon={<UserRoundCog className="w-4 h-4" />}
            searchPlaceholder="Search by name…"
            emptyLabel="No users available."
            resultLabel={n => `${n} user${n !== 1 ? 's' : ''} available`}
          />
        )
      })()}
    </div>
  )
}
