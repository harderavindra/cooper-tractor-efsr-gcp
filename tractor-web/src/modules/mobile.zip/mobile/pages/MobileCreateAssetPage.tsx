import { useEffect } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { ChevronLeft, Info, MapPin, AlertCircle } from 'lucide-react'
import { useCreateAsset } from '../../commissioning/hooks/useCreateAsset'
import { lookupPincode } from '../../../shared/lib/locationApi'
import type { SapAssetSearchResult } from '../../commissioning/types'
import type { Asset } from '../../../shared/data/types'

const ENTRY_TYPES = [
  { value: 'PRE_COMMISSIONING', label: 'Pre-Commissioning' },
  { value: 'COMMISSIONING',     label: 'Commissioning'     },
  { value: 'REVALIDATION',      label: 'Revalidation'      },
  { value: 'RE_COMMISSIONING',  label: 'Re-Commissioning'  },
]

const inputCls = 'w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#E76124]'

function fmtDate(d: string | undefined): string {
  if (!d) return '—'
  return new Date(d).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

type DispatchType = 'auto' | 'window' | 'revalidation' | 'no_date'

function getDispatchType(billingDate?: string | null): DispatchType {
  if (!billingDate) return 'no_date'
  const date        = new Date(billingDate)
  const AUTO_CUTOFF = new Date('2024-07-01')
  const sixMonthsAgo = new Date()
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6)
  if (date < AUTO_CUTOFF)  return 'auto'
  if (date >= sixMonthsAgo) return 'window'
  return 'revalidation'
}

export default function MobileCreateAssetPage() {
  const navigate  = useNavigate()
  const location  = useLocation()
  const state     = location.state as { sapRecord?: SapAssetSearchResult; returnTo?: string; context?: string } | null
  const sapRecord = state?.sapRecord
  const returnTo  = state?.returnTo ?? '/mobile/commissioning/new'
  const isService = state?.context === 'service'

  const dispatchType: DispatchType = getDispatchType(sapRecord?.billingDate)

  const ca = useCreateAsset((created: Asset) => {
    navigate(`${returnTo}?asset=${created._id}`, { replace: true })
  })

  useEffect(() => {
    if (sapRecord) {
      ca.prefillFromSap(sapRecord, dispatchType === 'revalidation' || dispatchType === 'auto')
    }
  }, []) // eslint-disable-line react-hooks/exhaustive-deps

  async function handlePinChange(pin: string) {
    ca.setNewAddress(prev => ({ ...prev, pinCode: pin }))
    if (pin.length === 6) {
      const loc = await lookupPincode(pin)
      if (loc) {
        ca.setNewAddress(prev => ({
          ...prev,
          locality: loc.post_office,
          taluk:    loc.taluka,
          district: loc.district,
          state:    loc.state,
        }))
      }
    }
  }

  const addr      = ca.newAddress
  const canSubmit = !ca.creating && !!ca.newGensetSN.trim() && !!ca.newEngineSN.trim()

  return (
    <div className="min-h-screen ">

      {/* Header */}
      <div className="px-5 pt-6 pb-4 flex items-center gap-3 border-b border-gray-100">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full bg-white flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <div className="flex-1 min-w-0">
          <p className="text-base font-extrabold text-gray-900 leading-tight">
            {dispatchType === 'auto' ? 'Create Asset' : 'Create Asset'}
          </p>
          <p className="text-xs text-gray-400 mt-0.5">
            {dispatchType === 'auto'   && 'Commissioning entry will be created automatically'}
            {dispatchType === 'window' && 'Commission this asset after registration'}
            {dispatchType === 'revalidation' && 'Revalidation required after registration'}
          </p>
        </div>
      </div>

      {/* Scrollable form */}
      <div className="px-5 pt-4 pb-4 space-y-5">

        {/* SAP banner + info card */}
        {sapRecord && (
          <div className="space-y-3">
            {/* Banner */}
            <div className="bg-[#fef4ef] border border-[#E76124]/30 rounded-2xl px-4 py-3 flex items-start gap-3">
              <Info className="w-5 h-5 text-[#E76124] shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-[#1E1951]">Found in SAP records</p>
                <p className="text-xs text-[#1E1951]/60 mt-0.5">
                  {isService
                    ? 'The form below is pre-filled from the SAP data. Create the asset to proceed with your service request.'
                    : 'The form below is pre-filled from the SAP data. Review and create the asset to proceed with commissioning.'}
                </p>
              </div>
            </div>

            {/* SAP info card */}
            <div className="bg-white border border-[#E76124]/20 rounded-2xl overflow-hidden shadow-sm">
              {/* card header */}
              <div className="px-4 py-3 border-b border-[#E76124]/10 bg-[#fef4ef] flex items-center justify-between gap-2 flex-wrap">
                <div className="flex items-center gap-2">
                  <p className="text-sm font-bold text-[#1E1951]">{sapRecord.gensetSerialNo}</p>
                  <span className="text-[10px] font-bold bg-[#E76124] text-white px-2 py-0.5 rounded-full">SAP</span>
                </div>
                <div className="flex items-center gap-2">
                  {sapRecord.gensetRating && (
                    <span className="text-xs font-semibold text-[#E76124] bg-[#fde9df] px-2.5 py-1 rounded-full">{sapRecord.gensetRating}</span>
                  )}
                  {sapRecord.cpcbStage && (
                    <span className="text-xs font-semibold text-[#1E1951] bg-[#1E1951]/10 px-2.5 py-1 rounded-full">{sapRecord.cpcbStage}</span>
                  )}
                </div>
              </div>
              {/* data grid */}
              <div className="px-4 py-4 grid grid-cols-2 gap-x-4 gap-y-3">
                {([
                  ['Genset S/N',       sapRecord.gensetSerialNo],
                  ['Engine S/N',       sapRecord.engineSerialNo],
                  ['Invoice No.',      sapRecord.invoiceNumber],
                  ['Billing Date',     fmtDate(sapRecord.billingDate)],
                  ['Material No.',     sapRecord.materialNo],
                  ['Ship-To Party',    sapRecord.shipToPartyName || sapRecord.shipToParty],
                  ['Zone',             sapRecord.zone],
                  ['Segment',          sapRecord.customerSegment],
                  ['Commissioning Dt', sapRecord.commissioningDate ? fmtDate(sapRecord.commissioningDate) : undefined],
                ] as [string, string | undefined][]).map(([label, val]) => val ? (
                  <div key={label}>
                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">{label}</p>
                    <p className="text-xs font-semibold text-[#1E1951] leading-snug">{val}</p>
                  </div>
                ) : null)}
                {sapRecord.endCustomerDetails && (
                  <div className="col-span-2">
                    <p className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">End Customer</p>
                    <p className="text-xs font-semibold text-[#1E1951]">{sapRecord.endCustomerDetails}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Asset Details */}
        <div className="bg-white rounded-2xl px-4 py-4 space-y-3">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Asset Details</p>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">
                Genset S/N <span className="text-red-400">*</span>
              </label>
              <input value={ca.newGensetSN} onChange={e => ca.setNewGensetSN(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">
                Engine S/N <span className="text-red-400">*</span>
              </label>
              <input value={ca.newEngineSN} onChange={e => ca.setNewEngineSN(e.target.value)} className={inputCls} />
            </div>
          </div>
        </div>

        {/* Client */}
        <div className="bg-white rounded-2xl px-4 py-4 space-y-3">
          <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Client</p>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Client Name</label>
              <input value={ca.newClientName} onChange={e => ca.setNewClientName(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Client Code</label>
              <input value={ca.newClientCode} onChange={e => ca.setNewClientCode(e.target.value)} className={inputCls} />
            </div>
          </div>
        
          <div className="grid grid-cols-2 gap-2">
              <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">Client Email</label>
            <input type="email" value={ca.newClientEmail} onChange={e => ca.setNewClientEmail(e.target.value)} className={inputCls} />
          </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Primary Contact</label>
              <input value={ca.newPrimaryContactName} onChange={e => ca.setNewPrimaryContactName(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Contact No.</label>
              <input type="tel" value={ca.newPrimaryContactNo} onChange={e => ca.setNewPrimaryContactNo(e.target.value)} className={inputCls} />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Alternate Contact No.</label>
              <input type="tel" value={ca.newAlternateContactNo} onChange={e => ca.setNewAlternateContactNo(e.target.value)} className={inputCls} />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">Dispatch Date</label>
            <input type="date" value={ca.newDispatchDate} onChange={e => ca.setNewDispatchDate(e.target.value)} className={inputCls} />
          </div>
        </div>

        {/* Address */}
        <div className="bg-white rounded-2xl px-4 py-4 space-y-3">
          <div className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5 text-gray-400" />
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Address</p>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">Address Line 1</label>
            <input
              value={addr.line1 ?? ''}
              onChange={e => ca.setNewAddress(prev => ({ ...prev, line1: e.target.value }))}
              className={inputCls}
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">Address Line 2</label>
            <input
              value={addr.line2 ?? ''}
              onChange={e => ca.setNewAddress(prev => ({ ...prev, line2: e.target.value }))}
              className={inputCls}
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">PIN Code</label>
              <input
                value={addr.pinCode ?? ''}
                onChange={e => handlePinChange(e.target.value)}
                maxLength={6}
                inputMode="numeric"
                className={inputCls}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">City</label>
              <input
                value={addr.city ?? ''}
                onChange={e => ca.setNewAddress(prev => ({ ...prev, city: e.target.value }))}
                className={inputCls}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">District</label>
              <input
                value={addr.district ?? ''}
                onChange={e => ca.setNewAddress(prev => ({ ...prev, district: e.target.value }))}
                className={inputCls}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">State</label>
              <input
                value={addr.state ?? ''}
                onChange={e => ca.setNewAddress(prev => ({ ...prev, state: e.target.value }))}
                className={inputCls}
              />
            </div>
          </div>
        </div>

        {/* Commissioning Entry — conditional on dispatch logic; entry form hidden in service context */}
        {dispatchType === 'auto' && (
          <div className="bg-green-50 border border-green-200 rounded-2xl px-4 py-4 flex items-start gap-3">
            <span className="w-2 h-2 rounded-full bg-green-500 shrink-0 mt-1.5" />
            <div>
              <p className="text-xs font-bold text-green-700">Auto-Commissioned</p>
              <p className="text-xs text-green-600 mt-0.5 leading-relaxed">
                Dispatch date ({fmtDate(sapRecord?.billingDate)}) is before July 2024 — a completed commissioning entry will be created automatically when this asset is registered.
              </p>
            </div>
          </div>
        )}

        {(dispatchType === 'revalidation' || dispatchType === 'auto') && ca.commissioningDate && (
          <div className="bg-white rounded-2xl px-4 py-4 space-y-3">
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Commissioning Entry <span className="normal-case font-normal text-gray-300">(from SAP)</span></p>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Entry Type</label>
              <select
                value={ca.commissioningType}
                onChange={e => ca.setCommissioningType(e.target.value)}
                className={`${inputCls} bg-white`}
              >
                {ENTRY_TYPES.map(t => (
                  <option key={t.value} value={t.value}>{t.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Date <span className="font-normal text-gray-400">(pre-filled from SAP)</span></label>
              <input
                type="date"
                value={ca.commissioningDate}
                onChange={e => ca.setCommissioningDate(e.target.value)}
                className={inputCls}
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">
                Notes <span className="font-normal text-gray-400">(optional)</span>
              </label>
              <textarea
                value={ca.commissioningNotes}
                onChange={e => ca.setCommissioningNotes(e.target.value)}
                rows={2}
                className={`${inputCls} resize-none`}
              />
            </div>
          </div>
        )}

        {ca.createError && (
          <div className="flex items-center gap-2 bg-red-50 border border-red-100 rounded-2xl px-4 py-3">
            <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
            <p className="text-xs text-red-600">{ca.createError}</p>
          </div>
        )}
      </div>

      {/* Sticky action bar */}
      <div className=" bottom-0 inset-x-0 px-5 pt-3 pb-8 flex gap-3 ">
        <button
          onClick={() => navigate(-1)}
          className="flex-1 py-3 rounded-2xl bg-white border border-gray-200 text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors"
        >
          Cancel
        </button>
        <button
          onClick={ca.handleCreate}
          disabled={!canSubmit}
          className="flex-1 py-3 rounded-2xl bg-[#E76124] text-white text-sm font-bold disabled:opacity-40 hover:bg-[#cf5520] transition-colors"
        >
          {ca.creating ? 'Creating…' : 'Confirm & Create'}
        </button>
      </div>
    </div>
  )
}
