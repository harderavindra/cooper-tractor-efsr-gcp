import { useState, useEffect, useMemo, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import {
  Bell,
  FileCheck,
  FileCog,
  AlertTriangle,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  XCircle,
  UserRoundCog,
  Handshake,
  Cog,
} from "lucide-react";
import { useAuth } from "../../../shared/context/AuthContext";
import { useMobileTeam } from "../context/MobileTeamContext";
import { Avatar } from "../../../shared/components/Avatar";
import { api } from "../../../shared/lib/api";
import { MobileCommCard } from "../components/MobileCommCard";
import { MobileSelectSheet } from "../components/MobileSelectSheet";
import { reassignEntry } from "../../commissioning/services/commissioningApi";
import { MobileSRCard } from "../components/MobileSRCard";
import { serviceApi } from "../../service/services/serviceApi";
import { timeAgo } from "../../../shared/utils/dateUtils";
import type {
  CommissioningTask,
  ServiceTask,
} from "../../../shared/hooks/useMyTasks";
import { SR_CATEGORIES } from "../../service/data/serviceCategories";
import { AssetGensetBlock } from "../components/AssetGensetBlock";

const SR_CAT_MAP = Object.fromEntries(
  SR_CATEGORIES.map((c) => [c.letter, c.title]),
);

const ACTIVE = ["ASSIGNED", "ACCEPTED", "IN_PROGRESS"];

// ── API shape ─────────────────────────────────────────────────────────────────

interface TaskCounts {
  active: number;
  completed: number;
  closed: number;
  total: number;
}

interface ApprovalItem {
  _id: string;
  title?: string;
  srNumber?: string;
  status: string;
  category?: string;
  date: string;
  workApproval?: {
    status: string;
    rejectedBy?: string;
    rejectionNote?: string;
  };
  partApproval?: { status: string };
  asset: { gensetNumber: string; clientName?: string; engineNumber?: string };
  createdBy?: { name: string; userId?: string; profilePic?: string };
  assignedTo?: { name: string; userId?: string; profilePic?: string };
}

interface DashboardData {
  counts: { commissioning: TaskCounts; service: TaskCounts };
  activeTasks: { commissioning: CommissioningTask[]; service: ServiceTask[] };
  recentCompleted: {
    commissioning: CommissioningTask[];
    service: ServiceTask[];
  };
  approvalList: ApprovalItem[];
  summaryCounts?: {
    myActive: number;
    teamActive: number;
    overdue: number;
    pendingApproval: number;
    completed: number;
  };
  teamAvatars?: { _id: string; activeCount: number }[];
}

// ── Approval List ─────────────────────────────────────────────────────────────

const APPROVAL_BADGE: Record<
  string,
  { label: string; cls: string; icon: React.ReactNode }
> = {
  PENDING_AM: {
    label: "Awaiting AM",
    cls: "bg-amber-100 text-amber-700",
    icon: <Clock className="w-3 h-3" />,
  },
  PENDING_RSM: {
    label: "Awaiting RSM",
    cls: "bg-blue-100 text-blue-700",
    icon: <Clock className="w-3 h-3" />,
  },
  REJECTED: {
    label: "Rejected",
    cls: "bg-red-100 text-red-600",
    icon: <XCircle className="w-3 h-3" />,
  },
};

function ApprovalListSection({ items }: { items: ApprovalItem[] }) {
  const navigate = useNavigate();
  const [idx, setIdx] = useState(0);

  if (items.length === 0) return null;

  const safeIdx = Math.min(idx, items.length - 1);

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-3">
          <p className="text-base font-bold text-gray-900">SR Approvals</p>
          <button
            onClick={() => navigate("/mobile/sr-approvals")}
            className="text-xs font-semibold text-[#E76124] hover:underline transition-colors"
          >
            Show all
          </button>
        </div>
        <div className="flex items-center gap-1.5">
          <button
            onClick={() => setIdx((i) => Math.max(0, i - 1))}
            disabled={safeIdx === 0}
            className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity"
          >
            <ChevronLeft className="w-4 h-4 text-gray-600" />
          </button>
          <span className="text-sm text-gray-400 min-w-[32px] text-center">
            {safeIdx + 1}/{items.length}
          </span>
          <button
            onClick={() => setIdx((i) => Math.min(items.length - 1, i + 1))}
            disabled={safeIdx === items.length - 1}
            className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity"
          >
            <ChevronRight className="w-4 h-4 text-gray-600" />
          </button>
        </div>
      </div>

      <div className="overflow-hidden">
        <div
          className="flex transition-transform duration-300 ease-in-out"
          style={{ transform: `translateX(-${safeIdx * 100}%)` }}
        >
          {items.map((it) => {
            const waBadge = it.workApproval?.status
              ? APPROVAL_BADGE[it.workApproval.status]
              : null;
            const hasPaPending = it.partApproval?.status === "PENDING";
            return (
              <div key={it._id} className="w-full shrink-0">
                <button
                  onClick={() => navigate(`/mobile/service/${it._id}`)}
                  className="w-full bg-white rounded-2xl px-4 py-3 shadow-sm text-left hover:shadow-md transition-shadow space-y-1.5"
                >
                
                  <AssetGensetBlock
                    asset={it.asset}
                    variant="service"
                    srNumber={it.srNumber}
                    createdBy={it.createdBy ?? null}
                    assignedTo={it.assignedTo ?? null}
                  />
                    {/* Row 1: SR number · category */}
                  <div className="flex items-center bg-gray-100 px-3 py-3 rounded-lg gap-2">
                   <Cog size={24} />
                    {it.category && (
                      <span className="text-xs font-bold text-[#1E1951]">
                        {it.category} · {SR_CAT_MAP[it.category] ?? it.category}
                      </span>
                    )}
                  </div>
                  {/* Row 3: engine number · badge */}
                  <div className="flex items-center justify-between gap-2 py-2">
                    {waBadge ? (
                      <span
                        className={`inline-flex items-center gap-1 font-semibold px-2 py-0.5 rounded-full shrink-0 ${waBadge.cls}`}
                      >
                        {waBadge.icon} {waBadge.label}
                      </span>
                    ) : hasPaPending ? (
                      <span className="inline-flex items-center gap-1  font-semibold px-2 py-0.5 rounded-full shrink-0 bg-orange-100 text-orange-700">
                        <Clock className="w-3 h-3" /> Parts · Pending
                      </span>
                    ) : null}

                     <span className="text-sm text-gray-800  font-bold shrink-0">
                      {timeAgo(it.date)}
                    </span>
                  </div>
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

// ── Weekly Insights ───────────────────────────────────────────────────────────

const WEEK_DAYS = ["MO", "TU", "WE", "TH", "FR", "SA", "SU"];
const BAR_MAX_H = 80;

function toMonIdx(jsDay: number) {
  return jsDay === 0 ? 6 : jsDay - 1;
}

function weekStart(): Date {
  const d = new Date();
  const diff = d.getDay() === 0 ? -6 : 1 - d.getDay();
  d.setDate(d.getDate() + diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

interface StatTile {
  label: string;
  value: number;
  icon: React.ElementType;
  cls: string;
}

interface WeeklyInsightsProps {
  activeTasks: { createdAt: string }[];
  completedTasks: { createdAt: string }[];
  totalCount: number;
  activeCount: number;
  completedCount: number;
  stats: StatTile[];
}

function WeeklyInsights({
  activeTasks,
  completedTasks,
  totalCount,
  activeCount,
  completedCount,
  stats,
}: WeeklyInsightsProps) {
  const [tab, setTab] = useState<"weekly" | "overview">("weekly");

  const todayIdx = toMonIdx(new Date().getDay());
  const wStart = weekStart();
  const wEnd = new Date(wStart.getTime() + 7 * 86400000);

  const completedDay = Array(7).fill(0);
  const activeDay = Array(7).fill(0);
  for (const t of completedTasks) {
    const d = new Date(t.createdAt);
    if (d >= wStart && d < wEnd) completedDay[toMonIdx(d.getDay())]++;
  }
  for (const t of activeTasks) {
    const d = new Date(t.createdAt);
    if (d >= wStart && d < wEnd) activeDay[toMonIdx(d.getDay())]++;
  }

  const totals = WEEK_DAYS.map((_, i) => completedDay[i] + activeDay[i]);
  const maxVal = Math.max(...totals, 1);

  const statPills = [
    { label: "Total", value: totalCount, ring: "bg-gray-700" },
    { label: "Active", value: activeCount, ring: "bg-violet-500" },
    { label: "Completed", value: completedCount, ring: "bg-green-500" },
  ];

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <p className="text-base font-bold text-gray-900">Insights</p>
        <div className="flex items-center bg-gray-100 rounded-full p-0.5 gap-0.5">
          {(
            [
              ["weekly", "Weekly"],
              ["overview", "Overview"],
            ] as const
          ).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setTab(key)}
              className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${
                tab === key
                  ? "bg-white text-gray-900 shadow-sm"
                  : "text-gray-400"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {tab === "weekly" && (
        <>
          <div className="flex gap-2 mb-4">
            {statPills.map(({ label, value, ring }) => (
              <div
                key={label}
                className="flex flex-col flex-1 items-center gap-2 bg-white shadow-sm rounded-2xl px-3 py-2"
              >
                <span
                  className={`w-9 h-9 rounded-full ${ring} flex items-center justify-center text-white text-xs font-bold shrink-0`}
                >
                  {String(value).padStart(2, "0")}
                </span>
                <span className="text-xs text-gray-500">{label}</span>
              </div>
            ))}
          </div>
          <div className="bg-white rounded-3xl px-4 pt-4 pb-3 shadow-sm">
            <div className="flex items-end justify-between gap-2">
              {WEEK_DAYS.map((day, i) => {
                const total = totals[i];
                const totalH =
                  total > 0
                    ? Math.max(14, Math.round((total / maxVal) * BAR_MAX_H))
                    : 0;
                const greenH =
                  total > 0
                    ? Math.round((completedDay[i] / total) * totalH)
                    : 0;
                const purpleH = totalH - greenH;
                const isToday = i === todayIdx;
                return (
                  <div
                    key={day}
                    className="flex flex-col items-center gap-1.5 flex-1 min-w-0"
                  >
                    <span className="text-[10px] text-gray-400 h-4 leading-4 tabular-nums">
                      {total > 0 ? total : "0"} / {completedDay[i] }
                    </span>
                    <div
                      className="w-full max-w-[14px] rounded-full bg-gray-200 overflow-hidden flex flex-col justify-end"
                      style={{ height: `${BAR_MAX_H}px` }}
                    >
                      {total > 0 && (
                        <div
                          className="w-full flex flex-col"
                          style={{ height: `${totalH}px` }}
                        >
                          {purpleH > 0 && (
                            <div
                              className={`w-full ${isToday ? "bg-violet-500" : "bg-violet-500"}`}
                              style={{ height: `${purpleH}px` }}
                            />
                          )}
                          {greenH > 0 && (
                            <div
                              className="w-full bg-green-500"
                              style={{ height: `${greenH}px` }}
                            />
                          )}
                        </div>
                      )}
                    </div>
                    <span
                      className={`text-[10px] leading-none ${isToday ? "font-bold text-gray-900" : "text-gray-400"}`}
                    >
                      {day}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </>
      )}

      {tab === "overview" && (
        <div className="grid grid-cols-4 gap-2">
          {stats.map(({ label, value, icon: Icon, cls }) => (
            <div
              key={label}
              className="bg-white rounded-2xl px-3 py-3 flex flex-col gap-1"
            >
              <div
                className={`w-8 h-8 rounded-full ${cls} flex items-center justify-center shrink-0`}
              >
                <Icon className="w-4 h-4 text-white" />
              </div>
              <p className="text-xl font-bold leading-none">{value}</p>
              <p className="text-[10px] text-gray-400 leading-tight">{label}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function greeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good Morning";
  if (h < 17) return "Good Afternoon";
  return "Good Evening";
}

// ── Dashboard ─────────────────────────────────────────────────────────────────

export default function MobileDashboard() {
  const navigate = useNavigate();
  const { name, profilePic, userId, role } = useAuth();
  const { members: teamMembers } = useMobileTeam();
  const isDealer = role === "dealer";
  const isAM = role === "area_manager";

  const [dash, setDash] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [cardIdx, setCardIdx] = useState(0);
  const [recentIdx, setRecentIdx] = useState(0);

  const [assignSheet, setAssignSheet] = useState<{
    taskId: string;
    type: "accepted" | "active";
    subtitle: string;
    source: "comm" | "sr";
  } | null>(null);
  const [selectedEng, setSelectedEng] = useState("");
  const [assigning, setAssigning] = useState(false);
  const [assignError, setAssignError] = useState("");
  const [selectedMemberId, setSelectedMemberId] = useState<string | null>(null);

  function selectMember(id: string) {
    setSelectedMemberId((prev) => (prev === id ? null : id));
    setCardIdx(0);
  }

  async function confirmAssign() {
    if (!assignSheet || !selectedEng) return;
    setAssigning(true);
    setAssignError("");
    try {
      if (assignSheet.source === "sr") {
        if (assignSheet.type === "active") {
          await serviceApi.acceptEntry(assignSheet.taskId);
        }
        await serviceApi.reassignEntry(assignSheet.taskId, selectedEng);
      } else {
        await reassignEntry(assignSheet.taskId, selectedEng);
      }
      reloadDashboard();
      setAssignSheet(null);
      setSelectedEng("");
    } catch (err) {
      setAssignError(err instanceof Error ? err.message : "Assignment failed");
    } finally {
      setAssigning(false);
    }
  }

  const reloadDashboard = useCallback(() => {
    api
      .get<DashboardData>("/api/me/dashboard")
      .then(setDash)
      .catch(() => {});
  }, []);

  useEffect(() => {
    api
      .get<DashboardData>("/api/me/dashboard")
      .then(setDash)
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const commTasks = dash?.activeTasks.commissioning ?? [];
  const srTasks = dash?.activeTasks.service ?? [];

  const totalActive =
    (dash?.counts.commissioning.active ?? 0) +
    (dash?.counts.service.active ?? 0);
  const overdueCount =
    isAM && dash?.summaryCounts
      ? dash.summaryCounts.overdue
      : [...commTasks, ...srTasks].filter((t) => t.isOverdue).length;

  const commActiveCount = dash?.counts.commissioning.active ?? 0;
  const srActiveCount = dash?.counts.service.active ?? 0;
  const completedCount =
    (dash?.counts.commissioning.completed ?? 0) +
    (dash?.counts.service.completed ?? 0);

  type SlideItem =
    | { kind: "comm"; task: CommissioningTask }
    | { kind: "sr"; task: ServiceTask };

  const slides = useMemo<SlideItem[]>(() => {
    const memberFilter =
      isAM && selectedMemberId !== null
        ? (t: { assignedTo?: { userId?: string } }) =>
            t.assignedTo?.userId?.toString() === selectedMemberId
        : () => true;
    return [
      ...commTasks
        .filter((t) => ACTIVE.includes(t.status) && memberFilter(t))
        .map((t) => ({ kind: "comm" as const, task: t })),
      ...srTasks
        .filter((t) => ACTIVE.includes(t.status) && memberFilter(t))
        .map((t) => ({ kind: "sr" as const, task: t })),
    ].sort(
      (a, b) =>
        new Date(a.task.date).getTime() - new Date(b.task.date).getTime(),
    );
  }, [commTasks, srTasks, isAM, selectedMemberId]);

  const safeIdx = Math.min(cardIdx, Math.max(0, slides.length - 1));

  const recentCompleted = useMemo<SlideItem[]>(() => {
    const comm = (dash?.recentCompleted.commissioning ?? []).map((t) => ({
      kind: "comm" as const,
      task: t,
    }));
    const sr = (dash?.recentCompleted.service ?? []).map((t) => ({
      kind: "sr" as const,
      task: t,
    }));
    return [...comm, ...sr]
      .sort(
        (a, b) =>
          new Date(b.task.createdAt).getTime() -
          new Date(a.task.createdAt).getTime(),
      )
      .slice(0, 3);
  }, [dash]);

  const safeRecent = Math.min(recentIdx, Math.max(0, recentCompleted.length - 1));

  // Merge stable identity (context) with live activeCount (dashboard)
  const enrichedTeam = useMemo(() => {
    const countMap = new Map((dash?.teamAvatars ?? []).map(a => [a._id, a.activeCount ?? 0]));
    return teamMembers.map(m => ({ ...m, activeCount: countMap.get(m._id) ?? 0 }));
  }, [teamMembers, dash?.teamAvatars]);

  const engineerItems = useMemo(() => enrichedTeam.map((m) => ({
    id: m._id,
    label: m.role === "dealer" ? (m.dealerName || m.name) : m.name,
    sublabel: m.role === "dealer" ? m.name : (m.dealerName || "Engineer"),
    avatar: { name: m.dealerName || m.name, userId: m._id, photo: m.profilePic ?? undefined },
  })), [enrichedTeam]);

  const stats = useMemo<StatTile[]>(() => [
    { label: "Comm Active", value: commActiveCount, icon: FileCheck,    cls: "bg-[#E76124]" },
    { label: "SR Active",   value: srActiveCount,   icon: FileCog,      cls: "bg-[#1E1951]" },
    { label: "Overdue",     value: overdueCount,    icon: AlertTriangle, cls: overdueCount > 0 ? "bg-red-500" : "bg-gray-400" },
    { label: "Completed",   value: completedCount,  icon: CheckCircle2, cls: "bg-green-600" },
  ], [commActiveCount, srActiveCount, overdueCount, completedCount]);

  return (
    <div className="px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar
            name={name ?? "?"}
            userId={userId ?? undefined}
            photo={profilePic ?? undefined}
            size="lg"
            showPopover={true}
          />
          <div>
            <p className="text-sm text-gray-400">{greeting()} !</p>
            <p className="text-base font-bold text-gray-900">{name}</p>
          </div>
        </div>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>

      {/* Hero */}
      <div className="space-y-3">
        <div>
          <p className="text-3xl text-gray-400 leading-snug">
            {isDealer ? "Your team have" : "You have"}{" "}
            <span className="text-gray-900 font-bold">{totalActive}</span>
          </p>
          <p className="text-3xl font-bold text-gray-900">active Tasks</p>
        </div>

        {/* Team avatars */}
        {(isDealer || isAM) && enrichedTeam.length > 0 && (
          <div className="flex gap-3 overflow-x-auto pb-1 pt-1 pl-1 no-scrollbar">
            {userId &&
              name &&
              (() => {
                const myCount = [...commTasks, ...srTasks].filter(
                  (t) =>
                    ACTIVE.includes(t.status) &&
                    (
                      t.assignedTo as { userId?: string } | undefined
                    )?.userId?.toString() === userId,
                ).length;
                const isSelected = isAM && selectedMemberId === userId;
                return (
                  <button
                    onClick={() => isAM && selectMember(userId)}
                    className={`flex flex-col items-center gap-1 shrink-0 ${isAM ? "cursor-pointer" : ""}`}
                  >
                    <div className="relative">
                      <div
                        className={`rounded-full transition-all ${isSelected ? "ring-2 ring-[#E76124] ring-offset-2" : ""}`}
                      >
                        <Avatar
                          name={name}
                          userId={userId}
                          photo={profilePic ?? undefined}
                          size="xl"
                          showPopover={!isAM}
                          popoverPos="right"
                        />
                      </div>
                      {myCount > 0 && (
                        <span className="absolute -top-1 -right-1 min-w-[16px] h-4 rounded-full bg-[#E76124] text-white text-[9px] font-bold flex items-center justify-center px-0.5 leading-none ring-1 ring-white">
                          {myCount}
                        </span>
                      )}
                      {isDealer && (
                        <span className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-[#E76124] ring-2 ring-white" >
                          <Handshake size={10} className="w-3 h-3 text-white" />
                        </span>
                      )}
                    </div>
                    <p
                      className={`text-[10px] font-bold ${isSelected ? "text-[#E76124]" : "text-gray-400"}`}
                    >
                      You
                    </p>
                  </button>
                );
              })()}
            {[...enrichedTeam]
              .sort((a, b) => b.activeCount - a.activeCount)
              .map((m) => {
                const isSelected = isAM && selectedMemberId === m._id;
                const isMemberDealer = m.role === "dealer";
                const displayName = isMemberDealer ? (m.dealerName || m.name) : m.name.split(" ")[0];
                return (
                  <button
                    key={m._id}
                    onClick={() => isAM && selectMember(m._id)}
                    className={`flex flex-col items-center gap-1 shrink-0 ${isAM ? "cursor-pointer" : ""}`}
                  >
                    <div className="relative">
                      <div
                        className={`rounded-full transition-all ${isSelected ? "ring-2 ring-[#1E1951] ring-offset-2" : ""}`}
                      >
                        <Avatar
                          name={m.dealerName || m.name}
                          userId={m._id}
                          photo={m.profilePic ?? undefined}
                          size="xl"
                          showPopover={!isAM}
                          popoverPos="right"
                        />
                      </div>
                      {isMemberDealer && (
                        <span className="absolute -bottom-0.5 -right-0.5 w-6 h-6 rounded-full flex items-center justify-center bg-indigo-800">
                          <Handshake size={16} className=" text-white" />
                        </span>
                      )}
                      {m.activeCount > 0 && (
                        <span className="absolute -top-1 -right-1 min-w-[16px] h-4 rounded-full bg-[#E76124] text-white text-[9px] font-bold flex items-center justify-center px-0.5 leading-none ring-1 ring-white">
                          {m.activeCount}
                        </span>
                      )}
                    </div>
                    <p
                      className={`text-[10px] font-medium max-w-[52px] truncate text-center ${isSelected ? "text-[#1E1951] font-bold" : "text-gray-500"}`}
                    >
                      {displayName}
                    </p>
                  </button>
                );
              })}
          </div>
        )}
      </div>

      {loading && (
        <p className="text-sm text-gray-400 text-center py-8">Loading…</p>
      )}

      {/* Approval List */}
      {!loading && <ApprovalListSection items={dash?.approvalList ?? []} />}

      {/* Active Task carousel / Recent Completed fallback */}
      {!loading && (
        <section>
          {/* Section header */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2 min-w-0">
              <p className="text-base font-bold text-gray-900 shrink-0">
                {slides.length > 0 ? "Active Task" : "Recent Task"}
              </p>
              {isAM && selectedMemberId && (() => {
                const sel = enrichedTeam.find(m => m._id === selectedMemberId)
                if (!sel) return null
                const label = sel.role === 'dealer' ? (sel.dealerName || sel.name) : sel.name.split(' ')[0]
                return (
                  <span className="flex items-center gap-1 bg-[#1E1951] text-white text-xs font-semibold px-2 py-0.5 rounded-full max-w-[120px]">
                    <span className="truncate">{label}</span>
                    <button onClick={() => { setSelectedMemberId(null); setCardIdx(0) }} className="shrink-0 hover:opacity-70">
                      <XCircle className="w-3.5 h-3.5" />
                    </button>
                  </span>
                )
              })()}
            </div>
            {/* Pagination for active tasks */}
            {slides.length > 0 && (
              <div className="flex items-center gap-1.5">
                <button onClick={() => setCardIdx(i => Math.max(0, i - 1))} disabled={safeIdx === 0}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity">
                  <ChevronLeft className="w-4 h-4 text-gray-600" />
                </button>
                <span className="text-sm text-gray-400 min-w-[32px] text-center">{safeIdx + 1}/{slides.length}</span>
                <button onClick={() => setCardIdx(i => Math.min(slides.length - 1, i + 1))} disabled={safeIdx === slides.length - 1}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity">
                  <ChevronRight className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            )}
            {/* Pagination for recent completed */}
            {slides.length === 0 && recentCompleted.length > 1 && (
              <div className="flex items-center gap-1.5">
                <button onClick={() => setRecentIdx(i => Math.max(0, i - 1))} disabled={safeRecent === 0}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity">
                  <ChevronLeft className="w-4 h-4 text-gray-600" />
                </button>
                <span className="text-sm text-gray-400 min-w-[32px] text-center">{safeRecent + 1}/{recentCompleted.length}</span>
                <button onClick={() => setRecentIdx(i => Math.min(recentCompleted.length - 1, i + 1))} disabled={safeRecent === recentCompleted.length - 1}
                  className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center disabled:opacity-30 transition-opacity">
                  <ChevronRight className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            )}
          </div>

          {/* Active task carousel */}
          {slides.length > 0 && (
            <div className="overflow-hidden">
              <div className="flex transition-transform duration-300 ease-in-out"
                style={{ transform: `translateX(-${safeIdx * 100}%)` }}>
                {slides.map((item) => (
                  <div key={item.task._id} className="w-full shrink-0">
                    {item.kind === "comm" ? (
                      <MobileCommCard
                        task={item.task}
                        userId={userId ?? undefined}
                        isDealer={isDealer}
                        onReload={() => reloadDashboard()}
                        onOpenAssign={(taskId, type, subtitle) => {
                          setAssignSheet({ taskId, type, subtitle, source: "comm" });
                          setSelectedEng("");
                        }}
                      />
                    ) : (
                      <MobileSRCard
                        task={item.task}
                        isDealer={isDealer}
                        onOpenAssign={(taskId, type, subtitle) => {
                          setAssignSheet({ taskId, type, subtitle, source: "sr" });
                          setSelectedEng("");
                        }}
                        onAction={
                          item.task.assignedTo?.userId?.toString() === userId
                            ? () => {
                                if (item.task.status === "ASSIGNED") {
                                  const pa = item.task.preApproval;
                                  if (pa?.required && pa.status !== "APPROVED") return;
                                  serviceApi.acceptEntry(item.task._id).then(() => reloadDashboard()).catch(() => {});
                                } else if (item.task.status === "ACCEPTED") {
                                  serviceApi.startEntry(item.task._id).then(() => reloadDashboard()).catch(() => {});
                                } else {
                                  navigate(`/mobile/service/${item.task._id}/complete`);
                                }
                              }
                            : undefined
                        }
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Recent completed carousel */}
          {slides.length === 0 && recentCompleted.length > 0 && (
            <div className="overflow-hidden">
              <div className="flex transition-transform duration-300 ease-in-out"
                style={{ transform: `translateX(-${safeRecent * 100}%)` }}>
                {recentCompleted.map((item) => (
                  <div key={item.task._id} className="w-full shrink-0">
                    {item.kind === "comm" ? (
                      <MobileCommCard
                        task={item.task}
                        userId={userId ?? undefined}
                        isDealer={isDealer}
                        onReload={() => reloadDashboard()}
                        onOpenAssign={(taskId, type, subtitle) => {
                          setAssignSheet({ taskId, type, subtitle, source: "comm" });
                          setSelectedEng("");
                        }}
                      />
                    ) : (
                      <MobileSRCard
                        task={item.task}
                        isDealer={isDealer}
                        onOpenAssign={(taskId, type, subtitle) => {
                          setAssignSheet({ taskId, type, subtitle, source: "sr" });
                          setSelectedEng("");
                        }}
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* All caught up */}
          {slides.length === 0 && recentCompleted.length === 0 && (
            <div className="bg-white rounded-3xl px-5 py-10 text-center shadow-sm flex flex-col items-center gap-3">
              <div className="w-14 h-14 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle2 className="w-7 h-7 text-green-500" />
              </div>
              <div>
                <p className="text-base font-bold text-gray-900">All caught up!</p>
                <p className="text-sm text-gray-400 mt-1">No active tasks right now.</p>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Insights */}
      {!loading && dash && (
        <WeeklyInsights
          activeTasks={[...commTasks, ...srTasks]}
          completedTasks={[
            ...dash.recentCompleted.commissioning,
            ...dash.recentCompleted.service,
          ]}
          totalCount={totalActive + completedCount}
          activeCount={totalActive}
          completedCount={completedCount}
          stats={stats}
        />
      )}

      <MobileSelectSheet
        open={!!assignSheet}
        title={
          assignSheet?.type === "accepted"
            ? "Assign to Engineer"
            : "Reassign to Engineer"
        }
        subtitle={assignError || assignSheet?.subtitle}
        items={engineerItems}
        value={selectedEng}
        onChange={setSelectedEng}
        onClose={() => {
          setAssignSheet(null);
          setSelectedEng("");
          setAssignError("");
        }}
        onConfirm={confirmAssign}
        confirmLabel="Assign"
        confirmIcon={<UserRoundCog className="w-4 h-4" />}
        confirming={assigning}
        searchPlaceholder="Search by name…"
        emptyLabel="No engineers available."
        resultLabel={(n) => `${n} engineer${n !== 1 ? "s" : ""} available`}
      />
    </div>
  );
}
