import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronLeft, Bell } from 'lucide-react'
import { useEngineerTasks, type StatusGroup } from '../../commissioning/hooks/useEngineerTasks'
import { useTeamTasks, type TeamTask } from '../../../shared/hooks/useTeamTasks'
import { useAuth } from '../../../shared/context/AuthContext'
import { MobileCommCard } from '../components/MobileCommCard'
import type { CommissioningTask } from '../../../shared/hooks/useMyTasks'
import { MobileSearchBar } from '../components/MobileSearchBar'
import { MobileStatusTabs } from '../components/MobileStatusTabs'
import { MobilePageController } from '../components/MobilePageController'
const STATUS_EMPTY = {
  active:    "You're all caught up — no active tasks.",
  completed: 'No completed tasks yet.',
  closed:    'No closed tasks.',
}

const PAGE_SIZE = 5

const ACTIVE_STATUSES    = ['ASSIGNED', 'ACCEPTED', 'IN_PROGRESS']
const COMPLETED_STATUSES = ['COMPLETED', 'APPROVED']

// ── shared layout shell ───────────────────────────────────────────────────────

function PageShell({ children }: { children: React.ReactNode }) {
  const navigate = useNavigate()
  return (
    <div className="px-4 py-6 space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">Commissioning</p>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>
      {children}
    </div>
  )
}



// ── AM view ───────────────────────────────────────────────────────────────────

function MobileAMCommissioning() {
  const navigate = useNavigate()
  const { data, loading, error, reload } = useTeamTasks()
  const [status, setStatus] = useState<'active' | 'completed' | 'closed'>('active')
  const [search, setSearch] = useState('')
  const [pageIdx, setPageIdx] = useState(0)

  // Flatten all team commissioning tasks, deduplicated
  const allTasks = useMemo<TeamTask[]>(() => {
    if (!data) return []
    const seen = new Set<string>()
    const list: TeamTask[] = []
    const push = (t: TeamTask) => { if (!seen.has(t._id)) { seen.add(t._id); list.push(t) } }
    data.myTasks.commissioning.forEach(push)
    data.team.forEach(g => {
      g.ownTasks.commissioning.forEach(push)
      g.engineers.forEach(e => e.tasks.commissioning.forEach(push))
    })
    return list
  }, [data])

  const counts = useMemo(() => ({
    active:    allTasks.filter(t => ACTIVE_STATUSES.includes(t.status)).length,
    completed: allTasks.filter(t => COMPLETED_STATUSES.includes(t.status)).length,
    closed:    allTasks.filter(t => t.status === 'CLOSED').length,
  }), [allTasks])

  const visible = useMemo(() => {
    let list = allTasks.filter(t => {
      if (status === 'active')    return ACTIVE_STATUSES.includes(t.status)
      if (status === 'completed') return COMPLETED_STATUSES.includes(t.status)
      return t.status === 'CLOSED'
    })
    if (search) {
      const q = search.toLowerCase()
      list = list.filter(t =>
        t.asset?.gensetNumber?.toLowerCase().includes(q) ||
        t.asset?.clientName?.toLowerCase().includes(q) ||
        t.asset?.engineNumber?.toLowerCase().includes(q)
      )
    }
    return list
  }, [allTasks, status, search])

  const totalPages = Math.max(1, Math.ceil(visible.length / PAGE_SIZE))
  const safePage   = Math.min(pageIdx, totalPages - 1)
  const pageItems  = visible.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)

  function changeStatus(s: 'active' | 'completed' | 'closed') { setStatus(s); setPageIdx(0) }

  // Map TeamTask → CommissioningTask shape for MobileCommCard
  function toCommTask(t: TeamTask): CommissioningTask {
    return {
      ...t,
      type: 'COMMISSIONING',
      createdAt: t.date ?? new Date(0).toISOString(),
      notes: undefined,
      createdBy: t.assignedTo
        ? { userId: t.assignedTo.userId ?? '', name: t.assignedTo.name ?? '', role: '' }
        : undefined,
      statusHistory: [],
      actionLog: [],
    } as unknown as CommissioningTask
  }

  return (
    <PageShell>
      <div className="flex items-center justify-between gap-2">
        <MobileSearchBar value={search} onChange={v => { setSearch(v); setPageIdx(0) }} />
        <button
          onClick={() => navigate('/mobile/commissioning/new')}
          className="w-11 h-11 rounded-2xl bg-orange-600/60 flex items-center justify-center shrink-0 shadow-sm  transition-colors"
        >
          <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
          </svg>
        </button>
      </div>
      <MobileStatusTabs variant="commissioning" status={status} onChange={s => changeStatus(s as 'active' | 'completed' | 'closed')} counts={counts} />

      {error  && <div className="bg-red-50 text-red-600 text-sm rounded-xl px-4 py-3">{error}</div>}
      {loading && <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>}

      {!loading && visible.length > 0 && (
        <>
          <MobilePageController page={safePage} total={totalPages} onChange={setPageIdx} />
          <div className="space-y-3">
            {pageItems.map(t => (
              <MobileCommCard
                key={t._id}
                task={toCommTask(t)}
                userId={undefined}
                isDealer={false}
                onReload={reload}
              />
            ))}
          </div>
        </>
      )}

      {!loading && visible.length === 0 && (
        <div className="bg-white rounded-2xl px-5 py-12 text-center shadow-sm">
          <p className="text-sm text-gray-400">{STATUS_EMPTY[status]}</p>
        </div>
      )}
    </PageShell>
  )
}

// ── dealer / engineer view ────────────────────────────────────────────────────

export default function MobileCommissioning() {
  const navigate = useNavigate()
  const { role } = useAuth()
  const [pageIdx, setPageIdx] = useState(0)

  const {
    loading, error,
    status, setStatus,
    search, setSearch,
    counts,
    allTasks,
    isDealer,
    userId,
    reload,
  } = useEngineerTasks()

  if (role === 'area_manager') return <MobileAMCommissioning />

  const totalPages = Math.max(1, Math.ceil(allTasks.length / PAGE_SIZE))
  const safePage   = Math.min(pageIdx, totalPages - 1)
  const pageItems  = allTasks.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)

  function changeStatus(s: StatusGroup) { setStatus(s); setPageIdx(0) }

  return (
    <PageShell>
     

      <div className="flex justify-between items-center gap-2">
        <MobileSearchBar value={search} onChange={v => { setSearch(v); setPageIdx(0) }} />
        {isDealer && (
          <button
            onClick={() => navigate('/mobile/commissioning/new')}
            className="w-11 h-11 rounded-2xl bg-[#1E1951] flex items-center justify-center shrink-0 shadow-sm hover:bg-[#16123d] transition-colors"
          >
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
            </svg>
          </button>
        )}
      </div>
      <MobileStatusTabs variant="commissioning" status={status} onChange={s => changeStatus(s as StatusGroup)} counts={counts} />

      {error  && <div className="bg-red-50 text-red-600 text-sm rounded-xl px-4 py-3">{error}</div>}
      {loading && <p className="text-sm text-gray-400 py-16 text-center">Loading…</p>}

      {!loading && allTasks.length > 0 && (
        <>
          <MobilePageController page={safePage} total={totalPages} onChange={setPageIdx} />
          <div className="space-y-3">
            {pageItems.map(task => (
              <MobileCommCard
                key={task._id}
                task={task}
                userId={userId ?? undefined}
                isDealer={isDealer}
                onReload={reload}
              />
            ))}
          </div>
        </>
      )}

      {!loading && allTasks.length === 0 && (
        <div className="bg-white rounded-2xl px-5 py-12 text-center shadow-sm">
          <p className="text-sm text-gray-400">{STATUS_EMPTY[status]}</p>
        </div>
      )}
    </PageShell>
  )
}
