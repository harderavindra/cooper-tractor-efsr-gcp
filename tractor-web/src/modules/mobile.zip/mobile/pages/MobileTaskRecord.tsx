import { useEffect, useState } from 'react'
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import { ChevronLeft, CheckCircle2, XCircle, MessageSquare, Bell, ChevronDown, ChevronUp } from 'lucide-react'
import { PhotoImg } from '../../../shared/components/PhotoImg'
import { ActivityCard } from '../../../shared/components/ActivityCard'
import { VALIDATION_SECTIONS, getCheckValue, getCheckComment } from '../../../shared/data/validationChecks'
import { COMMISSIONING_SECTIONS, PERF_ROWS } from '../../commissioning/data/commissioningChecks'
import { getEntry } from '../../commissioning/services/commissioningApi'
import { api } from '../../../shared/lib/api'
import type { CommissioningTask } from '../../../shared/hooks/useMyTasks'
import type { Asset } from '../../../shared/data/types'
import type { CommissioningEntry } from '../../../shared/data/commissioningLogic'

// ── Constants ─────────────────────────────────────────────────────────────────

const TYPE_LABEL: Record<string, string> = {
  PRE_COMMISSIONING: 'Pre-Commissioning',
  COMMISSIONING:     'Commissioning',
  REVALIDATION:      'Revalidation',
  RE_COMMISSIONING:  'Re-Commissioning',
}

const ACTION_PILL: Record<string, string> = {
  PRE_COMMISSIONING: 'bg-blue-100 text-blue-700',
  COMMISSIONING:     'bg-green-100 text-green-700',
  REVALIDATION:      'bg-orange-100 text-orange-700',
  RE_COMMISSIONING:  'bg-purple-100 text-purple-700',
}
const ACTION_DOT: Record<string, string> = {
  PRE_COMMISSIONING: 'bg-blue-500',
  COMMISSIONING:     'bg-green-500',
  REVALIDATION:      'bg-orange-500',
  RE_COMMISSIONING:  'bg-purple-500',
}
const ACTION_SHORT: Record<string, string> = {
  PRE_COMMISSIONING: 'PreC',
  COMMISSIONING:     'C',
  REVALIDATION:      'ReV',
  RE_COMMISSIONING:  'ReC',
}

const STATUS_PILL: Record<string, string> = {
  OPEN:        'bg-gray-100 text-gray-600',
  ASSIGNED:    'bg-blue-100 text-blue-700',
  ACCEPTED:    'bg-indigo-100 text-indigo-700',
  IN_PROGRESS: 'bg-amber-100 text-amber-700',
  COMPLETED:   'bg-green-100 text-green-700',
  APPROVED:    'bg-emerald-100 text-emerald-700',
  CLOSED:      'bg-[#1E1951]/10 text-[#1E1951]',
}
const STATUS_LABEL: Record<string, string> = {
  OPEN: 'Open', ASSIGNED: 'Assigned', ACCEPTED: 'Accepted',
  IN_PROGRESS: 'In Progress', COMPLETED: 'Completed', APPROVED: 'Approved', CLOSED: 'Closed',
}

const PRIORITY_CLS: Record<string, string> = {
  P1: 'bg-red-100 text-red-700',
  P2: 'bg-orange-100 text-orange-700',
  P3: 'bg-blue-100 text-blue-700',
  P4: 'bg-gray-100 text-gray-500',
}

// ── Sub-components ────────────────────────────────────────────────────────────

function F({ label, value, mono, span2 }: {
  label: string; value?: string | number | boolean | null; mono?: boolean; span2?: boolean
}) {
  const display =
    value === undefined || value === null || value === '' ? '—'
    : typeof value === 'boolean' ? (value ? 'Yes' : 'No')
    : String(value)
  return (
    <div className={'px-3' + (span2 ? ' col-span-2' : '')}>
      <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">{label}</p>
      <p className={`text-sm font-bold text-gray-700 ${mono ? 'font-mono' : ''} ${display === '—' ? '!text-gray-300 !font-normal' : ''}`}>
        {display}
      </p>
    </div>
  )
}

function SectionHeading({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center w-full px-3 py-2 bg-indigo-100 rounded-full mb-3">
      <p className="text-sm font-bold capitalize tracking-wide text-gray-800">{children}</p>
    </div>
  )
}

function AssetInfoGroup({ label, children }: { label: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="bg-white p-4 rounded-4xl text-gray-950 text-gray-400">
      <button
        onClick={() => setOpen(v => !v)}
        className="flex items-center justify-between w-full px-3 py-2  bg-indigo-100 rounded-full group"
      >
        <p className="text-sm font-bold capitalize tracking-widest">{label}</p>
        <span className="text-xs font-medium  transition-colors">
          {open ? <ChevronUp /> : <ChevronDown />}
        </span>
      </button>
      {open && <div className="grid grid-cols-2 gap-x-4 gap-y-2.5 pt-6">{children}</div>}
    </div>
  )
}

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map(s => (
        <svg key={s} className={`w-4 h-4 ${s <= rating ? 'text-[#E76124]' : 'text-gray-200'}`} fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
        </svg>
      ))}
      <span className="text-xs text-gray-500 ml-1">
        {['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'][rating] ?? ''}
      </span>
    </div>
  )
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function MobileTaskRecord() {
  const { id }   = useParams<{ id: string }>()
  const navigate = useNavigate()
  const location = useLocation()

  const stateTask = (location.state as { task?: CommissioningTask } | null)?.task

  const [entry,   setEntry]   = useState<CommissioningEntry | null>(stateTask ?? null)
  const [asset,   setAsset]   = useState<Asset | null>(stateTask?.asset ?? null)
  const [loading, setLoading] = useState(true)
  const [error,   setError]   = useState<string | null>(null)
  const [lightbox, setLightbox] = useState<string | null>(null)
  const [openCommSections, setOpenCommSections] = useState<Set<string>>(new Set())

  function toggleCommSection(letter: string) {
    setOpenCommSections(prev => {
      const next = new Set(prev)
      next.has(letter) ? next.delete(letter) : next.add(letter)
      return next
    })
  }

  useEffect(() => {
    if (!id) return
    setLoading(true)
    getEntry(id)
      .then(async e => {
        setEntry(e)
        try { setAsset(await api.get<Asset>(`/api/assets/${e.assetId}`)) } catch { /* ignore */ }
      })
      .catch(() => setError('Could not load record.'))
      .finally(() => setLoading(false))
  }, [id])

  const typePill  = entry?.type ? ACTION_PILL[entry.type]  : 'bg-gray-100 text-gray-500'
  const typeDot   = entry?.type ? ACTION_DOT[entry.type]   : 'bg-gray-400'
  const typeShort = entry?.type ? ACTION_SHORT[entry.type] : '—'

  const photos = (entry as { photos?: string[] } | null)?.photos ?? []
  type FcRow = { codeId: { code: string; description: string; category: string; subCategory: string; priority?: string }; observation?: string; rootCause?: string; correctiveAction?: string }
  const faultCodes = ((entry as { faultCodes?: FcRow[] } | null)?.faultCodes ?? []) as FcRow[]
  type PartRow = { partId: { code: string; name: string; category: string; subCategory: string; unit: string }; quantity: number }
  const partsUsed = ((entry as { partsUsed?: PartRow[] } | null)?.partsUsed ?? []) as PartRow[]

  return (
    <div className="flex flex-col h-full">

      {/* ── Header ── */}
      <div className="shrink-0 flex items-center justify-between px-4 py-3 bg-white border-b border-gray-100">
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>

        <div className="flex items-center gap-2 flex-1 justify-center flex-wrap">
          {entry?.type && (
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${typePill}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${typeDot}`} />
              {typeShort}
            </span>
          )}
          {entry?.status && (
            <span className={`text-xs font-semibold px-2.5 py-1 rounded-full ${STATUS_PILL[entry.status] ?? 'bg-gray-100 text-gray-500'}`}>
              {STATUS_LABEL[entry.status] ?? entry.status}
            </span>
          )}
          {entry?.type && (
            <span className="text-xs text-gray-400">{TYPE_LABEL[entry.type]}</span>
          )}
        </div>

        <button className="relative w-9 h-9 rounded-full bg-gray-100 flex items-center justify-center shrink-0">
          <Bell className="w-4 h-4 text-gray-500" />
          <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500" />
        </button>
      </div>

      {/* ── Scrollable body ── */}
      <div className="flex-1 overflow-y-auto">

        {loading && (
          <div className="flex items-center justify-center py-20 gap-2 text-gray-400">
            <svg className="w-5 h-5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
            <span className="text-sm">Loading…</span>
          </div>
        )}
        {error && <p className="text-sm text-red-500 text-center py-10">{error}</p>}

        {!loading && entry && asset && (
          <>
            {/* ── Asset identity ── */}
            <div className="px-5 pt-4 pb-5  border-b border-gray-100 space-y-4 ">
              <div className="flex items-start justify-between gap-3 text-gray-400">
                <div>
                  <p className="font-mono text-base font-bold text-gray-900">{asset.gensetNumber}</p>
                  <p className="text-xs text-gray-400 mt-0.5">
                    {[asset.gensetModel, asset.kva && `${asset.kva} KVA`, asset.cpcb].filter(Boolean).join(' · ') || '—'}
                  </p>
                  {entry.srNumber && (
                    <span className="font-mono text-[10px] text-gray-400 tracking-widest">{entry.srNumber}</span>
                  )}
                </div>
                <span className={`shrink-0 text-xs font-semibold px-2.5 py-1 rounded-full ${
                  asset.warrantyStatus === 'Under Warranty' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
                }`}>
                  {asset.warrantyStatus ?? 'No warranty info'}
                </span>
              </div>

              {/* Activity History */}
              <div className="bg-white p-4 rounded-3xl">
                <SectionHeading>Activity History</SectionHeading>
                <ActivityCard
                  statusHistory={entry.statusHistory}
                  actionLog={entry.actionLog}
                  date={entry.createdAt}
                  createdByName={entry.createdBy?.name}
                  completedByName={entry.assignedTo?.name}
                  compact={true} 
                />
              </div>

              <AssetInfoGroup label="Genset Identification">
                <F label="Genset Model"     value={asset.gensetModel} />
                <F label="Genset SR Number" value={asset.gensetNumber} mono />
                <F label="Engine Model"     value={asset.engineModel} />
                <F label="Engine Number"    value={asset.engineNumber} mono />
                <F label="Engine KW"        value={asset.kw} />
                <F label="Engine Type"      value={asset.engineType} />
                <F label="Engine Family"    value={asset.engineFamily} />
                <F label="Fuel Type"        value={asset.fuelType} />
                <F label="Application"      value={asset.applicationMaterial} />
              </AssetInfoGroup>

              <AssetInfoGroup label="Engine Parameters">
                <F label="Oil Level"     value={asset.oilLevel} />
                <F label="Oil Pressure"  value={asset.oilPressure != null ? `${asset.oilPressure} kPa` : null} />
                <F label="Coolant Level" value={asset.coolantLevel} />
                <F label="Coolant Temp"  value={asset.coolantTemperature != null ? `${asset.coolantTemperature} °C` : null} />
                <F label="DEF Level"     value={asset.defLevelPercentage != null ? `${asset.defLevelPercentage}%` : null} />
              </AssetInfoGroup>

              <AssetInfoGroup label="Alternator & Panel">
                <F label="Alt. Make"   value={asset.alternatorMake} />
                <F label="Alt. Model"  value={asset.alternatorModel} />
                <F label="Alt. S/N"    value={asset.alternatorSerialNumber} />
                <F label="ATS S/N"     value={asset.atsSerialNumber} />
                <F label="Battery S/N" value={asset.batterySerialNumber} />
                <F label="KVA"         value={asset.kva} />
                <F label="Phase"       value={asset.phase} />
                <F label="Panel Type"  value={asset.panelType} />
                <F label="Panel S/N"   value={asset.controlPanelSerialNumber} />
                <F label="CPCB Norm"   value={asset.cpcb} />
              </AssetInfoGroup>
            </div>

            {/* ── Entry details ── */}
            <div className="px-5 py-5 space-y-6">

              {/* Photos */}
              {photos.length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Photos ({photos.length})</SectionHeading>
                  <div className="grid grid-cols-3 gap-2">
                    {photos.map((p, i) => (
                      <button key={i} type="button"
                        className="aspect-square rounded-xl overflow-hidden bg-gray-100 border border-gray-200 hover:opacity-90 transition-opacity"
                      >
                        <PhotoImg src={p} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" onClick={(url) => setLightbox(url)} />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Fault / Complaint Codes */}
              {faultCodes.length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Complaint Codes ({faultCodes.length})</SectionHeading>
                  <div className="space-y-3">
                    {faultCodes.map((fc, i) => (
                      <div key={i} className="overflow-hidden">
                        <div className="flex items-start gap-3 ">
                          <span className=" bg-orange-400 font-mono text-xs font-bold   text-gray-900 px-2 py-1 rounded-lg shrink-0">
                            {fc.codeId.code}
                          </span>
                          {fc.codeId.priority && (
                            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded mt-0.5 shrink-0 ${PRIORITY_CLS[fc.codeId.priority] ?? 'bg-gray-100 text-gray-500'}`}>
                              {fc.codeId.priority}
                            </span>
                          )}
                          
                        </div>
                        <div className="min-w-0 px-4">
                            <p className="text-xs font-semibold text-[#1E1951] leading-snug">{fc.codeId.description}</p>
                            <p className="text-xs text-gray-400 mt-0.5">{fc.codeId.category} › {fc.codeId.subCategory}</p>
                          </div>
                        <div className="px-4 py-3 space-y-2">
                          {fc.observation && (
                            <div className='bg-yellow-100 px-3 py-2'>
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-wide mb-1">Observation</p>
                              <p className="text-xs text-gray-700 leading-relaxed">{fc.observation}</p>
                            </div>
                          )}
                          {fc.rootCause && (
                            <div className='bg-red-100 px-3 py-2'>
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-wide mb-1">Root Cause</p>
                              <p className="text-xs text-gray-700 leading-relaxed">{fc.rootCause}</p>
                            </div>
                          )}
                          {fc.correctiveAction && (
                            <div className='bg-green-100 px-3 py-2'>
                              <p className="text-xs font-bold text-gray-800 uppercase tracking-wide mb-1">Corrective Action</p>
                              <p className="text-xs text-gray-700 leading-relaxed">{fc.correctiveAction}</p>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Parts Used */}
              {partsUsed.length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Parts Used ({partsUsed.length})</SectionHeading>
                  <div className="space-y-2">
                    {partsUsed.map((p, i) => (
                      <div key={i} className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2.5">
                        <span className="font-mono text-xs font-bold bg-white border border-gray-200 text-gray-700 px-2 py-0.5 rounded-lg shrink-0">
                          {p.partId.code}
                        </span>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-[#1E1951] truncate">{p.partId.name}</p>
                          <p className="text-xs text-gray-400">{p.partId.category} › {p.partId.subCategory}</p>
                        </div>
                        <span className="text-xs font-bold text-gray-700 shrink-0">
                          {p.quantity} <span className="font-normal text-gray-400">{p.partId.unit}</span>
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Notes */}
              {entry.notes && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Notes</SectionHeading>
                  <p className="text-sm text-gray-700 leading-relaxed">{entry.notes}</p>
                </div>
              )}

              {/* Genset Readings */}
              {entry.gensetReadings && (() => {
                const gr = entry.gensetReadings as Record<string, unknown>
                const gv = (k: string) => { const val = gr[k]; return val != null && val !== '' ? String(val) : null }
                const elec = [
                  { key: 'acVoltageRY', label: 'AC Volt R-Y (V)' }, { key: 'acVoltageYB', label: 'AC Volt Y-B (V)' },
                  { key: 'acVoltageBR', label: 'AC Volt B-R (V)' }, { key: 'acAmpR',       label: 'AC Amp R (A)' },
                  { key: 'acAmpY',      label: 'AC Amp Y (A)' },    { key: 'acAmpB',       label: 'AC Amp B (A)' },
                  { key: 'loadKwR',     label: 'Load KW R' },       { key: 'loadKwY',      label: 'Load KW Y' },
                  { key: 'loadKwB',     label: 'Load KW B' },       { key: 'totalKwLoad',  label: 'Total KW', full: true },
                  { key: 'loadPercentage', label: 'Load %' },
                ]
                const eng = [
                  { key: 'rpm', label: 'RPM' }, { key: 'frequency', label: 'Frequency (Hz)' },
                  { key: 'dcVoltage', label: 'DC Voltage (V)' }, { key: 'oilPressure', label: 'Oil Pressure' },
                  { key: 'coolantTemperature', label: 'Coolant Temp (°C)' }, { key: 'defLevelPercentage', label: 'DEF Level (%)' },
                ]
                const hasElec = elec.some(f => gv(f.key) != null)
                const hasEng  = eng.some(f => gv(f.key) != null) || gv('oilLevel') || gv('coolantLevel')
                if (!hasElec && !hasEng) return null
                return (
                  <>
                    {hasElec && (
                      <div className="bg-white p-4 rounded-3xl">
                        <SectionHeading>Electrical Readings</SectionHeading>
                        <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 grid grid-cols-3 gap-x-3 gap-y-2.5">
                          {elec.map(f => {
                            const val = gv(f.key)
                            return (
                              <div key={f.key} className={f.full ? 'col-span-3' : ''}>
                                <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">{f.label}</p>
                                <p className={`text-sm font-bold ${val ? 'text-gray-800' : 'text-gray-300'}`}>{val ?? '—'}</p>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )}
                    {hasEng && (
                      <div className="bg-white p-4 rounded-3xl">
                        <SectionHeading>Engine Parameters</SectionHeading>
                        <div className="bg-gray-50 border border-gray-100 rounded-xl p-3 grid grid-cols-3 gap-x-3 gap-y-2.5">
                          {eng.map(f => {
                            const val = gv(f.key)
                            return (
                              <div key={f.key}>
                                <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">{f.label}</p>
                                <p className={`text-sm font-bold ${val ? 'text-gray-800' : 'text-gray-300'}`}>{val ?? '—'}</p>
                              </div>
                            )
                          })}
                          {gv('oilLevel') && (
                            <div>
                              <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Oil Level</p>
                              <span className={`inline-flex text-sm font-semibold px-2 py-0.5 rounded-full ${gv('oilLevel') === 'OK' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {gv('oilLevel')}
                              </span>
                            </div>
                          )}
                          {gv('coolantLevel') && (
                            <div>
                              <p className="text-xs text-gray-400 uppercase tracking-wide mb-0.5">Coolant Level</p>
                              <span className={`inline-flex text-sm font-semibold px-2 py-0.5 rounded-full ${gv('coolantLevel') === 'OK' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {gv('coolantLevel')}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </>
                )
              })()}

              {/* Validation Checks */}
              {entry.validationChecks && Object.keys(entry.validationChecks).length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Validation Checks</SectionHeading>
                  <div className="space-y-3">
                    {VALIDATION_SECTIONS.map(sec => {
                      const vc = entry.validationChecks as Record<string, unknown> | undefined
                      const answered = sec.items.filter(item => getCheckValue(vc, item.id))
                      if (answered.length === 0) return null
                      return (
                        <div key={sec.letter} className="border border-gray-100 rounded-xl overflow-hidden">
                          <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border-b border-gray-100">
                            <span className="w-5 h-5 rounded-full bg-orange-500 text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                              {sec.letter}
                            </span>
                            <p className="text-sm font-semibold text-gray-700">{sec.title}</p>
                          </div>
                          <div className="divide-y divide-gray-50">
                            {answered.map(item => {
                              const idx     = sec.items.indexOf(item) + 1
                              const value   = getCheckValue(vc, item.id)
                              const comment = getCheckComment(vc, item.id)
                              const badgeCls =
                                value === 'Ok' || value === 'OK'    ? 'bg-green-50 text-green-700 border-green-200'
                                : value === 'Not OK'                 ? 'bg-red-50 text-red-600 border-red-200'
                                : value === 'Replaced'               ? 'bg-blue-50 text-blue-700 border-blue-200'
                                : value === 'Arrested' || value === 'Corrected' ? 'bg-[#fef4ef] text-[#E76124] border-[#E76124]/30'
                                : 'bg-gray-50 text-gray-600 border-gray-200'
                              return (
                                <div key={item.id} className="px-3 py-2.5">
                                  <div className="flex items-start justify-between gap-3">
                                    <p className="text-xs text-gray-600 leading-snug">
                                      <span className="text-gray-400 mr-1">{idx}.</span>{item.label}
                                    </p>
                                    <span className={`shrink-0 text-[11px] font-semibold border px-2 py-0.5 rounded-lg ${badgeCls}`}>
                                      {value}
                                    </span>
                                  </div>
                                  {comment && (
                                    <div className="mt-1.5 flex items-start gap-1.5">
                                      <MessageSquare className="w-3 h-3 text-gray-400 mt-0.5 shrink-0" />
                                      <p className="text-xs text-gray-500 italic leading-relaxed">{comment}</p>
                                    </div>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Commissioning Checks */}
              {entry.commissioningChecks && Object.keys(entry.commissioningChecks).length > 0 && (
                <div className="bg-white p-4 rounded-3xl">
                  <SectionHeading>Commissioning Checks</SectionHeading>
                  <div className="space-y-4">
                    {COMMISSIONING_SECTIONS.map(sec => {
                      if (sec.letter === 'D') {
                        const checks = entry.commissioningChecks!
                        const METRICS = [
                          { key: 'LR', label: 'Load R (A)' }, { key: 'LY', label: 'Load Y (A)' },
                          { key: 'LB', label: 'Load B (A)' }, { key: 'VR', label: 'Voltage R (V)' },
                          { key: 'VY', label: 'Voltage Y (V)' }, { key: 'VB', label: 'Voltage B (V)' },
                          { key: 'F', label: 'Frequency (Hz)' }, { key: 'BV', label: 'Battery Voltage (V)' },
                        ]
                        const hasAny = PERF_ROWS.some(row => METRICS.some(m => checks[`${row.prefix}${m.key}`]))
                        if (!hasAny) return null
                        const isOpen = openCommSections.has('D')
                        return (
                          <div key="D">
                            <button
                              onClick={() => toggleCommSection('D')}
                              className="flex items-center gap-2 w-full text-left px-3 py-2 mb-2 bg-indigo-100 rounded-full group"
                            >
                              <span className="w-6 h-6 rounded-full bg-orange-500 text-white text-xs font-bold flex items-center justify-center shrink-0">D</span>
                              <p className="text-sm font-bold text-gray-700 flex-1">Performance Trial</p>
                              <span className="text-xs font-medium text-gray-500 group-hover:text-gray-700 transition-colors">
                                {isOpen ? 'Less ▲' : 'More ▼'}
                              </span>
                            </button>
                            {isOpen && (
                              <div className="overflow-x-auto rounded-lg overflow-hidden border border-gray-200">
                                <table className="w-full text-xs border-collapse">
                                  <thead>
                                    <tr className="bg-[#1E1951]">
                                      <th className="text-left text-white/60 font-medium py-2 pl-3 pr-3 w-36" />
                                      {PERF_ROWS.map(row => (
                                        <th key={row.prefix} className="text-center text-white font-semibold py-2 px-2 min-w-[44px]">{row.pct}</th>
                                      ))}
                                    </tr>
                                  </thead>
                                  <tbody>
                                    {METRICS.map((m, idx) => (
                                      <tr key={m.key} className={idx % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                                        <td className="text-gray-600 font-medium py-2 pl-3 pr-3">{m.label}</td>
                                        {PERF_ROWS.map(row => {
                                          const val = checks[`${row.prefix}${m.key}`]
                                          return (
                                            <td key={row.prefix} className="text-center py-2 px-2 text-[#1E1951] font-bold">
                                              {val ?? <span className="text-gray-300">–</span>}
                                            </td>
                                          )
                                        })}
                                      </tr>
                                    ))}
                                  </tbody>
                                </table>
                              </div>
                            )}
                          </div>
                        )
                      }
                      const checks2    = entry.commissioningChecks as Record<string, unknown> | undefined
                      const answered  = sec.items.filter(item => getCheckValue(checks2, item.id))
                      if (answered.length === 0) return null
                      const okCount    = answered.filter(item => getCheckValue(checks2, item.id) === 'OK').length
                      const notOkCount = answered.filter(item => getCheckValue(checks2, item.id) === 'Not OK').length
                      const isOpen     = openCommSections.has(sec.letter)
                      return (
                        <div key={sec.letter}>
                          <button
                            onClick={() => toggleCommSection(sec.letter)}
                            className="flex items-center gap-2 w-full text-left px-3 py-2 mb-2 bg-indigo-100 rounded-full group"
                          >
                            <span className="w-6 h-6 rounded-full bg-orange-500 text-white text-xs font-bold flex items-center justify-center shrink-0">
                              {sec.letter}
                            </span>
                            <p className="text-sm font-bold text-gray-700 flex-1 truncate">{sec.title}</p>
                            <div className="flex items-center gap-2 shrink-0">
                              {okCount > 0 && (
                                <span className="flex items-center gap-0.5 text-sm font-semibold text-green-400">
                                  <CheckCircle2 size={16} />{okCount}
                                </span>
                              )}
                              {notOkCount > 0 && (
                                <span className="flex items-center gap-0.5 text-sm font-bold text-red-400">
                                  <XCircle size={16} />{notOkCount}
                                </span>
                              )}
                              <span className="text-xs font-medium text-gray-500 group-hover:text-gray-700 ml-1">
                                {isOpen ? 'Less ▲' : 'More ▼'}
                              </span>
                            </div>
                          </button>
                          {isOpen && (
                            <div className="pl-2">
                              {answered.map((item, idx) => {
                                const val     = getCheckValue(checks2, item.id)
                                const comment = getCheckComment(checks2, item.id)
                                const isNotOk = val === 'Not OK'
                                return (
                                  <div key={item.id} className={`px-2 py-2 rounded ${idx % 2 !== 0 ? 'bg-gray-50' : ''}`}>
                                    <div className="flex items-start justify-between gap-3">
                                      <p className="text-sm text-gray-800">{item.label}</p>
                                      <span className={`shrink-0 text-xs font-semibold px-2 py-0.5 rounded-lg border ${
                                        isNotOk ? 'bg-red-50 text-red-600 border-red-200' : 'bg-green-50 text-green-600 border-green-200'
                                      }`}>{val}</span>
                                    </div>
                                    {isNotOk && comment && (
                                      <p className="mt-1 text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-2 py-1.5 italic">{comment}</p>
                                    )}
                                  </div>
                                )
                              })}
                            </div>
                          )}
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Customer Feedback */}
              {entry.customerFeedback && (() => {
                const cf = entry.customerFeedback
                if (!cf) return null
                return (
                  <div className="bg-white p-4 rounded-3xl">
                    <SectionHeading>Customer Feedback</SectionHeading>
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between flex-wrap gap-2">
                        <div>
                          {cf.customerName && <p className="text-sm font-bold text-[#1E1951]">{cf.customerName}</p>}
                        </div>
                        {cf.rating != null && <Stars rating={cf.rating} />}
                      </div>
                      {cf.comment && (
                        <p className="text-xs text-gray-600 leading-relaxed italic border-t border-gray-200 pt-2.5">
                          "{cf.comment}"
                        </p>
                      )}
                    </div>
                  </div>
                )
              })()}

              <div className="pb-4" />
            </div>
          </>
        )}
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4" onClick={() => setLightbox(null)}>
          <img src={lightbox} alt="Full size" className="max-w-full max-h-full rounded-xl object-contain" />
          <button
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/20 flex items-center justify-center"
            onClick={() => setLightbox(null)}
          >
            <ChevronLeft className="w-5 h-5 text-white rotate-180" />
          </button>
        </div>
      )}
    </div>
  )
}
