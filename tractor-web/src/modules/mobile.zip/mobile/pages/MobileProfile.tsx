import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  User, Mail, Phone, MapPin,
  ChevronRight, LogOut, KeyRound, ChevronLeft, Bell,
} from 'lucide-react'
import { Avatar } from '../../../shared/components/Avatar'
import { useAuth, ROLE_LABEL } from '../../../shared/context/AuthContext'
import { api } from '../../../shared/lib/api'

interface ProfileData {
  name:       string
  username:   string
  email:      string | null
  mobile:     string | null
  address:    { line1?: string; city?: string; district?: string; state?: string; pinCode?: string } | null
  role:       string
  dealerName: string | null
  profilePic: string | null
  context: {
    am:     { _id?: string; name?: string; profilePic?: string | null; areaNames?: string[] } | null
    dealer: { _id: string; name: string; dealerName: string | null; profilePic: string | null } | null
  }
  team: { _id: string; name: string; dealerName?: string | null; profilePic: string | null }[]
}

const ROLE_COLOR: Record<string, string> = {
  admin:        'bg-[#1E1951] text-white',
  rsm:          'bg-indigo-100 text-indigo-700',
  area_manager: 'bg-violet-100 text-violet-700',
  dealer:       'bg-[#fde9df] text-[#E76124]',
  engineer:     'bg-green-100 text-green-700',
}

function InfoRow({ icon, label, value }: { icon: React.ReactNode; label: string; value?: string | null }) {
  return (
    <div className="flex items-center gap-3 px-4 py-3.5">
      <div className="w-8 h-8 rounded-xl bg-gray-50 flex items-center justify-center shrink-0">
        {icon}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-[11px] text-gray-400 font-medium">{label}</p>
        <p className="text-sm font-semibold text-gray-800 truncate mt-0.5">{value || '—'}</p>
      </div>
    </div>
  )
}

export default function MobileProfile() {
  const navigate  = useNavigate()
  const { userId, role, logout } = useAuth()
  const [data, setData]       = useState<ProfileData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.get<ProfileData>('/api/me/profile')
      .then(setData)
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  function handleLogout() {
    logout()
    navigate('/login', { replace: true })
  }

  const addrStr = data?.address
    ? [data.address.line1, data.address.city, data.address.district, data.address.state, data.address.pinCode]
        .filter(Boolean).join(', ') || null
    : null

  const am     = data?.context.am
  const dealer = data?.context.dealer
  const team   = data?.team ?? []

  return (
    <div className="px-4 py-6 space-y-4">

      {/* Header */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate(-1)}
          className="w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-600" />
        </button>
        <p className="text-lg font-extrabold tracking-widest text-gray-900 uppercase">Profile</p>
        <button className="relative w-10 h-10 rounded-full bg-white shadow-sm flex items-center justify-center">
          <Bell className="w-5 h-5 text-gray-500" />
          <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-red-500" />
        </button>
      </div>

      {/* Avatar + name */}
      <div className="flex flex-col items-center gap-3 py-2">
        {loading ? (
          <div className="w-24 h-24 rounded-full bg-gray-100 animate-pulse" />
        ) : (
          <Avatar
            name={data?.name ?? '?'}
            userId={userId ?? undefined}
            photo={data?.profilePic ?? undefined}
            size="xxl"
            showPopover={false}
          />
        )}
        <div className="text-center">
          <p className="text-xl font-bold text-gray-900">{data?.name ?? '—'}</p>
          {data?.dealerName && <p className="text-sm text-gray-400 mt-0.5">{data.dealerName}</p>}
          {role && (
            <span className={`inline-block mt-2 text-xs font-semibold px-3 py-1 rounded-full ${ROLE_COLOR[role] ?? 'bg-gray-100 text-gray-600'}`}>
              {ROLE_LABEL[role as keyof typeof ROLE_LABEL] ?? role}
            </span>
          )}
          {/* AM: show area chips */}
          {role === 'area_manager' && am?.areaNames && am.areaNames.length > 0 && (
            <div className="flex flex-wrap justify-center gap-1.5 mt-2">
              {(am.areaNames as string[]).map(a => (
                <span key={a} className="text-[11px] bg-violet-50 text-violet-700 px-2.5 py-0.5 rounded-full font-medium">{a}</span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Personal info */}
      <div className="bg-white rounded-3xl shadow-sm overflow-hidden divide-y divide-gray-50">
        <InfoRow icon={<User  className="w-4 h-4 text-gray-400" />} label="Full Name"     value={data?.name} />
        <InfoRow icon={<Mail  className="w-4 h-4 text-gray-400" />} label="Email ID"      value={data?.email} />
        <InfoRow icon={<Phone className="w-4 h-4 text-gray-400" />} label="Mobile Number" value={data?.mobile} />
        <InfoRow icon={<MapPin className="w-4 h-4 text-gray-400" />} label="Address"      value={addrStr} />
      </div>

      {/* Context: AM + Dealer */}
      {(am?._id || dealer) && (
        <div className="bg-white rounded-3xl shadow-sm overflow-hidden divide-y divide-gray-50">
          {am?._id && (
            <div className="flex items-center gap-3 px-4 py-3.5">
              <Avatar name={am.name!} userId={am._id} photo={am.profilePic ?? undefined} size="md" showPopover={true} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-800">{am.name}</p>
                <p className="text-xs text-gray-400 truncate">
                  Area Manager{am.areaNames?.length ? ` · ${(am.areaNames as string[]).join(', ')}` : ''}
                </p>
              </div>
            </div>
          )}
          {dealer && (
            <div className="flex items-center gap-3 px-4 py-3.5">
              <Avatar name={dealer.name} userId={dealer._id} photo={dealer.profilePic ?? undefined} size="md" showPopover={true} />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-800">{dealer.name}</p>
                <p className="text-xs text-gray-400 truncate">
                  Dealer{dealer.dealerName ? ` · ${dealer.dealerName}` : ''}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Team */}
      {team.length > 0 && (
        <div className="bg-white rounded-3xl shadow-sm overflow-hidden">
          <p className="px-4 pt-4 pb-1 text-xs font-bold text-gray-500 uppercase tracking-wider">Team</p>
          <div className="divide-y divide-gray-50">
            {team.map(member => (
              <div key={member._id} className="flex items-center gap-3 px-4 py-3">
                <Avatar name={member.name} userId={member._id} photo={member.profilePic ?? undefined} size="md" showPopover={true} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-gray-800">{member.name}</p>
                  {member.dealerName && <p className="text-xs text-gray-400">{member.dealerName}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="bg-white rounded-3xl shadow-sm overflow-hidden divide-y divide-gray-100">
        <button className="w-full flex items-center gap-3 px-5 py-4 hover:bg-gray-50 transition-colors">
          <div className="w-9 h-9 rounded-xl bg-blue-50 flex items-center justify-center shrink-0">
            <KeyRound className="w-5 h-5 text-blue-500" />
          </div>
          <p className="flex-1 text-left text-sm font-semibold text-gray-800">Change Password</p>
          <ChevronRight className="w-4 h-4 text-gray-300" />
        </button>
        <button onClick={handleLogout} className="w-full flex items-center gap-3 px-5 py-4 hover:bg-red-50 transition-colors">
          <div className="w-9 h-9 rounded-xl bg-red-50 flex items-center justify-center shrink-0">
            <LogOut className="w-5 h-5 text-red-500" />
          </div>
          <p className="flex-1 text-left text-sm font-semibold text-red-500">Logout</p>
          <ChevronRight className="w-4 h-4 text-red-300" />
        </button>
      </div>

    </div>
  )
}
